; Title: Title_Screen_bw_ID_style
; Composer: 
; Maker: 
; Programer: mid2mml for ppmck Ver1.0�� & stgig

	.bank	0
	.if TOTAL_SONGS > 1
song_addr_table:
	dw	song_000_track_table
	.if (ALLOW_BANK_SWITCH)
song_bank_table:
	dw	song_000_bank_table
	.endif ; ALLOW_BANK_SWITCH
	.endif ; TOTAL_SONGS > 1
song_000_track_table:
	dw	song_000_00
	dw	song_000_01
	dw	song_000_02
	dw	song_000_03
	dw	song_000_04
	dw	song_000_05
	dw	song_000_06
	dw	song_000_07
	dw	song_000_08
	dw	song_000_09
	dw	song_000_10
	dw	song_000_11
	dw	song_000_12
	dw	song_000_13
	dw	song_000_14
	dw	song_000_15
	dw	song_000_16
	dw	song_000_17
	dw	song_000_18
	dw	song_000_19
	dw	song_000_20
	dw	song_000_21
	dw	song_000_22
	dw	song_000_23
	dw	song_000_24
	dw	song_000_25
	dw	song_000_26
	dw	song_000_27
	.if (ALLOW_BANK_SWITCH)
song_000_bank_table:
	db	bank(song_000_00)*2
	db	bank(song_000_01)*2
	db	bank(song_000_02)*2
	db	bank(song_000_03)*2
	db	bank(song_000_04)*2
	db	bank(song_000_05)*2
	db	bank(song_000_06)*2
	db	bank(song_000_07)*2
	db	bank(song_000_08)*2
	db	bank(song_000_09)*2
	db	bank(song_000_10)*2
	db	bank(song_000_11)*2
	db	bank(song_000_12)*2
	db	bank(song_000_13)*2
	db	bank(song_000_14)*2
	db	bank(song_000_15)*2
	db	bank(song_000_16)*2
	db	bank(song_000_17)*2
	db	bank(song_000_18)*2
	db	bank(song_000_19)*2
	db	bank(song_000_20)*2
	db	bank(song_000_21)*2
	db	bank(song_000_22)*2
	db	bank(song_000_23)*2
	db	bank(song_000_24)*2
	db	bank(song_000_25)*2
	db	bank(song_000_26)*2
	db	bank(song_000_27)*2
	.endif

song_000_00:	;Trk A
	db	$ee
	db	bank(song_000_00_bnk002)*2
	dw	song_000_00_bnk002

	.bank	2
song_000_00_bnk002:
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 131 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 135 : 324
	db	$fc,$29,$fb,$08,$fd,$18,$fe,$01	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 139 : 647
	db	$20,$51,$1a,$50,$18,$51,$1a,$29	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 139 : 688
	db	$fd,$17,$21,$05,$fc,$02,$21,$05	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 143 : 971
	db	$21,$05,$fc,$03,$21,$05,$fc,$03	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 143 : 983
	db	$21,$05,$fc,$30,$fc,$51,$fc,$50	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 143 : 999
	db	$fc,$29,$fd,$18,$21,$28,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 146 : 1213
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 148 : 1375
	db	$fc,$51,$fc,$28,$21,$29,$20,$14	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 152 : 1699
	db	$28,$14,$22,$05,$fc,$0f,$1b,$15	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 154 : 1881
	db	$30,$14,$1a,$14,$fd,$17,$23,$03	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 155 : 1942
	db	$23,$9d,$fc,$02,$23,$a2,$fd,$18	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 155 : 1985
	db	$21,$a2,$fd,$17,$21,$28,$23,$29	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 159 : 2306
	db	$fd,$18,$31,$28,$34,$29,$fc,$28	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 162 : 2549
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 164 : 2670
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 168 : 2994
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 172 : 3317
	db	$fc,$2a,$fc,$0d,$fc,$47,$fc,$08	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 175 : 3600
	db	$fc,$03,$fc,$20,$fc,$29,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 177 : 3734
	db	$fc,$28,$fc,$29,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 179 : 3891
	db	$fc,$28,$fc,$2a,$fc,$07,$fc,$18	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 182 : 4134
	db	$fc,$0e,$fc,$05,$fc,$21,$fc,$1e	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 183 : 4247
	db	$fc,$33,$fc,$03,$fc,$12,$fc,$23	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 184 : 4329
	db	$fc,$14,$fc,$0c,$fc,$19,$fc,$17	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 185 : 4436
	db	$fc,$3e,$fc,$0f
song_000_00_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_00_lp)*2
	dw	song_000_00_lp


song_000_01:	;Trk B
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 189 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 193 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 197 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 201 : 971
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 205 : 1294
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$14	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 209 : 1618
	db	$fb,$08,$fd,$18,$fe,$01,$18,$14	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 212 : 1881
	db	$fc,$29,$fc,$2b,$fc,$26,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 212 : 1901
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 215 : 2104
	db	$fc,$51,$fc,$29,$1a,$28,$21,$29	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 219 : 2427
	db	$fc,$28,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 221 : 2630
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 225 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 229 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 233 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 235 : 3726
	db	$fc,$51,$fc,$28,$fc,$29,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 236 : 3810
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 239 : 4053
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 241 : 4223
	db	$fc,$1e,$fc,$33,$fc,$03,$fc,$12	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 242 : 4299
	db	$fc,$23,$fc,$14,$fc,$0c,$fc,$19	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 243 : 4401
	db	$fc,$17,$fc,$3e,$fc,$0f
song_000_01_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_01_lp)*2
	dw	song_000_01_lp


song_000_02:	;Trk C
	db	$fe,$8f,$fc,$28,$fb,$00,$49,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 101 : 0
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 247 : 40
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 247 : 53
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 247 : 61
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 247 : 73
	db	$fc,$01,$fc,$02,$49,$05,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 248 : 81
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 248 : 94
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 248 : 101
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 248 : 114
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 248 : 121
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 248 : 134
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 248 : 142
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 248 : 154
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 249 : 162
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 249 : 174
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 249 : 182
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 249 : 195
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 249 : 202
	db	$49,$04,$fc,$01,$fc,$02,$49,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 249 : 215
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 249 : 222
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 249 : 235
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 250 : 243
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 250 : 255
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 250 : 263
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 250 : 276
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 250 : 283
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 250 : 296
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 250 : 303
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 250 : 316
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 251 : 324
	db	$49,$04,$fc,$01,$fc,$03,$25,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 251 : 336
	db	$fc,$01,$fc,$02,$35,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 251 : 344
	db	$35,$05,$fc,$01,$fc,$02,$39,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 251 : 356
	db	$fc,$01,$fc,$05,$37,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 251 : 364
	db	$fc,$03,$39,$09,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 251 : 374
	db	$39,$01,$fc,$01,$fc,$03,$39,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 251 : 392
	db	$fc,$01,$fc,$02,$3a,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 251 : 397
	db	$fc,$05,$37,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 252 : 407
	db	$3a,$09,$fc,$01,$fc,$05,$3a,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 252 : 417
	db	$fc,$01,$fc,$02,$3a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 252 : 432
	db	$fc,$03,$40,$01,$fc,$01,$fc,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 252 : 442
	db	$3b,$01,$fc,$01,$fc,$03,$41,$09	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 252 : 453
	db	$fc,$01,$fc,$05,$41,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 252 : 458
	db	$fc,$03,$41,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 252 : 475
	db	$43,$02,$fc,$01,$fc,$05,$40,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 485
	db	$fc,$01,$fc,$02,$41,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 493
	db	$fc,$03,$43,$01,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 503
	db	$42,$02,$fc,$01,$fc,$02,$43,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 513
	db	$fc,$01,$fc,$03,$40,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 518
	db	$fc,$02,$49,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 531
	db	$49,$05,$fc,$01,$fc,$02,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 538
	db	$fc,$01,$fc,$03,$49,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 546
	db	$fc,$03,$49,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 253 : 556
	db	$49,$04,$fc,$01,$fc,$03,$49,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 566
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 574
	db	$fc,$03,$4a,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 584
	db	$49,$02,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 594
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 599
	db	$fc,$02,$49,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 612
	db	$49,$04,$fc,$01,$fc,$03,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 619
	db	$fc,$01,$fc,$03,$49,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 627
	db	$fc,$03,$49,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 254 : 637
	db	$4a,$04,$fc,$01,$fc,$03,$49,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 647
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 655
	db	$fc,$02,$4a,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 665
	db	$49,$02,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 675
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 680
	db	$fc,$02,$49,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 693
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 700
	db	$fc,$01,$fc,$02,$49,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 708
	db	$fc,$03,$49,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 255 : 718
	db	$49,$04,$fc,$01,$fc,$03,$49,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 728
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 736
	db	$fc,$02,$49,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 746
	db	$49,$01,$fc,$01,$fc,$03,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 756
	db	$fc,$01,$fc,$03,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 761
	db	$fc,$02,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 774
	db	$fc,$01,$fc,$03,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 781
	db	$fc,$02,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 794
	db	$fc,$01,$fc,$03,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 256 : 801
	db	$fc,$03,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 257 : 814
	db	$fc,$01,$fc,$02,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 257 : 822
	db	$fc,$03,$4a,$04,$fc,$01,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 257 : 834
	db	$fc,$01,$fc,$02,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 257 : 842
	db	$fc,$03,$48,$04,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 257 : 854
	db	$fc,$01,$fc,$03,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 257 : 862
	db	$fc,$02,$48,$04,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 257 : 875
	db	$fc,$01,$fc,$03,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 257 : 882
	db	$fc,$02,$48,$05,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 258 : 895
	db	$fc,$01,$fc,$02,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 258 : 903
	db	$fc,$03,$48,$04,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 258 : 915
	db	$fc,$01,$fc,$02,$50,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 258 : 923
	db	$fc,$03,$50,$04,$fc,$01,$50,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 258 : 935
	db	$fc,$01,$fc,$03,$50,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 258 : 943
	db	$fc,$02,$50,$04,$fc,$01,$50,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 258 : 956
	db	$fc,$01,$fc,$03,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 258 : 963
	db	$fc,$02,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 259 : 976
	db	$fc,$01,$fc,$03,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 259 : 983
	db	$fc,$03,$4a,$04,$fc,$01,$4b,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 259 : 996
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 259 : 1004
	db	$fc,$03,$49,$04,$fc,$01,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 259 : 1016
	db	$fc,$01,$fc,$02,$49,$05,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 259 : 1024
	db	$fc,$02,$49,$04,$fc,$01,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 259 : 1037
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 259 : 1044
	db	$fc,$02,$49,$04,$fc,$01,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 260 : 1057
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 260 : 1064
	db	$fc,$02,$49,$05,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 260 : 1077
	db	$fc,$01,$fc,$02,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 260 : 1085
	db	$fc,$03,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 260 : 1097
	db	$fc,$01,$fc,$02,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 260 : 1105
	db	$fc,$03,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 260 : 1117
	db	$fc,$01,$fc,$03,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 260 : 1125
	db	$fc,$02,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 261 : 1138
	db	$fc,$01,$fc,$03,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 261 : 1145
	db	$fc,$02,$4a,$04,$fc,$01,$49,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 261 : 1158
	db	$fc,$01,$fc,$02,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 261 : 1165
	db	$fc,$03,$48,$04,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 261 : 1178
	db	$fc,$01,$fc,$02,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 261 : 1186
	db	$fc,$03,$48,$04,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 261 : 1198
	db	$fc,$01,$fc,$02,$48,$05,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 261 : 1206
	db	$fc,$02,$48,$04,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 262 : 1219
	db	$fc,$01,$fc,$03,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 262 : 1226
	db	$fc,$02,$48,$04,$fc,$01,$48,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 262 : 1239
	db	$fc,$01,$fc,$03,$50,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 262 : 1246
	db	$fc,$03,$50,$04,$fc,$01,$50,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 262 : 1259
	db	$fc,$01,$fc,$02,$50,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 262 : 1267
	db	$fc,$03,$50,$04,$fc,$01,$50,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 262 : 1279
	db	$fc,$01,$fc,$02,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 262 : 1287
	db	$fc,$03,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 263 : 1299
	db	$fc,$01,$fc,$03,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 263 : 1307
	db	$fc,$02,$4a,$04,$fc,$01,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 263 : 1320
	db	$fc,$01,$fc,$03,$40,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 263 : 1327
	db	$fc,$05,$35,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 263 : 1337
	db	$35,$05,$fc,$01,$fc,$02,$35,$12	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 263 : 1347
	db	$fc,$02,$fc,$29,$23,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 263 : 1355
	db	$fc,$02,$37,$04,$fc,$01,$23,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 264 : 1421
	db	$fc,$01,$fc,$03,$37,$12,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 264 : 1428
	db	$fc,$29,$28,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 265 : 1456
	db	$40,$02,$fc,$01,$fc,$02,$21,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 265 : 1504
	db	$fc,$01,$35,$12,$fc,$02,$fc,$29	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 265 : 1509
	db	$26,$04,$fc,$01,$fc,$02,$3a,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 266 : 1578
	db	$fc,$01,$fc,$02,$36,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 266 : 1585
	db	$fc,$03,$36,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 266 : 1595
	db	$40,$02,$fc,$01,$fc,$02,$4a,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 266 : 1605
	db	$fc,$01,$50,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 266 : 1610
	db	$4a,$04,$fc,$01,$40,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 267 : 1626
	db	$38,$04,$fc,$01,$fc,$03,$40,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 267 : 1638
	db	$fc,$01,$38,$06,$fc,$01,$35,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 267 : 1646
	db	$fc,$01,$fc,$05,$39,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 267 : 1658
	db	$fc,$03,$40,$69,$fc,$08,$fc,$45	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 267 : 1676
	db	$fc,$51,$fc,$28,$48,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 270 : 1861
	db	$48,$02,$fc,$01,$fc,$05,$38,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 271 : 1985
	db	$fc,$01,$fc,$08,$38,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 271 : 1993
	db	$fc,$08,$48,$01,$fc,$01,$fc,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 271 : 2005
	db	$48,$04,$fc,$01,$fc,$05,$38,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 272 : 2023
	db	$fc,$01,$fc,$07,$38,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 272 : 2033
	db	$fc,$07,$48,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 272 : 2046
	db	$48,$04,$fc,$01,$fc,$06,$38,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 272 : 2063
	db	$fc,$01,$fc,$08,$38,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 272 : 2074
	db	$fc,$08,$48,$01,$fc,$01,$fc,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 272 : 2086
	db	$48,$04,$fc,$01,$fc,$05,$38,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 273 : 2104
	db	$fc,$01,$fc,$08,$38,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 273 : 2114
	db	$fc,$07,$48,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 273 : 2127
	db	$48,$04,$fc,$01,$fc,$05,$36,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 273 : 2144
	db	$fc,$01,$fc,$08,$36,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 273 : 2154
	db	$fc,$08,$48,$01,$fc,$01,$fc,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 273 : 2167
	db	$48,$04,$fc,$01,$fc,$05,$36,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 274 : 2185
	db	$fc,$01,$fc,$08,$36,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 274 : 2195
	db	$fc,$07,$48,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 274 : 2208
	db	$48,$04,$fc,$01,$fc,$05,$36,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 274 : 2225
	db	$fc,$01,$fc,$07,$36,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 274 : 2235
	db	$fc,$08,$48,$01,$fc,$01,$fc,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 274 : 2248
	db	$48,$04,$fc,$01,$fc,$05,$36,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 275 : 2266
	db	$fc,$01,$fc,$08,$36,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 275 : 2276
	db	$fc,$08,$48,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 275 : 2288
	db	$48,$04,$fc,$01,$fc,$05,$38,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 275 : 2306
	db	$fc,$01,$fc,$07,$38,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 275 : 2316
	db	$fc,$07,$48,$02,$fc,$01,$fc,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 275 : 2329
	db	$48,$04,$fc,$01,$fc,$05,$38,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 276 : 2347
	db	$fc,$01,$fc,$08,$38,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 276 : 2357
	db	$fc,$08,$48,$01,$fc,$01,$fc,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 276 : 2369
	db	$48,$04,$fc,$01,$fc,$05,$38,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 276 : 2387
	db	$fc,$01,$fc,$07,$38,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 276 : 2397
	db	$fc,$07,$48,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 276 : 2410
	db	$48,$05,$fc,$01,$fc,$05,$38,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 277 : 2427
	db	$fc,$01,$fc,$08,$38,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 277 : 2438
	db	$fc,$08,$43,$01,$fc,$01,$fc,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 277 : 2450
	db	$48,$04,$fc,$01,$fc,$05,$38,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 277 : 2468
	db	$fc,$01,$fc,$07,$38,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 277 : 2478
	db	$fc,$07,$48,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 277 : 2491
	db	$48,$04,$fc,$01,$fc,$05,$38,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 278 : 2508
	db	$fc,$01,$fc,$08,$38,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 278 : 2518
	db	$fc,$08,$48,$01,$fc,$01,$fc,$30	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 278 : 2531
	db	$fc,$29,$38,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 279 : 2589
	db	$38,$04,$fc,$01,$fc,$0f,$38,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 279 : 2640
	db	$fc,$01,$fc,$05,$38,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 279 : 2660
	db	$fc,$05,$38,$04,$fc,$01,$fc,$0f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 280 : 2675
	db	$38,$05,$fc,$01,$fc,$05,$38,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 280 : 2700
	db	$fc,$01,$fc,$05,$38,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 280 : 2711
	db	$fc,$0f,$38,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 280 : 2726
	db	$38,$04,$fc,$01,$fc,$05,$38,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 281 : 2751
	db	$fc,$01,$fc,$0f,$38,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 281 : 2761
	db	$fc,$05,$36,$05,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 281 : 2786
	db	$36,$04,$fc,$01,$fc,$0f,$36,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 281 : 2802
	db	$fc,$01,$fc,$05,$36,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 281 : 2822
	db	$fc,$05,$36,$04,$fc,$01,$fc,$0f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 282 : 2837
	db	$36,$04,$fc,$01,$fc,$05,$36,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 282 : 2862
	db	$fc,$01,$fc,$06,$36,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 282 : 2872
	db	$fc,$0f,$36,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 282 : 2888
	db	$36,$04,$fc,$01,$fc,$05,$36,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 283 : 2913
	db	$fc,$01,$fc,$0f,$36,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 283 : 2923
	db	$fc,$05,$35,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 283 : 2948
	db	$35,$04,$fc,$01,$fc,$10,$35,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 283 : 2963
	db	$fc,$01,$fc,$05,$35,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 283 : 2984
	db	$fc,$05,$35,$04,$fc,$01,$fc,$0f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 284 : 2999
	db	$35,$04,$fc,$01,$fc,$05,$35,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 284 : 3024
	db	$fc,$01,$fc,$05,$35,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 284 : 3034
	db	$fc,$10,$35,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 284 : 3049
	db	$35,$04,$fc,$01,$fc,$05,$35,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 285 : 3075
	db	$fc,$01,$fc,$0f,$34,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 285 : 3085
	db	$fc,$05,$34,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 285 : 3110
	db	$34,$04,$fc,$01,$fc,$0f,$34,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 285 : 3125
	db	$fc,$01,$fc,$06,$34,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 285 : 3145
	db	$fc,$05,$34,$04,$fc,$01,$fc,$0f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 286 : 3161
	db	$34,$04,$fc,$01,$fc,$05,$34,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 286 : 3186
	db	$fc,$01,$fc,$05,$34,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 286 : 3196
	db	$fc,$0f,$34,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 286 : 3211
	db	$34,$04,$fc,$01,$fc,$06,$34,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 287 : 3236
	db	$fc,$01,$fc,$0f,$34,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 287 : 3247
	db	$fc,$2d,$fc,$51,$fc,$51,$fc,$51	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 287 : 3272
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 291 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$49,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 293 : 3726
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 293 : 3769
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 293 : 3782
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 293 : 3790
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 293 : 3802
	db	$fc,$01,$fc,$02,$49,$05,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 294 : 3810
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 294 : 3823
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 294 : 3830
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 294 : 3843
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 294 : 3850
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 294 : 3863
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 294 : 3871
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 294 : 3883
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 295 : 3891
	db	$49,$05,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 295 : 3903
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 295 : 3911
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 295 : 3924
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 295 : 3931
	db	$49,$04,$fc,$01,$fc,$02,$49,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 295 : 3944
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 295 : 3951
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 295 : 3964
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 296 : 3972
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 296 : 3984
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 296 : 3992
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 296 : 4005
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 296 : 4012
	db	$49,$04,$fc,$01,$fc,$02,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 296 : 4025
	db	$fc,$01,$fc,$03,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 296 : 4032
	db	$49,$04,$fc,$01,$fc,$03,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 296 : 4045
	db	$fc,$01,$fc,$02,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 297 : 4053
	db	$49,$04,$fc,$01,$fc,$03,$25,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 297 : 4065
	db	$fc,$01,$fc,$02,$35,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 297 : 4073
	db	$35,$07,$fc,$01,$39,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 297 : 4085
	db	$fc,$05,$37,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 297 : 4096
	db	$39,$09,$fc,$01,$fc,$05,$39,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 297 : 4106
	db	$fc,$01,$fc,$03,$39,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 297 : 4121
	db	$fc,$06,$3a,$01,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 297 : 4128
	db	$37,$02,$fc,$01,$fc,$02,$3a,$09	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 298 : 4141
	db	$fc,$01,$fc,$05,$3a,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 298 : 4146
	db	$fc,$02,$3a,$02,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 298 : 4164
	db	$40,$02,$fc,$01,$fc,$05,$3b,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 298 : 4174
	db	$fc,$01,$fc,$03,$41,$09,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 298 : 4182
	db	$fc,$06,$41,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 298 : 4197
	db	$41,$01,$fc,$01,$fc,$06,$43,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 298 : 4208
	db	$fc,$01,$fc,$05,$40,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 299 : 4216
	db	$fc,$03,$41,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 299 : 4226
	db	$43,$01,$fc,$01,$fc,$06,$42,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 299 : 4237
	db	$fc,$01,$fc,$03,$43,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 299 : 4245
	db	$fc,$03,$39,$02,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 299 : 4255
	db	$37,$01,$fc,$01,$fc,$03,$39,$09	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 299 : 4266
	db	$fc,$01,$fc,$05,$39,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 299 : 4271
	db	$fc,$03,$39,$02,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 299 : 4288
	db	$3a,$01,$fc,$01,$fc,$05,$37,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 300 : 4299
	db	$fc,$01,$fc,$02,$3a,$09,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 300 : 4306
	db	$fc,$05,$3a,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 300 : 4321
	db	$3a,$02,$fc,$01,$fc,$05,$40,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 300 : 4331
	db	$fc,$01,$fc,$05,$3b,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 300 : 4339
	db	$fc,$03,$41,$09,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 300 : 4349
	db	$41,$02,$fc,$01,$fc,$02,$41,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 300 : 4367
	db	$fc,$01,$fc,$05,$43,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 300 : 4372
	db	$fc,$05,$40,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 301 : 4383
	db	$41,$04,$fc,$01,$fc,$03,$43,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 301 : 4393
	db	$fc,$01,$fc,$06,$42,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 301 : 4401
	db	$fc,$03,$43,$05,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 301 : 4411
	db	$50,$0d,$fc,$01,$50,$12,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 301 : 4422
	db	$50,$22,$fc,$03,$25,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 301 : 4456
	db	$fc,$06,$25,$03,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 302 : 4497
	db	$25,$02,$fc,$01,$fc,$03,$fc,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 302 : 4510
	db	$25,$17,$fc,$02,$fc,$21,$fc,$0f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 302 : 4520

song_000_02_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_02_lp)*2
	dw	song_000_02_lp


song_000_03:	;Trk D
	db	$fe,$8f,$fc,$51,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 101 : 0
	db	$fc,$28,$fd,$30,$22,$29,$22,$14	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 308 : 243
	db	$22,$14,$22,$51,$22,$28,$22,$29	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 309 : 344
	db	$22,$51,$fc,$28,$fc,$29,$22,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 311 : 526
	db	$fc,$28,$fc,$51,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 314 : 769
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$29	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 318 : 1052
	db	$22,$51,$fc,$28,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 321 : 1335
	db	$fc,$3d,$22,$51,$fc,$14,$fc,$28	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 325 : 1618
	db	$22,$51,$fc,$29,$fc,$28,$22,$03	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 327 : 1820
	db	$22,$56,$fc,$21,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 329 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 333 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 337 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 341 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 345 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 349 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$22,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 351 : 3726
	db	$fc,$29,$fc,$28,$fc,$29,$fc,$28	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 352 : 3850
	db	$22,$29,$22,$14,$22,$14,$22,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 354 : 4012
	db	$22,$2a,$22,$07,$22,$0e,$22,$0a	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 356 : 4174
	db	$22,$0b,$22,$03,$22,$05,$22,$3f	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 357 : 4247
	db	$22,$0a,$22,$29,$22,$03,$22,$12	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 358 : 4329
	db	$22,$15,$22,$0e,$22,$14,$22,$25	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 359 : 4401
	db	$22,$04,$fc,$13,$fc,$3e,$fc,$0f	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 360 : 4493

song_000_03_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_03_lp)*2
	dw	song_000_03_lp


song_000_04:	;Trk E
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 363 : 0
	db	$f4,$50,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 367 : 324
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 371 : 647
	db	$f4,$51,$f4,$51,$f4,$50,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 375 : 971
	db	$f4,$29,$01,$0c,$01,$08,$01,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 379 : 1294
	db	$01,$07,$01,$08,$01,$05,$01,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 379 : 1368
	db	$01,$0c,$01,$08,$01,$0c,$01,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 380 : 1396
	db	$01,$0d,$01,$07,$01,$08,$01,$05	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 380 : 1436
	db	$01,$07,$01,$0d,$01,$08,$01,$0c	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 381 : 1469
	db	$01,$08,$01,$0c,$01,$08,$01,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 381 : 1509
	db	$01,$05,$01,$07,$01,$0d,$01,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 382 : 1545
	db	$01,$07,$01,$05,$01,$1c,$01,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 382 : 1578
	db	$01,$05,$01,$14,$01,$07,$01,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 383 : 1626
	db	$01,$08,$01,$0c,$01,$08,$01,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 383 : 1671
	db	$01,$06,$01,$07,$01,$0d,$01,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 384 : 1706
	db	$01,$0d,$01,$08,$01,$14,$01,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 384 : 1739
	db	$01,$05,$01,$08,$01,$0d,$01,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 385 : 1787
	db	$01,$0d,$01,$07,$01,$0d,$01,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 385 : 1820
	db	$01,$07,$01,$05,$01,$08,$01,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 386 : 1861
	db	$01,$07,$01,$0d,$01,$07,$01,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 386 : 1894
	db	$01,$08,$01,$07,$01,$05,$01,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 386 : 1934
	db	$01,$0d,$01,$0a,$01,$47,$f4,$30	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 387 : 1962
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$50	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 389 : 2104
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 393 : 2427
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 397 : 2751
	db	$f4,$51,$f4,$50,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 401 : 3075
	db	$f4,$51,$f4,$51,$f4,$28,$f4,$2a	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 405 : 3398
	db	$f4,$0d,$f4,$47,$f4,$08,$f4,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 408 : 3642
	db	$f4,$20,$f4,$29,$f4,$51,$f4,$28	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 409 : 3737
	db	$f4,$29,$f4,$51,$f4,$51,$f4,$28	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 411 : 3931
	db	$f4,$2a,$f4,$07,$f4,$18,$f4,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 414 : 4174
	db	$f4,$05,$f4,$21,$f4,$1e,$f4,$33	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 415 : 4261
	db	$01,$03,$01,$12,$01,$15,$01,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 417 : 4380
	db	$01,$08,$01,$0c,$01,$03,$01,$09	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 417 : 4436
	db	$01,$10,$01,$09,$01,$17,$01,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 418 : 4468
	db	$01,$49
song_000_04_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_04_lp)*2
	dw	song_000_04_lp


song_000_05:	;Trk F
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 421 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 425 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 429 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 433 : 971
	db	$fc,$51,$fc,$3d,$fb,$00,$fd,$1e	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 437 : 1294
	db	$fe,$00,$57,$14,$fc,$35,$fd,$1f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 438 : 1436
	db	$41,$05,$fc,$0f,$4a,$08,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 439 : 1509
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 441 : 1618
	db	$fc,$2b,$fc,$26,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 445 : 1942
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 448 : 2185
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 452 : 2508
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 456 : 2832
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 460 : 3156
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 464 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 466 : 3655
	db	$fc,$29,$fc,$51,$fc,$28,$fc,$29	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 467 : 3769
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 470 : 3972
	db	$fc,$07,$fc,$18,$fc,$0e,$fc,$05	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 473 : 4216
	db	$fc,$21,$fc,$1e,$fc,$33,$fc,$03	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 473 : 4266
	db	$fc,$12,$fc,$23,$fc,$14,$fc,$0c	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 475 : 4383
	db	$fc,$19,$fc,$17,$fc,$3e,$fc,$0f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 476 : 4468

song_000_05_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_05_lp)*2
	dw	song_000_05_lp


song_000_06:	;Trk G
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 479 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 483 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 487 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 491 : 971
	db	$fc,$51,$fc,$51,$fc,$49,$fb,$00	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 495 : 1294
	db	$fd,$24,$fe,$40,$53,$08,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 497 : 1529
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 499 : 1618
	db	$fc,$2b,$fc,$26,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 503 : 1942
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 506 : 2185
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 510 : 2508
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 514 : 2832
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 518 : 3156
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 522 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 524 : 3655
	db	$fc,$29,$fc,$51,$fc,$28,$fc,$29	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 525 : 3769
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 528 : 3972
	db	$fc,$07,$fc,$18,$fc,$0e,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 531 : 4216
	db	$fc,$21,$fc,$1e,$fc,$33,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 531 : 4266
	db	$fc,$12,$fc,$23,$fc,$14,$fc,$0c	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 533 : 4383
	db	$fc,$19,$fc,$17,$fc,$3e,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 534 : 4468

song_000_06_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_06_lp)*2
	dw	song_000_06_lp


song_000_07:	;Trk H
	db	$fc,$51,$fd,$26,$fe,$06,$35,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 537 : 0
	db	$fc,$05,$3b,$03,$fc,$03,$36,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 538 : 83
	db	$fc,$02,$46,$03,$fc,$05,$3b,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 538 : 99
	db	$fc,$03,$35,$05,$fc,$2b,$45,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 538 : 111
	db	$fc,$05,$4b,$03,$fc,$02,$46,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 539 : 164
	db	$fc,$05,$53,$03,$fc,$05,$4b,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 539 : 177
	db	$fc,$03,$45,$02,$fc,$2e,$35,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 539 : 192
	db	$fc,$05,$3b,$03,$fc,$02,$36,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 540 : 245
	db	$fc,$05,$46,$02,$fc,$06,$45,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 540 : 258
	db	$fc,$03,$4b,$05,$fc,$02,$fd,$27	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 540 : 273
	db	$46,$14,$fc,$08,$53,$02,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 540 : 283
	db	$53,$05,$fc,$03,$46,$14,$3b,$14	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 540 : 316
	db	$40,$08,$fc,$0c,$39,$08,$fc,$0c	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 541 : 364
	db	$35,$15,$fc,$07,$fd,$26,$34,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 542 : 404
	db	$fc,$02,$34,$05,$fc,$03,$fd,$27	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 542 : 435
	db	$51,$17,$fc,$05,$fd,$26,$48,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 542 : 445
	db	$45,$07,$3a,$03,$fc,$05,$45,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 542 : 478
	db	$fc,$02,$51,$05,$fc,$03,$53,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 543 : 496
	db	$fc,$05,$47,$03,$fc,$02,$53,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 543 : 508
	db	$fc,$03,$45,$07,$fc,$21,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 543 : 523
	db	$fc,$29,$35,$1e,$39,$03,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 545 : 647
	db	$30,$3d,$fc,$0a,$33,$02,$fc,$08	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 546 : 728
	db	$33,$19,$fc,$03,$32,$02,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 547 : 809
	db	$31,$05,$fc,$02,$30,$9b,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 547 : 842
	db	$35,$0a,$fc,$03,$39,$05,$fc,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 549 : 1011
	db	$30,$72,$fc,$08,$fd,$27,$3a,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 549 : 1031
	db	$37,$03,$fc,$02,$3a,$08,$fd,$26	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 551 : 1160
	db	$30,$72,$fc,$07,$36,$05,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 551 : 1173
	db	$fc,$05,$46,$05,$fc,$03,$45,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 553 : 1302
	db	$fc,$05,$4a,$03,$fc,$02,$50,$08	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 553 : 1317
	db	$45,$02,$fc,$12,$39,$0d,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 553 : 1335
	db	$45,$03,$fc,$05,$45,$02,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 554 : 1375
	db	$45,$02,$fc,$06,$45,$02,$fc,$0a	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 554 : 1388
	db	$50,$08,$3a,$02,$fc,$05,$42,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 554 : 1408
	db	$fc,$02,$43,$03,$fc,$19,$4a,$19	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 554 : 1426
	db	$fc,$03,$49,$03,$fc,$02,$48,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 555 : 1481
	db	$fc,$05,$45,$02,$fc,$05,$45,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 555 : 1492
	db	$fc,$02,$44,$08,$45,$02,$fc,$0a	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 555 : 1507
	db	$4a,$06,$fc,$02,$44,$03,$fc,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 555 : 1529
	db	$45,$02,$fc,$03,$44,$02,$fc,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 556 : 1545
	db	$45,$0d,$44,$02,$fc,$06,$46,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 556 : 1557
	db	$fc,$05,$46,$03,$fc,$02,$46,$12	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 556 : 1580
	db	$fc,$0a,$48,$03,$fc,$05,$48,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 556 : 1608
	db	$fc,$03,$48,$11,$fc,$03,$48,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 557 : 1628
	db	$fc,$05,$40,$03,$fc,$0a,$45,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 557 : 1653
	db	$fc,$05,$49,$6f,$fc,$0a,$50,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 557 : 1674
	db	$fc,$05,$4a,$02,$fc,$03,$50,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 559 : 1803
	db	$fc,$02,$51,$03,$fc,$26,$55,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 559 : 1818
	db	$fc,$12,$48,$14,$45,$05,$fc,$0f	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 560 : 1863
	db	$47,$15,$fc,$2b,$fc,$26,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 560 : 1921
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 563 : 2104
	db	$fc,$51,$fc,$51,$fc,$29,$48,$3c	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 567 : 2427
	db	$fc,$0a,$33,$06,$fc,$05,$33,$37	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 570 : 2690
	db	$fc,$05,$33,$05,$fc,$05,$48,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 571 : 2766
	db	$fc,$05,$46,$3d,$fc,$0a,$33,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 571 : 2786
	db	$fc,$05,$33,$3b,$fc,$02,$30,$0a	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 572 : 2867
	db	$33,$05,$fc,$05,$45,$1f,$47,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 573 : 2943
	db	$fc,$05,$48,$5b,$fc,$0a,$45,$0a	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 573 : 2989
	db	$48,$05,$fc,$05,$51,$4e,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 575 : 3105
	db	$50,$26,$fc,$02,$4a,$26,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 576 : 3196
	db	$fd,$25,$46,$4e,$fc,$03,$46,$3c	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 577 : 3277
	db	$fc,$0d,$46,$05,$fc,$03,$46,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 579 : 3418
	db	$46,$50,$46,$2a,$45,$0d,$45,$1d	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 580 : 3520
	db	$fd,$26,$44,$15,$4b,$15,$4b,$08	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 582 : 3684
	db	$4b,$03,$4b,$20,$fc,$29,$35,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 583 : 3734
	db	$fc,$05,$3b,$03,$fc,$03,$36,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 584 : 3812
	db	$fc,$02,$46,$03,$fc,$05,$3b,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 584 : 3828
	db	$fc,$03,$35,$05,$fc,$2b,$45,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 584 : 3840
	db	$fc,$05,$4b,$03,$fc,$02,$46,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 585 : 3893
	db	$fc,$05,$53,$03,$fc,$05,$4b,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 585 : 3906
	db	$fc,$03,$45,$02,$fc,$05,$fc,$29	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 585 : 3921
	db	$35,$02,$fc,$05,$3b,$03,$fc,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 586 : 3972
	db	$36,$03,$fc,$05,$46,$02,$fc,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 586 : 3984
	db	$45,$02,$fc,$03,$4b,$05,$fc,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 586 : 4000
	db	$fd,$27,$46,$14,$fc,$08,$53,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 586 : 4012
	db	$fc,$03,$53,$05,$fc,$03,$46,$14	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 586 : 4042
	db	$3b,$14,$40,$08,$fc,$0c,$39,$08	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 587 : 4073
	db	$fc,$0d,$35,$14,$fc,$07,$fd,$26	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 587 : 4121
	db	$34,$03,$fc,$02,$34,$05,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 588 : 4161
	db	$45,$17,$fc,$06,$48,$05,$45,$08	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 588 : 4174
	db	$3a,$02,$fc,$05,$45,$03,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 589 : 4216
	db	$51,$05,$fc,$03,$53,$02,$fc,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 589 : 4229
	db	$47,$02,$fc,$03,$53,$05,$fc,$03	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 589 : 4245
	db	$fd,$27,$40,$03,$40,$05,$fc,$0c	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 589 : 4258
	db	$39,$08,$fc,$0d,$35,$14,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 589 : 4278
	db	$fd,$26,$34,$03,$fc,$02,$34,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 590 : 4326
	db	$fc,$02,$45,$17,$fc,$05,$48,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 590 : 4337
	db	$45,$08,$3a,$03,$fc,$05,$45,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 590 : 4372
	db	$fc,$03,$51,$05,$fc,$03,$53,$02	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 591 : 4390
	db	$fc,$06,$47,$02,$fc,$03,$53,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 591 : 4403
	db	$fc,$02,$45,$0e,$45,$14,$45,$25	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 591 : 4420
	db	$45,$17,$45,$04,$45,$19,$fc,$21	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 592 : 4493
	db	$fc,$0f
song_000_07_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_07_lp)*2
	dw	song_000_07_lp


song_000_08:	;Trk I
	db	$fc,$51,$fd,$26,$fe,$06,$2b,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 595 : 0
	db	$fc,$05,$43,$03,$fc,$03,$3b,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 596 : 83
	db	$fc,$02,$43,$03,$fc,$05,$43,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 596 : 99
	db	$fc,$03,$3b,$05,$fc,$2b,$3b,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 596 : 111
	db	$fc,$05,$53,$03,$fc,$02,$4b,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 597 : 164
	db	$56,$03,$fc,$05,$53,$02,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 597 : 182
	db	$4b,$02,$fc,$2e,$2b,$02,$fc,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 597 : 195
	db	$43,$03,$fc,$02,$3b,$08,$43,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 598 : 250
	db	$fc,$06,$4b,$02,$fc,$03,$53,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 598 : 265
	db	$fc,$02,$fd,$27,$4b,$14,$fc,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 598 : 281
	db	$56,$02,$fc,$03,$56,$05,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 598 : 311
	db	$4b,$14,$2b,$14,$fc,$28,$fc,$1c	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 599 : 324
	db	$fd,$26,$37,$03,$fc,$02,$37,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 600 : 432
	db	$fc,$03,$fd,$27,$41,$17,$fc,$11	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 600 : 442
	db	$fd,$26,$53,$03,$fc,$05,$50,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 601 : 485
	db	$fc,$02,$41,$05,$fc,$03,$40,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 601 : 496
	db	$fc,$05,$52,$03,$fc,$02,$43,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 601 : 508
	db	$fc,$03,$55,$07,$fc,$21,$fc,$51	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 601 : 523
	db	$fc,$29,$25,$1e,$29,$03,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 603 : 647
	db	$fd,$27,$40,$3d,$fc,$0a,$fd,$26	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 604 : 728
	db	$23,$02,$fc,$08,$43,$19,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 604 : 799
	db	$fd,$27,$42,$02,$fc,$03,$41,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 605 : 837
	db	$fc,$02,$fd,$26,$40,$9b,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 605 : 847
	db	$25,$0a,$fc,$03,$29,$05,$fc,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 607 : 1011
	db	$fd,$27,$40,$72,$fc,$08,$fd,$26	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 607 : 1031
	db	$2a,$07,$27,$03,$fc,$02,$2a,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 609 : 1153
	db	$fd,$27,$40,$72,$fc,$07,$fd,$26	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 609 : 1173
	db	$40,$05,$fc,$03,$40,$02,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 611 : 1294
	db	$3a,$08,$4a,$02,$fc,$05,$50,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 611 : 1307
	db	$fc,$02,$56,$08,$40,$02,$fc,$12	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 611 : 1325
	db	$45,$0d,$fc,$07,$49,$03,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 611 : 1355
	db	$50,$02,$fc,$06,$55,$02,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 612 : 1388
	db	$40,$08,$43,$02,$fc,$26,$53,$19	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 612 : 1408
	db	$fc,$03,$52,$03,$fc,$02,$51,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 613 : 1481
	db	$fc,$05,$50,$02,$fc,$05,$50,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 613 : 1492
	db	$fc,$02,$4b,$08,$50,$02,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 613 : 1507
	db	$3a,$06,$fc,$02,$50,$03,$fc,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 613 : 1529
	db	$51,$02,$fc,$03,$50,$02,$fc,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 614 : 1545
	db	$51,$0d,$50,$02,$fc,$06,$36,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 614 : 1557
	db	$fc,$05,$36,$03,$fc,$02,$36,$12	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 614 : 1580
	db	$fc,$0a,$38,$03,$fc,$05,$38,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 614 : 1608
	db	$fc,$03,$38,$11,$fc,$03,$38,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 615 : 1628
	db	$fc,$2e,$fc,$51,$fc,$51,$fc,$28	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 615 : 1653
	db	$42,$05,$fc,$0f,$3b,$15,$fc,$2b	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 618 : 1901
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 619 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 623 : 2266
	db	$fc,$29,$38,$3c,$fc,$0a,$40,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 627 : 2589
	db	$fc,$05,$40,$37,$fc,$05,$40,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 628 : 2706
	db	$fc,$05,$38,$05,$fc,$05,$4a,$3d	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 629 : 2776
	db	$fc,$0a,$36,$05,$fc,$05,$36,$3b	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 630 : 2852
	db	$fc,$02,$40,$0a,$43,$05,$fc,$2e	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 631 : 2931
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$29	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 632 : 2994
	db	$fd,$25,$4a,$4e,$fc,$03,$4a,$3c	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 635 : 3277
	db	$fc,$0d,$4a,$05,$fc,$03,$49,$51	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 637 : 3418
	db	$49,$50,$4a,$2a,$4a,$0d,$4a,$1d	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 638 : 3520
	db	$fd,$26,$4a,$15,$53,$15,$40,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 640 : 3684
	db	$40,$03,$40,$0b,$3b,$15,$fc,$29	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 641 : 3734
	db	$2b,$02,$fc,$05,$43,$03,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 642 : 3810
	db	$3b,$05,$fc,$02,$43,$03,$fc,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 642 : 3823
	db	$43,$02,$fc,$03,$3b,$05,$fc,$2b	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 642 : 3838
	db	$3b,$02,$fc,$05,$53,$03,$fc,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 643 : 3891
	db	$4b,$08,$56,$03,$fc,$05,$53,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 643 : 3903
	db	$fc,$03,$4b,$02,$fc,$05,$fc,$29	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 643 : 3921
	db	$2b,$02,$fc,$05,$43,$03,$fc,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 644 : 3972
	db	$3b,$08,$43,$02,$fc,$06,$4b,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 644 : 3984
	db	$fc,$03,$53,$05,$fc,$02,$fd,$27	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 644 : 4002
	db	$4b,$14,$fc,$08,$56,$02,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 644 : 4012
	db	$56,$05,$fc,$03,$4b,$14,$2b,$14	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 644 : 4045
	db	$fc,$29,$fc,$1b,$fd,$26,$37,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 645 : 4093
	db	$fc,$02,$37,$05,$fc,$03,$50,$17	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 646 : 4164
	db	$fc,$13,$53,$02,$fc,$05,$50,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 646 : 4197
	db	$fc,$03,$41,$05,$fc,$03,$40,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 647 : 4226
	db	$fc,$06,$52,$02,$fc,$03,$43,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 647 : 4239
	db	$fc,$06,$fc,$05,$fc,$21,$fc,$1b	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 647 : 4255
	db	$37,$03,$fc,$02,$37,$06,$fc,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 648 : 4326
	db	$fd,$25,$50,$17,$fc,$12,$fd,$26	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 648 : 4339
	db	$53,$03,$fc,$05,$50,$02,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 649 : 4380
	db	$41,$05,$fc,$03,$40,$02,$fc,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 649 : 4393
	db	$52,$02,$fc,$03,$43,$06,$fc,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 649 : 4409
	db	$49,$0e,$49,$14,$49,$25,$49,$17	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 649 : 4422
	db	$49,$04,$35,$19,$fc,$21,$fc,$0f	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 650 : 4516

song_000_08_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_08_lp)*2
	dw	song_000_08_lp


song_000_09:	;Trk J
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 653 : 0
	db	$fd,$27,$fe,$06,$56,$14,$fc,$15	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 656 : 283
	db	$56,$14,$43,$14,$fc,$28,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 657 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 659 : 485
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 663 : 809
	db	$fc,$50,$fc,$51,$fc,$29,$fd,$26	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 667 : 1133
	db	$49,$02,$fc,$12,$49,$0d,$fc,$07	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 669 : 1335
	db	$39,$03,$fc,$0a,$40,$02,$fc,$42	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 670 : 1375
	db	$fc,$49,$53,$06,$fc,$02,$40,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 671 : 1456
	db	$fc,$05,$41,$02,$fc,$03,$40,$02	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 672 : 1540
	db	$fc,$05,$41,$0d,$40,$02,$fc,$06	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 672 : 1552
	db	$43,$02,$fc,$05,$43,$03,$fc,$02	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 672 : 1578
	db	$43,$12,$fc,$0a,$43,$03,$fc,$05	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 672 : 1590
	db	$43,$02,$fc,$03,$43,$11,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 673 : 1626
	db	$43,$02,$fc,$2e,$fc,$51,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 673 : 1651
	db	$fc,$51,$fc,$2b,$fc,$26,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 676 : 1861
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 679 : 2104
	db	$fc,$51,$fc,$51,$fc,$29,$40,$3f	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 683 : 2427
	db	$fc,$07,$43,$06,$fc,$05,$43,$37	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 686 : 2693
	db	$fc,$05,$43,$05,$fc,$05,$43,$05	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 687 : 2766
	db	$fc,$05,$3a,$3d,$fc,$0a,$43,$05	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 687 : 2786
	db	$fc,$05,$43,$3b,$fc,$3f,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 688 : 2867
	db	$fc,$51,$fc,$50,$fc,$29,$fd,$25	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 691 : 3075
	db	$50,$4e,$fc,$03,$50,$3c,$fc,$0d	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 693 : 3277
	db	$51,$05,$fc,$03,$50,$51,$50,$50	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 695 : 3431
	db	$50,$2a,$51,$0d,$51,$1d,$fd,$26	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 697 : 3600
	db	$52,$15,$43,$15,$55,$08,$55,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 698 : 3684
	db	$55,$0b,$56,$15,$fc,$29,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 699 : 3737
	db	$fc,$28,$fc,$29,$fc,$28,$fd,$27	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 701 : 3891
	db	$56,$14,$fc,$15,$56,$14,$43,$14	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 702 : 4012
	db	$fc,$29,$fc,$28,$fc,$2a,$fc,$07	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 703 : 4093
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 705 : 4223
	db	$fc,$1e,$fc,$33,$fc,$03,$fc,$12	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 706 : 4299
	db	$fc,$15,$55,$0e,$55,$14,$55,$25	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 707 : 4401
	db	$55,$17,$55,$04,$fc,$3a,$fc,$0f	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 708 : 4493

song_000_09_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_09_lp)*2
	dw	song_000_09_lp


song_000_10:	;Trk K
	db	$fc,$28,$fd,$28,$fe,$03,$25,$29	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 711 : 0
	db	$1b,$28,$25,$29,$1b,$28,$25,$29	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 712 : 81
	db	$1b,$28,$1b,$14,$fc,$08,$1b,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 714 : 243
	db	$fc,$03,$1b,$03,$fc,$05,$26,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 714 : 313
	db	$1b,$14,$fc,$28,$fc,$29,$21,$19	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 715 : 344
	db	$fc,$03,$28,$05,$25,$07,$2a,$1a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 716 : 470
	db	$fc,$02,$27,$05,$23,$08,$15,$9a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 717 : 511
	db	$fc,$08,$25,$1e,$20,$03,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 719 : 680
	db	$15,$29,$17,$50,$18,$51,$1a,$29	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 720 : 728
	db	$17,$21,$16,$07,$15,$51,$23,$29	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 723 : 971
	db	$1a,$28,$21,$51,$20,$28,$26,$29	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 725 : 1133
	db	$15,$07,$fc,$0d,$15,$14,$fc,$29	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 727 : 1335
	db	$23,$02,$fc,$05,$27,$03,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 728 : 1416
	db	$23,$14,$fc,$29,$21,$07,$fc,$0d	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 728 : 1436
	db	$21,$14,$fc,$29,$20,$07,$2a,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 729 : 1517
	db	$26,$14,$fc,$08,$26,$08,$33,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 730 : 1590
	db	$30,$14,$2b,$07,$25,$08,$fc,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 731 : 1631
	db	$20,$05,$fc,$03,$25,$0c,$29,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 731 : 1671
	db	$fc,$03,$fc,$14,$29,$14,$23,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 731 : 1696
	db	$fc,$05,$23,$02,$fc,$03,$22,$08	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 732 : 1742
	db	$23,$14,$fc,$28,$21,$14,$fc,$0d	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 732 : 1760
	db	$28,$05,$fc,$03,$30,$14,$28,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 733 : 1853
	db	$27,$08,$fc,$0c,$22,$15,$24,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 734 : 1901
	db	$20,$14,$18,$03,$18,$63,$fc,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 735 : 1962
	db	$fc,$14,$17,$14,$16,$7a,$fc,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 737 : 2104
	db	$20,$14,$25,$79,$fc,$29,$14,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 739 : 2286
	db	$18,$0a,$24,$0a,$23,$0a,$21,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 741 : 2478
	db	$23,$0b,$21,$0a,$1b,$0a,$1a,$28	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 742 : 2518
	db	$19,$29,$18,$0a,$23,$0a,$30,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 743 : 2589
	db	$2a,$0a,$28,$0a,$2a,$0a,$28,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 743 : 2660
	db	$27,$0b,$23,$41,$fc,$05,$22,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 744 : 2700
	db	$16,$0b,$21,$0a,$2a,$0a,$28,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 745 : 2791
	db	$26,$0a,$28,$0a,$26,$0a,$25,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 746 : 2832
	db	$23,$51,$fc,$29,$fc,$51,$fc,$51	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 746 : 2872
	db	$fc,$50,$fc,$29,$23,$9f,$fc,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 750 : 3156
	db	$28,$9f,$fc,$02,$2a,$28,$fc,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 753 : 3439
	db	$29,$0d,$29,$1a,$fc,$03,$28,$12	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 756 : 3642
	db	$fc,$03,$27,$13,$fc,$02,$26,$08	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 756 : 3702
	db	$26,$03,$26,$0b,$25,$05,$fc,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 757 : 3734
	db	$1b,$05,$18,$08,$25,$29,$1b,$28	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 757 : 3756
	db	$25,$29,$1b,$28,$25,$29,$1b,$28	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 758 : 3850
	db	$1b,$14,$fc,$08,$1b,$02,$fc,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 760 : 4012
	db	$1b,$05,$fc,$03,$26,$14,$1b,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 760 : 4045
	db	$fc,$29,$fc,$28,$21,$1d,$28,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 761 : 4093
	db	$25,$08,$2a,$07,$2a,$16,$27,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 762 : 4208
	db	$27,$03,$23,$08,$fc,$03,$fc,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 763 : 4247
	db	$fc,$21,$fc,$1e,$fc,$0a,$21,$1c	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 763 : 4266
	db	$28,$05,$25,$08,$2a,$03,$2a,$12	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 764 : 4367
	db	$2a,$08,$27,$05,$23,$08,$15,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 765 : 4401
	db	$fc,$0b,$15,$06,$fc,$02,$15,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 765 : 4425
	db	$fc,$09,$fc,$03,$15,$06,$fc,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 765 : 4447
	db	$15,$04,$fc,$0c,$15,$06,$fc,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 766 : 4468
	db	$15,$04,$fc,$06,$15,$04,$fc,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 766 : 4493
	db	$15,$06,$fc,$04,$15,$19,$fc,$21	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 766 : 4510
	db	$fc,$0f
song_000_10_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_10_lp)*2
	dw	song_000_10_lp


song_000_11:	;Trk L
	db	$fc,$28,$fd,$2b,$fe,$07,$4b,$33	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 769 : 0
	db	$fc,$0a,$4b,$03,$fc,$0a,$4b,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 770 : 91
	db	$fc,$05,$4b,$33,$fc,$0a,$4b,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 770 : 116
	db	$fc,$0a,$4b,$02,$fc,$05,$4b,$33	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 771 : 185
	db	$fc,$0a,$4b,$02,$fc,$0b,$4b,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 772 : 253
	db	$fc,$05,$4b,$33,$fc,$0a,$4b,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 772 : 278
	db	$fc,$12,$45,$05,$fc,$0f,$39,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 773 : 346
	db	$fc,$03,$50,$02,$fc,$03,$50,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 773 : 389
	db	$fc,$05,$35,$15,$35,$14,$35,$28	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 773 : 399
	db	$3a,$1f,$37,$0a,$fd,$2a,$65,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 775 : 485
	db	$fc,$02,$60,$05,$57,$08,$55,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 775 : 531
	db	$fc,$03,$50,$05,$47,$07,$45,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 775 : 551
	db	$fc,$03,$40,$05,$39,$08,$35,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 776 : 571
	db	$fc,$02,$40,$05,$39,$08,$45,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 776 : 592
	db	$fc,$02,$fd,$29,$50,$05,$fd,$2a	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 776 : 612
	db	$49,$08,$55,$05,$fc,$03,$fd,$29	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 776 : 619
	db	$60,$05,$fd,$2a,$59,$07,$65,$14	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 776 : 635
	db	$fc,$3d,$fc,$21,$fd,$2b,$49,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 777 : 667
	db	$fc,$03,$50,$50,$fc,$29,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 778 : 766
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 781 : 971
	db	$fc,$29,$35,$21,$39,$05,$fc,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 785 : 1294
	db	$40,$4a,$fc,$07,$43,$1c,$42,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 786 : 1375
	db	$fc,$02,$41,$05,$fc,$03,$40,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 787 : 1487
	db	$fc,$28,$fc,$28,$fd,$2c,$45,$08	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 788 : 1578
	db	$fc,$05,$fd,$2b,$49,$05,$fc,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 789 : 1666
	db	$50,$74,$fc,$05,$53,$03,$fc,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 789 : 1679
	db	$52,$02,$fc,$03,$53,$05,$fc,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 791 : 1808
	db	$45,$1f,$fc,$02,$48,$03,$fc,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 791 : 1820
	db	$45,$3c,$3b,$15,$44,$28,$18,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 792 : 1861
	db	$18,$81,$fc,$0a,$17,$12,$fc,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 793 : 1985
	db	$16,$77,$fc,$03,$fc,$14,$20,$14	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 795 : 2144
	db	$15,$a2,$14,$51,$1a,$28,$19,$29	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 797 : 2306
	db	$18,$51,$fc,$28,$fc,$28,$16,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 801 : 2630
	db	$fc,$29,$fc,$51,$fc,$51,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 804 : 2872
	db	$fc,$50,$fc,$51,$fd,$2a,$5a,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 808 : 3156
	db	$fc,$03,$56,$05,$51,$08,$50,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 810 : 3322
	db	$fc,$02,$4a,$05,$46,$08,$43,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 810 : 3343
	db	$fc,$02,$3a,$05,$43,$08,$4a,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 810 : 3363
	db	$fc,$03,$46,$05,$5a,$35,$fc,$23	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 810 : 3383
	db	$59,$08,$56,$05,$51,$07,$50,$08	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 812 : 3479
	db	$49,$05,$46,$08,$43,$07,$39,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 812 : 3507
	db	$41,$08,$49,$07,$43,$05,$59,$2e	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 812 : 3532
	db	$fc,$02,$1a,$28,$fc,$02,$19,$0d	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 813 : 3598
	db	$19,$1a,$fc,$03,$18,$12,$fc,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 814 : 3655
	db	$17,$13,$fc,$02,$fd,$2b,$16,$08	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 814 : 3705
	db	$16,$03,$16,$0b,$fd,$2a,$15,$15	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 815 : 3734
	db	$fd,$2b,$4b,$33,$fc,$0a,$4b,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 815 : 3769
	db	$fc,$0a,$4b,$05,$fc,$02,$4b,$33	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 816 : 3833
	db	$fc,$0a,$4b,$03,$fc,$0a,$4b,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 817 : 3901
	db	$fc,$02,$4b,$33,$fc,$0a,$4b,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 817 : 3929
	db	$fc,$0b,$4b,$05,$fc,$02,$4b,$33	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 818 : 3994
	db	$fc,$0a,$fd,$2c,$4b,$02,$fc,$0a	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 819 : 4063
	db	$4b,$06,$fc,$02,$fd,$2b,$45,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 819 : 4085
	db	$fc,$0f,$39,$05,$fc,$03,$50,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 819 : 4098
	db	$fc,$03,$50,$02,$fc,$06,$35,$14	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 819 : 4123
	db	$35,$14,$fd,$2c,$35,$2a,$3a,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 820 : 4154
	db	$3a,$18,$37,$0b,$fd,$2b,$45,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 821 : 4223
	db	$45,$02,$fc,$03,$fc,$0c,$39,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 821 : 4261
	db	$fc,$03,$50,$02,$fc,$03,$50,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 821 : 4283
	db	$fc,$05,$fd,$2c,$35,$14,$35,$0a	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 821 : 4294
	db	$35,$0a,$35,$29,$fd,$2b,$3a,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 822 : 4329
	db	$3a,$12,$3a,$0a,$37,$09,$fc,$02	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 823 : 4383
	db	$fd,$2c,$35,$0e,$35,$14,$35,$25	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 823 : 4422
	db	$35,$17,$35,$04,$fd,$2b,$35,$16	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 824 : 4493
	db	$fc,$24,$fc,$0f
song_000_11_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_11_lp)*2
	dw	song_000_11_lp


song_000_12:	;Trk M
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 827 : 0
	db	$fc,$28,$fb,$03,$fd,$0e,$fe,$00	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 831 : 324
	db	$35,$05,$fc,$0f,$43,$05,$fc,$0f	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 831 : 364
	db	$50,$15,$fc,$07,$45,$03,$fc,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 832 : 404
	db	$45,$03,$fc,$05,$41,$28,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 832 : 437
	db	$fc,$51,$fc,$51,$fc,$21,$37,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 834 : 566
	db	$fc,$03,$fd,$0d,$40,$50,$fc,$29	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 836 : 766
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 838 : 890
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 842 : 1213
	db	$fc,$51,$fc,$28,$fd,$0f,$35,$08	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 846 : 1537
	db	$fc,$05,$fd,$0e,$39,$05,$fc,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 847 : 1666
	db	$40,$74,$fc,$05,$43,$03,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 847 : 1679
	db	$42,$02,$fc,$03,$43,$05,$fc,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 849 : 1808
	db	$41,$1f,$fc,$02,$58,$05,$fc,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 849 : 1820
	db	$40,$28,$42,$08,$fc,$21,$37,$28	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 850 : 1861
	db	$fc,$03,$fc,$26,$fc,$51,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 851 : 1982
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 854 : 2185
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 858 : 2508
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 862 : 2832
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 866 : 3156
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 870 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 872 : 3655
	db	$fc,$29,$fc,$51,$fc,$28,$fc,$29	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 873 : 3769
	db	$fc,$51,$fc,$28,$35,$05,$fc,$0f	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 876 : 3972
	db	$43,$05,$fc,$10,$50,$14,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 877 : 4113
	db	$45,$03,$fc,$02,$45,$03,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 878 : 4161
	db	$fd,$0f,$41,$2a,$fc,$07,$fc,$18	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 878 : 4174
	db	$fc,$0b,$fd,$0e,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 879 : 4247
	db	$fc,$03,$fc,$0c,$43,$05,$fc,$10	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 879 : 4263
	db	$50,$14,$fc,$07,$45,$03,$fc,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 880 : 4299
	db	$45,$03,$fc,$05,$fd,$0f,$41,$29	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 880 : 4331
	db	$fc,$03,$fc,$12,$fc,$23,$fc,$14	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 881 : 4380
	db	$fc,$0c,$fc,$19,$fc,$17,$fc,$3e	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 881 : 4456
	db	$fc,$0f
song_000_12_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_12_lp)*2
	dw	song_000_12_lp


song_000_13:	;Trk N
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 885 : 0
	db	$fc,$28,$fb,$03,$fd,$0e,$fe,$00	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 889 : 324
	db	$50,$14,$fc,$14,$40,$15,$fc,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 889 : 364
	db	$50,$03,$fc,$02,$50,$03,$fc,$2d	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 890 : 432
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 891 : 485
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 895 : 809
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 899 : 1133
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 903 : 1456
	db	$fc,$28,$55,$1f,$fc,$02,$45,$05	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 907 : 1780
	db	$fc,$03,$55,$51,$50,$28,$fc,$03	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 907 : 1858
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 909 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 913 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 917 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 921 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 925 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 929 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 931 : 3726
	db	$fc,$51,$fc,$28,$fc,$29,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 932 : 3810
	db	$fc,$28,$50,$14,$fc,$15,$40,$14	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 935 : 4053
	db	$fc,$07,$50,$03,$fc,$02,$50,$03	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 936 : 4154
	db	$fc,$05,$fc,$2a,$fc,$07,$fc,$18	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 936 : 4169
	db	$fc,$0b,$50,$03,$50,$05,$50,$0c	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 937 : 4247
	db	$fc,$15,$fd,$0f,$40,$14,$fc,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 937 : 4278
	db	$fd,$0e,$50,$03,$fc,$02,$50,$03	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 938 : 4326
	db	$fc,$2e,$fc,$03,$fc,$12,$fc,$23	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 938 : 4334
	db	$fc,$14,$fc,$0c,$fc,$19,$fc,$17	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 939 : 4436
	db	$fc,$3e,$fc,$0f
song_000_13_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_13_lp)*2
	dw	song_000_13_lp


song_000_14:	;Trk O
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 943 : 0
	db	$fc,$28,$fb,$03,$fd,$22,$40,$05	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 947 : 324
	db	$fc,$23,$fc,$1c,$fd,$23,$40,$03	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 947 : 369
	db	$fc,$02,$fd,$21,$40,$03,$fc,$2d	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 948 : 435
	db	$fc,$51,$fc,$51,$fc,$51,$ee
	db	bank(song_000_14_bnk003)*2
	dw	song_000_14_bnk003

	.bank	3
	.org	$e000
song_000_14_bnk003:
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 952 : 728
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 956 : 1052
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 960 : 1375
	db	$fc,$51,$fc,$51,$fc,$51,$57,$28	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 964 : 1699
	db	$fc,$03,$fc,$26,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 967 : 1982
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 970 : 2185
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 974 : 2508
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 978 : 2832
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 982 : 3156
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 986 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 988 : 3655
	db	$fc,$29,$fc,$51,$fc,$28,$fc,$29	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 989 : 3769
	db	$fc,$51,$fc,$28,$fd,$22,$40,$05	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 992 : 3972
	db	$fc,$24,$fc,$1b,$fd,$23,$40,$03	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 993 : 4098
	db	$fc,$02,$fd,$20,$40,$03,$fc,$05	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 994 : 4164
	db	$fc,$2a,$fc,$07,$fc,$18,$fc,$0b	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 994 : 4174
	db	$fd,$22,$40,$03,$40,$02,$fc,$03	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 995 : 4258
	db	$fc,$21,$fc,$1b,$40,$03,$fc,$02	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 995 : 4266
	db	$fd,$20,$40,$03,$fc,$2e,$fc,$03	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 996 : 4331
	db	$fc,$12,$fc,$23,$fc,$14,$fc,$0c	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 997 : 4383
	db	$fc,$19,$fc,$17,$fc,$3e,$fc,$0f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 998 : 4468

song_000_14_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_14_lp)*2
	dw	song_000_14_lp


song_000_15:	;Trk P
	db	$fc,$28,$fb,$04,$ef,$07,$fd,$11	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1001 : 0
	db	$fe,$00,$45,$29,$2b,$28,$45,$29	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1001 : 40
	db	$2b,$28,$45,$29,$2b,$28,$2b,$17	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1003 : 162
	db	$fc,$05,$2b,$02,$fc,$03,$2b,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1004 : 306
	db	$fc,$05,$46,$26,$fc,$2a,$fc,$29	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1004 : 319
	db	$35,$26,$fc,$02,$33,$15,$3a,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1006 : 445
	db	$45,$0c,$fc,$1c,$fc,$51,$fc,$29	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1007 : 526
	db	$45,$1b,$fc,$03,$49,$03,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1009 : 688
	db	$40,$3d,$fc,$0a,$43,$02,$fc,$08	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1010 : 728
	db	$43,$1c,$fd,$10,$42,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1011 : 809
	db	$41,$05,$fc,$02,$fd,$11,$40,$9b	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1011 : 842
	db	$fc,$07,$45,$0d,$49,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1013 : 1004
	db	$40,$72,$fc,$08,$4a,$07,$47,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1013 : 1031
	db	$fc,$02,$4a,$08,$40,$72,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1015 : 1163
	db	$3a,$1c,$fc,$03,$36,$0a,$40,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1017 : 1294
	db	$fc,$12,$40,$14,$fc,$29,$33,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1017 : 1337
	db	$fc,$0a,$37,$05,$fc,$03,$33,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1018 : 1418
	db	$fc,$29,$31,$02,$fc,$12,$31,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1019 : 1456
	db	$fc,$29,$30,$02,$fc,$05,$3a,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1020 : 1537
	db	$fc,$02,$36,$05,$fc,$17,$36,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1020 : 1588
	db	$fc,$05,$43,$02,$fc,$03,$36,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1021 : 1621
	db	$38,$07,$35,$03,$fc,$0a,$30,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1021 : 1651
	db	$fc,$03,$35,$14,$fc,$14,$39,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1021 : 1676
	db	$33,$03,$fc,$05,$33,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1022 : 1739
	db	$32,$08,$33,$14,$fc,$28,$31,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1022 : 1752
	db	$fc,$0d,$38,$05,$fc,$03,$40,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1023 : 1840
	db	$38,$14,$37,$05,$fc,$24,$fc,$2b	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1024 : 1881
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1025 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1029 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1033 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1037 : 2913
	db	$fc,$29,$33,$8d,$fc,$15,$38,$8d	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1041 : 3236
	db	$fc,$14,$fc,$2a,$fc,$0d,$fc,$47	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1045 : 3580
	db	$fc,$08,$fc,$03,$fc,$20,$45,$29	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1047 : 3726
	db	$2b,$28,$45,$29,$2b,$14,$fc,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1048 : 3810
	db	$45,$29,$2b,$14,$fc,$14,$2b,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1049 : 3931
	db	$fc,$08,$fc,$05,$2b,$03,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1050 : 4032
	db	$46,$28,$fc,$29,$fc,$28,$35,$27	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1051 : 4053
	db	$fc,$03,$33,$07,$33,$0e,$3a,$0a	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1052 : 4213
	db	$3a,$0b,$fc,$03,$fc,$05,$fc,$21	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1053 : 4247
	db	$fc,$1e,$fc,$0a,$35,$26,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1054 : 4299
	db	$33,$03,$33,$12,$3a,$15,$35,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1055 : 4380
	db	$35,$14,$35,$25,$35,$17,$35,$04	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1055 : 4436
	db	$35,$19,$fc,$21,$fc,$0f
song_000_15_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_15_lp)*2
	dw	song_000_15_lp


song_000_16:	;Trk Q
	db	$fc,$51,$fb,$04,$ef,$07,$fd,$11	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1059 : 0
	db	$fe,$01,$3b,$28,$3b,$29,$3b,$28	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1060 : 81
	db	$35,$29,$35,$28,$3b,$17,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1061 : 202
	db	$3b,$02,$fc,$03,$3b,$03,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1062 : 311
	db	$36,$26,$fc,$2a,$fc,$51,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1063 : 324
	db	$fc,$51,$fc,$29,$35,$1b,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1066 : 566
	db	$39,$03,$fc,$07,$50,$3d,$fc,$0a	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1067 : 718
	db	$33,$02,$fc,$08,$53,$1c,$52,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1068 : 799
	db	$fc,$03,$51,$05,$fc,$02,$50,$9b	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1069 : 839
	db	$fc,$07,$35,$0d,$39,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1071 : 1004
	db	$50,$72,$fc,$08,$3a,$07,$37,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1071 : 1031
	db	$fc,$02,$3a,$08,$50,$72,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1073 : 1163
	db	$fc,$29,$35,$02,$fc,$12,$35,$14	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1075 : 1294
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1076 : 1375
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$2b	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1080 : 1699
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1083 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1087 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1091 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1095 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1099 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1103 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1105 : 3726
	db	$3b,$28,$3b,$29,$3b,$14,$fc,$14	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1106 : 3810
	db	$35,$29,$35,$14,$fc,$14,$3b,$14	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1107 : 3931
	db	$fc,$15,$36,$28,$fc,$29,$fc,$28	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1108 : 4032
	db	$fc,$2a,$fc,$07,$fc,$18,$fc,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1110 : 4174
	db	$fc,$05,$fc,$21,$fc,$1e,$fc,$33	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1111 : 4261
	db	$fc,$03,$fc,$12,$fc,$23,$fc,$14	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1113 : 4380
	db	$fc,$0c,$fc,$19,$fc,$17,$fc,$3e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1113 : 4456
	db	$fc,$0f
song_000_16_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_16_lp)*2
	dw	song_000_16_lp


song_000_17:	;Trk R
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1117 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1121 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1125 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$29	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1129 : 971
	db	$fb,$04,$ef,$07,$fd,$11,$fe,$02	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1132 : 1254
	db	$30,$21,$fc,$07,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1132 : 1254
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1135 : 1456
	db	$fc,$51,$fc,$51,$fc,$2b,$fc,$26	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1139 : 1780
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1142 : 2023
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1146 : 2347
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1150 : 2670
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1154 : 2994
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1158 : 3317
	db	$fc,$2a,$fc,$0d,$fc,$47,$fc,$08	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1161 : 3600
	db	$fc,$03,$fc,$20,$fc,$29,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1163 : 3734
	db	$fc,$28,$fc,$29,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1165 : 3891
	db	$fc,$28,$fc,$2a,$fc,$07,$fc,$18	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1168 : 4134
	db	$fc,$0e,$fc,$05,$fc,$21,$fc,$1e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1169 : 4247
	db	$fc,$33,$fc,$03,$fc,$12,$fc,$23	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1170 : 4329
	db	$fc,$14,$fc,$0c,$fc,$19,$fc,$17	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1171 : 4436
	db	$fc,$3e,$fc,$0f
song_000_17_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_17_lp)*2
	dw	song_000_17_lp


song_000_18:	;Trk S
	db	$fc,$14,$fb,$05,$ef,$07,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1175 : 0
	db	$fe,$03,$5a,$05,$fc,$03,$55,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1175 : 20
	db	$4a,$07,$45,$03,$fd,$04,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1175 : 33
	db	$fc,$02,$45,$03,$45,$02,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1175 : 46
	db	$fc,$02,$45,$03,$45,$02,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1175 : 56
	db	$fc,$02,$fd,$05,$45,$03,$fd,$04	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1175 : 66
	db	$45,$02,$fd,$05,$45,$03,$fc,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1175 : 71
	db	$4b,$26,$fc,$02,$45,$03,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1176 : 81
	db	$fc,$03,$fd,$04,$45,$02,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1176 : 126
	db	$45,$03,$fc,$02,$45,$03,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1176 : 134
	db	$45,$03,$fc,$02,$fd,$05,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1176 : 144
	db	$fd,$04,$45,$02,$fd,$05,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1176 : 152
	db	$fc,$05,$4b,$26,$fc,$02,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1176 : 157
	db	$45,$02,$fc,$03,$fd,$04,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1177 : 205
	db	$45,$03,$45,$02,$fc,$03,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1177 : 212
	db	$45,$03,$fd,$05,$45,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1177 : 222
	db	$fd,$04,$45,$03,$fd,$05,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1177 : 230
	db	$fd,$04,$45,$03,$fc,$05,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1177 : 235
	db	$4b,$26,$fc,$02,$45,$17,$fc,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1178 : 243
	db	$4a,$02,$fc,$03,$4a,$03,$fc,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1178 : 311
	db	$55,$11,$fc,$03,$4b,$12,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1179 : 324
	db	$40,$17,$fc,$11,$fc,$29,$40,$19	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1179 : 364
	db	$fc,$03,$fd,$04,$57,$02,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1180 : 470
	db	$57,$02,$fc,$05,$fd,$05,$4b,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1180 : 478
	db	$4b,$02,$fc,$03,$4b,$03,$fd,$04	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1181 : 488
	db	$4b,$02,$fd,$05,$4b,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1181 : 496
	db	$4b,$03,$4b,$02,$4b,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1181 : 503
	db	$4b,$03,$4b,$02,$4b,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1181 : 513
	db	$4b,$03,$44,$3d,$fc,$3c,$fc,$29	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1181 : 523
	db	$44,$3c,$fc,$3d,$fc,$51,$fc,$51	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1183 : 688
	db	$fc,$14,$fb,$06,$fd,$14,$fe,$04	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1187 : 971
	db	$59,$05,$fc,$03,$5a,$05,$54,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1187 : 991
	db	$55,$0d,$57,$02,$fc,$05,$fd,$13	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1187 : 1011
	db	$55,$72,$fc,$08,$fd,$14,$5a,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1187 : 1031
	db	$fc,$02,$57,$03,$fc,$02,$5a,$08	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1189 : 1158
	db	$55,$47,$fc,$0a,$fb,$05,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1189 : 1173
	db	$fe,$03,$50,$26,$fc,$02,$44,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1190 : 1254
	db	$44,$02,$fc,$03,$44,$02,$fd,$04	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1191 : 1297
	db	$44,$03,$44,$03,$fc,$02,$44,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1191 : 1304
	db	$44,$02,$fd,$05,$44,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1191 : 1315
	db	$44,$03,$44,$02,$44,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1191 : 1322
	db	$44,$03,$45,$21,$fc,$07,$fc,$29	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1191 : 1332
	db	$48,$05,$fc,$02,$52,$05,$48,$08	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1192 : 1416
	db	$52,$14,$fc,$29,$47,$05,$fc,$0f	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1192 : 1436
	db	$47,$14,$fc,$29,$45,$0a,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1193 : 1517
	db	$45,$14,$fc,$08,$45,$05,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1194 : 1590
	db	$57,$05,$45,$14,$fc,$07,$4b,$0b	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1195 : 1626
	db	$fc,$02,$45,$08,$4b,$14,$fc,$28	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1195 : 1669
	db	$47,$05,$fc,$03,$47,$05,$43,$08	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1196 : 1739
	db	$47,$14,$fc,$51,$fc,$51,$fc,$14	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1196 : 1760
	db	$fb,$06,$fd,$14,$fe,$04,$63,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1199 : 1962
	db	$fc,$03,$fd,$13,$55,$05,$57,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1199 : 1967
	db	$fd,$14,$68,$03,$68,$44,$fd,$13	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1199 : 1982
	db	$63,$05,$fc,$05,$fd,$14,$63,$26	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1200 : 2053
	db	$fc,$03,$63,$14,$fd,$13,$68,$14	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1200 : 2101
	db	$fd,$14,$6a,$42,$fc,$05,$fd,$13	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1201 : 2144
	db	$63,$05,$fc,$05,$fd,$14,$63,$33	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1202 : 2215
	db	$fc,$0a,$70,$0a,$fd,$13,$73,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1203 : 2276
	db	$fc,$05,$fd,$14,$71,$23,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1203 : 2301
	db	$fd,$12,$69,$03,$fd,$14,$68,$5b	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1203 : 2344
	db	$fc,$0a,$fd,$13,$55,$05,$fc,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1205 : 2438
	db	$57,$05,$fc,$05,$69,$02,$fd,$14	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1205 : 2458
	db	$68,$4c,$fc,$03,$6a,$47,$fd,$13	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1205 : 2470
	db	$57,$05,$fc,$05,$71,$02,$fd,$14	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1207 : 2620
	db	$70,$9f,$fc,$29,$fc,$51,$fc,$51	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1207 : 2632
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1212 : 2994
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1216 : 3317
	db	$fc,$2a,$fc,$0d,$fc,$47,$fb,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1219 : 3600
	db	$fd,$04,$fe,$03,$45,$03,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3726
	db	$fc,$03,$45,$03,$45,$02,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3731
	db	$45,$03,$fc,$03,$45,$03,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3739
	db	$45,$03,$fc,$03,$45,$03,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3750
	db	$45,$03,$fc,$03,$45,$02,$45,$08	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3761
	db	$fd,$04,$45,$03,$45,$02,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3777
	db	$45,$03,$fc,$02,$fd,$04,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3782
	db	$fd,$05,$45,$02,$45,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3790
	db	$45,$03,$45,$02,$45,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3797
	db	$45,$03,$4b,$28,$45,$03,$fd,$04	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1221 : 3807
	db	$45,$02,$fc,$03,$fd,$05,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1222 : 3853
	db	$fd,$04,$45,$03,$45,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1222 : 3860
	db	$45,$03,$45,$02,$45,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1222 : 3868
	db	$fd,$05,$45,$03,$45,$02,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1222 : 3878
	db	$fc,$02,$45,$03,$4b,$28,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1222 : 3886
	db	$45,$02,$fc,$03,$45,$02,$fd,$04	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1223 : 3934
	db	$45,$03,$45,$02,$fc,$03,$45,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1223 : 3941
	db	$45,$03,$45,$03,$fc,$02,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1223 : 3951
	db	$45,$03,$fd,$04,$45,$02,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1223 : 3959
	db	$45,$03,$fc,$02,$45,$03,$4b,$28	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1223 : 3964
	db	$45,$12,$fc,$02,$fd,$04,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1224 : 4012
	db	$45,$02,$fc,$03,$fd,$05,$4a,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1224 : 4035
	db	$fc,$03,$4a,$03,$fc,$05,$55,$28	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1224 : 4042
	db	$45,$12,$fc,$17,$fc,$28,$4b,$1a	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1225 : 4093
	db	$fc,$03,$60,$02,$fc,$03,$60,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1226 : 4200
	db	$fc,$06,$41,$07,$41,$0b,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1226 : 4210
	db	$41,$0a,$41,$08,$fc,$03,$45,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1227 : 4237
	db	$45,$05,$45,$0a,$fc,$17,$fc,$1e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1227 : 4261
	db	$fc,$0a,$4b,$1c,$fd,$04,$60,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1228 : 4329
	db	$fc,$02,$60,$03,$fc,$05,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1228 : 4370
	db	$4b,$03,$4b,$02,$fc,$03,$fd,$04	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1229 : 4380
	db	$4b,$02,$4b,$03,$4b,$02,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1229 : 4388
	db	$4b,$03,$4b,$02,$fd,$05,$4b,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1229 : 4398
	db	$fc,$03,$4b,$02,$4b,$03,$4b,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1229 : 4406
	db	$fc,$03,$4b,$02,$45,$0b,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1229 : 4417
	db	$45,$08,$4b,$09,$fc,$03,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1229 : 4436
	db	$45,$09,$45,$04,$fc,$0c,$45,$09	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1229 : 4459
	db	$45,$04,$fc,$06,$45,$04,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1230 : 4493
	db	$45,$03,$fc,$03,$fc,$04,$45,$21	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1230 : 4510
	db	$fc,$19,$fc,$0f
song_000_18_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_18_lp)*2
	dw	song_000_18_lp


song_000_19:	;Trk T
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1233 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1237 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1241 : 647
	db	$fc,$14,$fb,$06,$ef,$07,$fd,$14	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1245 : 971
	db	$fe,$05,$52,$05,$fc,$03,$fd,$13	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1245 : 991
	db	$53,$05,$fd,$14,$5b,$07,$60,$0d	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1245 : 999
	db	$61,$02,$fc,$05,$61,$03,$60,$6f	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1245 : 1024
	db	$fc,$08,$53,$05,$fc,$02,$4a,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1247 : 1145
	db	$fc,$02,$53,$08,$60,$47,$fc,$32	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1247 : 1163
	db	$fc,$51,$fc,$51,$fc,$29,$fb,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1249 : 1294
	db	$fd,$05,$fe,$06,$47,$0a,$fc,$1e	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1251 : 1497
	db	$fc,$30,$55,$05,$fc,$1c,$fc,$51	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1252 : 1537
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$14	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1254 : 1699
	db	$fb,$06,$fd,$13,$fe,$05,$53,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1257 : 1962
	db	$fc,$03,$65,$05,$fd,$14,$67,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1257 : 1967
	db	$fd,$13,$58,$03,$58,$44,$53,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1257 : 1982
	db	$fc,$05,$53,$26,$fc,$03,$53,$14	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1258 : 2058
	db	$58,$14,$5a,$42,$fc,$05,$53,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1259 : 2124
	db	$fc,$05,$53,$33,$fc,$0a,$60,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1260 : 2220
	db	$63,$05,$fc,$05,$61,$23,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1261 : 2296
	db	$fd,$12,$59,$03,$fd,$13,$58,$5b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1261 : 2344
	db	$fc,$0a,$fd,$14,$65,$05,$fc,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1263 : 2438
	db	$fd,$13,$67,$05,$fc,$05,$59,$02	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1263 : 2458
	db	$58,$4c,$fc,$03,$5a,$47,$67,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1263 : 2470
	db	$fc,$05,$61,$02,$60,$9f,$fc,$29	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1265 : 2625
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1268 : 2832
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1272 : 3156
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1276 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1278 : 3655
	db	$fc,$29,$fc,$51,$fc,$28,$fc,$29	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1279 : 3769
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1282 : 3972
	db	$fc,$07,$fc,$18,$fc,$0e,$fc,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1285 : 4216
	db	$fc,$21,$fc,$1e,$fc,$33,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1285 : 4266
	db	$fc,$12,$fc,$23,$fc,$14,$fc,$0c	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1287 : 4383
	db	$fc,$19,$fc,$17,$fc,$3e,$fc,$0f	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1288 : 4468

song_000_19_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_19_lp)*2
	dw	song_000_19_lp


song_000_20:	;Trk U
	db	$fc,$28,$fb,$07,$ef,$07,$fd,$08	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1291 : 0
	db	$fe,$07,$35,$21,$fc,$08,$2b,$1c	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1291 : 40
	db	$fc,$0c,$35,$1c,$fc,$0d,$2b,$1e	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1292 : 109
	db	$fc,$0a,$35,$1c,$fc,$0d,$2b,$1c	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1293 : 192
	db	$fc,$0c,$2b,$14,$fc,$08,$2b,$02	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1294 : 271
	db	$fc,$03,$2b,$05,$fc,$03,$36,$14	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1294 : 313
	db	$fc,$14,$35,$14,$fc,$14,$fc,$29	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1295 : 344
	db	$35,$28,$33,$15,$fc,$14,$35,$14	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1296 : 445
	db	$fc,$14,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1297 : 546
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1301 : 809
	db	$fc,$50,$fc,$29,$30,$28,$36,$1f	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1305 : 1133
	db	$33,$0a,$fc,$28,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1307 : 1325
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1310 : 1537
	db	$fc,$51,$fc,$2b,$fc,$26,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1314 : 1861
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1317 : 2104
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1321 : 2427
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1325 : 2751
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1329 : 3075
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1333 : 3398
	db	$fc,$0d,$fc,$47,$fc,$08,$fc,$03	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1336 : 3642
	db	$fc,$20,$35,$29,$2b,$28,$35,$24	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1337 : 3737
	db	$fc,$05,$2b,$23,$fc,$05,$35,$24	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1338 : 3886
	db	$fc,$05,$2b,$23,$fc,$05,$2b,$12	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1339 : 3967
	db	$fc,$0a,$2b,$02,$fc,$03,$2b,$05	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1340 : 4030
	db	$fc,$03,$36,$14,$fc,$14,$35,$29	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1340 : 4050
	db	$fc,$28,$35,$2a,$33,$07,$33,$0e	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1342 : 4134
	db	$fc,$0a,$fc,$0b,$35,$03,$35,$05	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1343 : 4237
	db	$35,$21,$fc,$1e,$fc,$0a,$35,$29	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1343 : 4266
	db	$33,$03,$33,$12,$fc,$23,$fc,$14	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1345 : 4380
	db	$fc,$0c,$fc,$19,$fc,$17,$fc,$04	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1345 : 4456
	db	$35,$19,$fc,$21,$fc,$0f
song_000_20_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_20_lp)*2
	dw	song_000_20_lp


song_000_21:	;Trk V
	db	$fb,$08,$ef,$07,$fd,$19,$fe,$08	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1349 : 0
	db	$6b,$05,$fc,$03,$5b,$05,$56,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1349 : 0
	db	$56,$05,$fc,$03,$56,$05,$45,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1349 : 20
	db	$45,$29,$45,$28,$45,$29,$45,$28	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1349 : 40
	db	$45,$29,$45,$28,$53,$17,$fc,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1351 : 202
	db	$53,$02,$fc,$03,$fd,$18,$53,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1352 : 311
	db	$fc,$03,$fd,$19,$53,$14,$4b,$14	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1352 : 321
	db	$fc,$28,$fc,$51,$fc,$29,$fd,$18	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1353 : 364
	db	$65,$07,$55,$05,$55,$06,$fc,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1355 : 526
	db	$fd,$17,$55,$05,$fc,$03,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1355 : 546
	db	$55,$05,$fc,$02,$fd,$18,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1355 : 559
	db	$fc,$03,$fd,$17,$55,$05,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1356 : 571
	db	$fc,$03,$fd,$18,$55,$05,$fc,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1356 : 584
	db	$55,$05,$fd,$17,$55,$05,$fc,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1356 : 594
	db	$fd,$18,$55,$05,$fc,$02,$fd,$17	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1356 : 607
	db	$55,$05,$55,$05,$fc,$03,$fd,$18	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1356 : 614
	db	$55,$05,$fc,$03,$55,$05,$fd,$17	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1356 : 627
	db	$55,$05,$fc,$02,$fd,$18,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1356 : 640
	db	$fc,$03,$fd,$17,$55,$05,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1357 : 652
	db	$fc,$02,$fd,$18,$55,$05,$fc,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1357 : 665
	db	$fd,$17,$55,$05,$55,$05,$fc,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1357 : 675
	db	$55,$05,$fc,$02,$55,$05,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1357 : 688
	db	$fc,$03,$fd,$18,$55,$05,$fc,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1357 : 705
	db	$fd,$17,$55,$06,$55,$05,$fc,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1357 : 715
	db	$fd,$18,$55,$05,$fc,$03,$fd,$17	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1358 : 728
	db	$55,$05,$55,$05,$fc,$02,$fd,$18	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1358 : 736
	db	$55,$05,$fc,$03,$55,$05,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1358 : 748
	db	$fc,$03,$57,$05,$fc,$02,$fd,$17	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1358 : 766
	db	$57,$05,$57,$05,$fc,$03,$fd,$18	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1358 : 776
	db	$57,$05,$fc,$02,$fd,$17,$57,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1358 : 789
	db	$57,$05,$fc,$03,$fd,$18,$57,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1358 : 801
	db	$fc,$03,$fd,$17,$57,$05,$57,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1359 : 814
	db	$fc,$02,$57,$05,$fc,$03,$fd,$18	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1359 : 827
	db	$57,$05,$fd,$17,$57,$05,$fc,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1359 : 837
	db	$fd,$18,$55,$05,$fc,$03,$fd,$17	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1359 : 849
	db	$55,$05,$55,$05,$fc,$03,$fd,$18	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1359 : 857
	db	$55,$05,$fc,$02,$55,$05,$fd,$17	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1359 : 870
	db	$55,$05,$fc,$03,$fd,$18,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1359 : 882
	db	$fc,$02,$fd,$17,$55,$06,$55,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1360 : 895
	db	$fc,$02,$fd,$18,$55,$05,$fc,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1360 : 908
	db	$55,$05,$fd,$17,$55,$05,$fc,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1360 : 918
	db	$fd,$18,$54,$05,$fc,$03,$fd,$17	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1360 : 930
	db	$54,$05,$54,$05,$fc,$03,$54,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1360 : 938
	db	$fc,$02,$fd,$18,$54,$05,$54,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1360 : 956
	db	$fc,$03,$54,$05,$fc,$02,$fd,$17	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1360 : 968
	db	$54,$05,$54,$05,$fc,$03,$fd,$18	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1361 : 978
	db	$54,$05,$fc,$03,$54,$05,$54,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1361 : 991
	db	$fc,$2b,$fc,$51,$fc,$28,$fd,$19	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1361 : 1009
	db	$41,$14,$41,$14,$41,$15,$55,$14	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1363 : 1173
	db	$40,$28,$5a,$1c,$fc,$03,$56,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1364 : 1254
	db	$fc,$03,$55,$21,$59,$05,$fc,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1365 : 1332
	db	$60,$4f,$fc,$02,$63,$1c,$62,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1366 : 1375
	db	$fc,$02,$61,$05,$fc,$03,$48,$28	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1367 : 1487
	db	$4a,$29,$fc,$28,$fc,$28,$45,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1368 : 1537
	db	$fc,$0a,$40,$05,$fc,$03,$45,$0c	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1369 : 1661
	db	$47,$05,$fc,$03,$45,$14,$55,$0d	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1369 : 1691
	db	$fc,$07,$57,$03,$fc,$05,$fc,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1370 : 1732
	db	$56,$08,$57,$14,$5a,$0f,$59,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1370 : 1752
	db	$55,$03,$60,$12,$fc,$02,$41,$29	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1371 : 1797
	db	$45,$28,$45,$05,$fc,$0f,$42,$15	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1372 : 1861
	db	$40,$14,$57,$14,$fd,$18,$40,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1373 : 1942
	db	$40,$9d,$fc,$02,$40,$a2,$41,$a2	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1373 : 1985
	db	$41,$51,$43,$28,$44,$29,$fc,$28	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1379 : 2468
	db	$fc,$51,$fc,$51,$fc,$51,$fd,$19	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1382 : 2670
	db	$46,$0a,$4a,$0a,$56,$0a,$50,$0a	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1385 : 2913
	db	$51,$8e,$fc,$3d,$fc,$50,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1385 : 2953
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1390 : 3317
	db	$fc,$2a,$fc,$0d,$fc,$47,$6b,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1393 : 3600
	db	$fc,$03,$fd,$18,$5b,$03,$5b,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1395 : 3731
	db	$fd,$19,$56,$09,$56,$05,$fc,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1395 : 3739
	db	$fd,$18,$56,$05,$fd,$19,$45,$08	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1395 : 3756
	db	$45,$29,$45,$28,$45,$29,$fc,$28	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1395 : 3769
	db	$45,$29,$fc,$28,$53,$17,$fc,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1397 : 3931
	db	$53,$02,$fc,$03,$fd,$18,$53,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1398 : 4040
	db	$fc,$05,$fd,$19,$53,$14,$4b,$14	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1398 : 4048
	db	$fc,$29,$fc,$28,$fc,$2a,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1399 : 4093
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1401 : 4223
	db	$fc,$1e,$fc,$33,$fc,$03,$fc,$12	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1402 : 4299
	db	$fc,$15,$55,$0e,$55,$14,$55,$25	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1403 : 4401
	db	$55,$17,$55,$04,$45,$19,$fc,$21	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1404 : 4493
	db	$fc,$0f
song_000_21_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_21_lp)*2
	dw	song_000_21_lp


song_000_22:	;Trk W
	db	$fb,$08,$ef,$07,$fd,$19,$fe,$09	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1407 : 0
	db	$65,$05,$fc,$03,$65,$05,$63,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1407 : 0
	db	$5b,$05,$fc,$03,$fd,$18,$53,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1407 : 20
	db	$fd,$19,$4b,$07,$53,$29,$fc,$28	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1407 : 33
	db	$53,$29,$fc,$28,$53,$29,$fc,$51	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1408 : 121
	db	$fc,$50,$fc,$51,$fc,$30,$fd,$18	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1411 : 324
	db	$59,$05,$59,$06,$fc,$02,$fd,$17	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1413 : 533
	db	$5a,$05,$fc,$03,$59,$05,$59,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1413 : 546
	db	$fc,$02,$fd,$18,$59,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1413 : 564
	db	$fd,$17,$59,$05,$59,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1414 : 574
	db	$fd,$18,$5a,$05,$fc,$02,$59,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1414 : 587
	db	$fd,$17,$59,$05,$fc,$03,$fd,$18	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1414 : 599
	db	$59,$05,$fc,$02,$fd,$17,$59,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1414 : 607
	db	$59,$05,$fc,$03,$fd,$18,$5a,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1414 : 619
	db	$fc,$03,$59,$05,$fd,$17,$59,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1414 : 632
	db	$fc,$02,$fd,$18,$5a,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1414 : 645
	db	$fd,$17,$59,$05,$59,$05,$fc,$02	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1415 : 655
	db	$fd,$18,$5a,$05,$fc,$03,$fd,$17	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1415 : 667
	db	$59,$05,$59,$05,$fc,$03,$59,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1415 : 675
	db	$fc,$02,$59,$05,$59,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1415 : 693
	db	$fd,$18,$59,$05,$fc,$02,$fd,$17	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1415 : 708
	db	$59,$06,$59,$05,$fc,$02,$fd,$18	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1415 : 715
	db	$59,$05,$fc,$03,$fd,$17,$59,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1416 : 728
	db	$59,$05,$fc,$02,$fd,$18,$59,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1416 : 741
	db	$fc,$03,$59,$05,$59,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1416 : 753
	db	$5a,$05,$fc,$02,$fd,$17,$5a,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1416 : 769
	db	$5a,$05,$fc,$03,$fd,$18,$5a,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1416 : 781
	db	$fc,$02,$fd,$17,$5a,$05,$5a,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1416 : 794
	db	$fc,$03,$fd,$18,$5a,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1416 : 806
	db	$fd,$17,$5a,$05,$5a,$05,$fc,$02	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1417 : 817
	db	$5a,$05,$fc,$03,$fd,$18,$5a,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1417 : 829
	db	$fd,$17,$5a,$05,$fc,$02,$fd,$18	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1417 : 842
	db	$58,$05,$fc,$03,$fd,$17,$58,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1417 : 849
	db	$58,$05,$fc,$03,$fd,$18,$58,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1417 : 862
	db	$fc,$02,$58,$05,$fd,$17,$58,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1417 : 875
	db	$fc,$03,$fd,$18,$58,$05,$fc,$02	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1417 : 887
	db	$fd,$17,$58,$06,$58,$05,$fc,$02	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1418 : 897
	db	$fd,$18,$58,$05,$fc,$03,$58,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1418 : 910
	db	$fd,$17,$58,$05,$fc,$02,$fd,$18	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1418 : 923
	db	$57,$05,$fc,$03,$fd,$17,$57,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1418 : 930
	db	$57,$05,$fc,$03,$57,$05,$fc,$02	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1418 : 943
	db	$fd,$18,$57,$05,$57,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1418 : 958
	db	$fd,$19,$47,$21,$fd,$18,$51,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1419 : 971
	db	$fc,$2b,$fc,$51,$fc,$28,$fd,$19	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1419 : 1009
	db	$45,$14,$38,$14,$48,$15,$51,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1421 : 1173
	db	$4a,$28,$50,$26,$fc,$03,$45,$21	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1422 : 1254
	db	$fd,$18,$49,$05,$fc,$02,$fd,$19	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1423 : 1368
	db	$50,$4f,$fc,$02,$53,$1c,$52,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1424 : 1375
	db	$fc,$02,$fd,$18,$51,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1425 : 1487
	db	$fd,$19,$60,$51,$fc,$28,$fc,$28	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1425 : 1497
	db	$49,$03,$fc,$0a,$45,$05,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1427 : 1658
	db	$49,$0c,$4a,$05,$fc,$03,$50,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1427 : 1679
	db	$49,$0d,$fc,$07,$53,$03,$fc,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1428 : 1719
	db	$fc,$05,$52,$08,$53,$14,$63,$11	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1428 : 1747
	db	$61,$03,$53,$12,$fc,$02,$48,$29	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1429 : 1797
	db	$38,$28,$5b,$05,$fc,$0f,$62,$15	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1430 : 1861
	db	$54,$14,$44,$14,$fd,$18,$48,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1431 : 1942
	db	$48,$9d,$fc,$02,$46,$a2,$45,$a2	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1431 : 1985
	db	$44,$51,$57,$28,$5a,$29,$fc,$28	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1437 : 2468
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1440 : 2670
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1444 : 2994
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1448 : 3317
	db	$fc,$2a,$fc,$0d,$fc,$47,$fd,$19	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1451 : 3600
	db	$65,$05,$fc,$03,$fd,$18,$65,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1453 : 3726
	db	$65,$02,$fd,$19,$63,$09,$5b,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1453 : 3737
	db	$fc,$03,$fd,$18,$53,$05,$fd,$19	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1453 : 3753
	db	$4b,$08,$53,$29,$fc,$28,$53,$29	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1453 : 3761
	db	$fc,$28,$53,$29,$fc,$51,$fc,$51	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1455 : 3891
	db	$fc,$28,$fc,$2a,$fc,$07,$fc,$18	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1458 : 4134
	db	$fc,$0e,$fc,$05,$fc,$21,$fc,$1e	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1459 : 4247
	db	$fc,$33,$fc,$03,$fc,$12,$fc,$15	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1460 : 4329
	db	$49,$0e,$49,$14,$49,$25,$49,$17	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1461 : 4422
	db	$49,$04,$35,$19,$fc,$21,$fc,$0f	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1462 : 4516

song_000_22_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_22_lp)*2
	dw	song_000_22_lp


song_000_23:	;Trk X
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1465 : 0
	db	$fc,$50,$fc,$45,$fb,$09,$fd,$1c	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1469 : 324
	db	$fe,$81,$65,$02,$fc,$03,$65,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1470 : 473
	db	$fc,$02,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1470 : 483
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1474 : 728
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1478 : 1052
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1482 : 1375
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$2b	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1486 : 1699
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1489 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1493 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1497 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1501 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1505 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1509 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1511 : 3726
	db	$fc,$51,$fc,$28,$fc,$29,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1512 : 3810
	db	$fc,$51,$fc,$28,$fc,$1d,$65,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1515 : 4053
	db	$fc,$03,$65,$05,$fc,$03,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1516 : 4205
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1517 : 4223
	db	$fc,$1e,$fc,$26,$65,$03,$fc,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1518 : 4299
	db	$65,$05,$fc,$03,$fc,$03,$fc,$12	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1518 : 4372
	db	$fc,$23,$fc,$14,$fc,$0c,$fc,$19	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1519 : 4401
	db	$fc,$17,$fc,$3e,$fc,$0f
song_000_23_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_23_lp)*2
	dw	song_000_23_lp


song_000_24:	;Trk Y
	db	$fc,$28,$fb,$00,$fd,$03,$fe,$81	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1523 : 0
	db	$4b,$12,$fc,$03,$fd,$01,$4b,$11	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1523 : 40
	db	$fc,$03,$fd,$00,$4b,$12,$fc,$02	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1523 : 78
	db	$4b,$12,$fc,$02,$fd,$02,$4b,$12	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1524 : 101
	db	$fc,$03,$fd,$01,$4b,$11,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1524 : 139
	db	$fd,$00,$4b,$11,$fc,$03,$4b,$12	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1525 : 162
	db	$fc,$02,$fd,$03,$4b,$12,$fc,$02	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1525 : 200
	db	$fd,$01,$4b,$12,$fc,$03,$fd,$00	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1525 : 222
	db	$4b,$11,$fc,$03,$4b,$12,$fc,$02	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1526 : 243
	db	$fd,$02,$4b,$12,$fc,$02,$fd,$01	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1526 : 283
	db	$4b,$12,$fc,$03,$fd,$00,$4b,$11	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1526 : 303
	db	$fc,$03,$4b,$12,$fc,$2a,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1527 : 341
	db	$fc,$51,$fc,$51,$fd,$02,$30,$29	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1529 : 485
	db	$fc,$28,$fc,$51,$fc,$51,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1531 : 688
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1535 : 971
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1539 : 1294
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$3c	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1543 : 1618
	db	$30,$15,$30,$28,$fc,$03,$fc,$26	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1546 : 1921
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1548 : 2023
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1552 : 2347
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$30	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1556 : 2670
	db	$fd,$03,$45,$1e,$fd,$02,$47,$05	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1559 : 2961
	db	$47,$03,$fc,$05,$fd,$03,$48,$4c	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1560 : 2996
	db	$48,$11,$fc,$08,$45,$0a,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1561 : 3080
	db	$48,$05,$fc,$05,$fd,$02,$51,$23	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1561 : 3118
	db	$51,$2b,$fc,$05,$fd,$03,$50,$24	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1562 : 3163
	db	$50,$02,$fc,$05,$4a,$24,$fc,$25	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1563 : 3247
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$29	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1564 : 3327
	db	$fc,$29,$fc,$0d,$fc,$47,$fc,$08	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1567 : 3611
	db	$fc,$03,$fc,$21,$4b,$11,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1569 : 3744
	db	$fd,$01,$4b,$11,$fc,$03,$fd,$00	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1569 : 3800
	db	$4b,$12,$fc,$02,$4b,$12,$fc,$02	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1570 : 3820
	db	$fd,$02,$4b,$12,$fc,$03,$fd,$01	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1570 : 3860
	db	$4b,$11,$fc,$03,$fd,$00,$4b,$12	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1570 : 3881
	db	$fc,$02,$4b,$12,$fc,$02,$fd,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1571 : 3919
	db	$4b,$12,$fc,$03,$fd,$01,$4b,$11	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1571 : 3941
	db	$fc,$03,$fd,$00,$4b,$12,$fc,$02	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1571 : 3979
	db	$4b,$12,$fc,$02,$fd,$02,$4b,$12	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1572 : 4002
	db	$fc,$02,$fd,$01,$4b,$12,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1572 : 4040
	db	$fd,$00,$4b,$11,$fc,$03,$4b,$12	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1573 : 4063
	db	$fc,$2b,$fc,$28,$fc,$2a,$fc,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1573 : 4101
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1575 : 4233
	db	$fc,$1e,$fc,$33,$fc,$03,$fc,$12	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1576 : 4309
	db	$fc,$15,$fd,$02,$55,$09,$fc,$02	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1577 : 4411
	db	$fd,$01,$55,$03,$55,$06,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1577 : 4443
	db	$fd,$02,$4a,$08,$fc,$03,$fd,$01	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1577 : 4455
	db	$4a,$09,$fc,$04,$fd,$02,$47,$09	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1577 : 4466
	db	$fc,$03,$fd,$01,$47,$09,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1578 : 4488
	db	$fd,$02,$4a,$0a,$fc,$04,$fd,$01	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1578 : 4503
	db	$4a,$0a,$fc,$03,$fd,$02,$49,$0b	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1578 : 4517
	db	$fc,$04,$fd,$01,$49,$0b,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1578 : 4541
	db	$fd,$00,$49,$0b,$fc,$12,$fc,$0f	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1578 : 4559

song_000_24_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_24_lp)*2
	dw	song_000_24_lp


song_000_25:	;Trk Z
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1581 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1585 : 324
	db	$fc,$35,$fb,$0a,$fd,$0b,$fe,$81	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1589 : 647
	db	$35,$1c,$fc,$03,$39,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1589 : 700
	db	$40,$3c,$fc,$08,$fc,$0d,$43,$1b	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1590 : 741
	db	$42,$03,$fc,$05,$41,$03,$fc,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1591 : 849
	db	$fd,$0c,$40,$21,$40,$56,$40,$30	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1591 : 862
	db	$fc,$05,$fd,$0b,$35,$0a,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1593 : 1029
	db	$39,$03,$fc,$02,$40,$0d,$40,$56	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1593 : 1049
	db	$40,$1c,$fc,$05,$fd,$0c,$3a,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1595 : 1153
	db	$37,$03,$fc,$05,$3a,$05,$40,$21	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1595 : 1193
	db	$40,$56,$40,$07,$fc,$2e,$fb,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1596 : 1239
	db	$fd,$08,$45,$21,$45,$07,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1597 : 1378
	db	$49,$03,$fc,$02,$fd,$08,$50,$4a	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1598 : 1418
	db	$50,$0a,$fc,$02,$53,$1c,$52,$03	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1599 : 1497
	db	$fc,$05,$fd,$07,$51,$02,$fc,$03	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1599 : 1540
	db	$fd,$08,$50,$21,$50,$35,$fc,$1b	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1599 : 1550
	db	$fc,$31,$fb,$0b,$fd,$0a,$45,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1601 : 1663
	db	$fc,$07,$fd,$09,$49,$03,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1601 : 1717
	db	$fd,$0a,$50,$11,$50,$56,$50,$17	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1601 : 1732
	db	$fc,$05,$53,$03,$fc,$02,$fd,$09	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1603 : 1858
	db	$52,$05,$fc,$03,$53,$02,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1603 : 1868
	db	$fd,$0a,$55,$1f,$fc,$02,$fd,$09	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1603 : 1883
	db	$58,$03,$fc,$05,$fd,$0a,$55,$49	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1604 : 1916
	db	$55,$05,$fc,$03,$fb,$07,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1605 : 1997
	db	$57,$24,$fc,$05,$58,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1605 : 2005
	db	$48,$02,$fc,$08,$fd,$06,$48,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1605 : 2056
	db	$fc,$08,$fd,$07,$58,$03,$fc,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1605 : 2068
	db	$58,$05,$fc,$05,$48,$03,$fc,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1606 : 2086
	db	$fd,$06,$48,$03,$fc,$07,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1606 : 2106
	db	$58,$03,$fc,$08,$58,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1606 : 2116
	db	$48,$02,$fc,$08,$fd,$06,$48,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1606 : 2137
	db	$fc,$08,$fd,$07,$58,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1606 : 2149
	db	$58,$05,$fc,$05,$48,$03,$fc,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1607 : 2167
	db	$fd,$06,$48,$03,$fc,$07,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1607 : 2187
	db	$58,$03,$fc,$08,$58,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1607 : 2197
	db	$46,$02,$fc,$08,$fd,$06,$46,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1607 : 2218
	db	$fc,$08,$fd,$07,$58,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1607 : 2230
	db	$58,$05,$fc,$05,$46,$03,$fc,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1608 : 2248
	db	$fd,$06,$46,$03,$fc,$07,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1608 : 2268
	db	$58,$03,$fc,$07,$58,$05,$fc,$06	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1608 : 2278
	db	$46,$02,$fc,$08,$fd,$06,$46,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1608 : 2299
	db	$fc,$08,$fd,$07,$58,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1608 : 2311
	db	$58,$05,$fc,$05,$46,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1609 : 2329
	db	$fd,$06,$46,$03,$fc,$07,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1609 : 2349
	db	$58,$03,$fc,$07,$58,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1609 : 2359
	db	$48,$03,$fc,$08,$fd,$06,$48,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1609 : 2379
	db	$fc,$08,$fd,$07,$58,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1609 : 2392
	db	$58,$05,$fc,$05,$48,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1610 : 2410
	db	$fd,$06,$48,$03,$fc,$07,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1610 : 2430
	db	$58,$03,$fc,$07,$58,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1610 : 2440
	db	$48,$03,$fc,$07,$fd,$06,$48,$03	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1610 : 2460
	db	$fc,$08,$fd,$07,$58,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1610 : 2473
	db	$58,$05,$fc,$05,$48,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1611 : 2491
	db	$fd,$06,$48,$02,$fc,$08,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1611 : 2511
	db	$53,$03,$fc,$07,$58,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1611 : 2521
	db	$48,$03,$fc,$07,$fd,$06,$48,$03	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1611 : 2541
	db	$fc,$07,$fd,$07,$58,$03,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1611 : 2554
	db	$58,$05,$fc,$05,$48,$02,$fc,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1612 : 2572
	db	$fd,$06,$48,$02,$fc,$08,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1612 : 2592
	db	$58,$02,$fc,$08,$51,$26,$51,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1612 : 2602
	db	$54,$28,$48,$05,$fc,$05,$fd,$06	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1613 : 2658
	db	$48,$05,$fc,$0a,$48,$05,$fc,$03	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1613 : 2708
	db	$fc,$02,$fd,$07,$48,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1614 : 2731
	db	$fd,$06,$48,$06,$fc,$0f,$48,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1614 : 2743
	db	$fc,$05,$fd,$07,$48,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1614 : 2769
	db	$fd,$06,$48,$05,$fc,$0f,$48,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1614 : 2784
	db	$fc,$03,$fc,$02,$fd,$07,$48,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1614 : 2809
	db	$fc,$05,$fd,$06,$48,$05,$fc,$10	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1615 : 2819
	db	$48,$05,$fc,$0a,$fd,$07,$46,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1615 : 2845
	db	$fc,$05,$fd,$06,$46,$05,$fc,$0f	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1615 : 2865
	db	$46,$08,$46,$02,$fc,$05,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1615 : 2890
	db	$46,$05,$fc,$05,$fd,$06,$46,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1616 : 2905
	db	$fc,$10,$46,$05,$fc,$05,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1616 : 2920
	db	$46,$05,$fc,$05,$fd,$06,$46,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1616 : 2946
	db	$fc,$0f,$46,$08,$46,$02,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1616 : 2961
	db	$fd,$07,$46,$05,$fc,$05,$fd,$06	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1617 : 2991
	db	$46,$05,$fc,$10,$46,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1617 : 3001
	db	$fd,$07,$45,$05,$fc,$05,$fd,$06	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1617 : 3032
	db	$45,$05,$fc,$0f,$45,$08,$45,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1617 : 3042
	db	$fc,$05,$fd,$07,$45,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1618 : 3072
	db	$fd,$06,$45,$05,$fc,$10,$45,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1618 : 3087
	db	$fc,$05,$fd,$07,$45,$05,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1618 : 3113
	db	$fd,$06,$45,$05,$fc,$0f,$45,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1618 : 3128
	db	$45,$02,$fc,$05,$fd,$07,$45,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1619 : 3156
	db	$fc,$05,$fd,$06,$45,$05,$fc,$0f	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1619 : 3168
	db	$44,$06,$fc,$05,$fd,$07,$44,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1619 : 3193
	db	$fc,$05,$fd,$06,$44,$05,$fc,$0f	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1619 : 3209
	db	$44,$07,$44,$03,$fc,$05,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1619 : 3234
	db	$44,$05,$fc,$05,$fd,$06,$44,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1620 : 3249
	db	$fc,$0f,$44,$05,$fc,$06,$fd,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1620 : 3264
	db	$44,$05,$fc,$05,$fd,$06,$44,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1620 : 3290
	db	$fc,$0f,$44,$07,$44,$03,$fc,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1620 : 3305
	db	$fd,$07,$44,$05,$fc,$05,$fd,$06	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1621 : 3335
	db	$44,$05,$fc,$0f,$44,$05,$fc,$26	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1621 : 3345
	db	$fc,$0d,$fb,$0c,$fd,$16,$6a,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1622 : 3408
	db	$fd,$15,$66,$08,$61,$05,$fc,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1622 : 3426
	db	$60,$05,$5a,$08,$56,$05,$fc,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1622 : 3441
	db	$53,$05,$4a,$08,$53,$05,$fc,$03	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1622 : 3461
	db	$5a,$05,$56,$07,$56,$05,$6a,$1a	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1622 : 3482
	db	$fc,$32,$fc,$0d,$69,$05,$66,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1623 : 3525
	db	$61,$06,$fc,$02,$60,$05,$59,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1624 : 3600
	db	$56,$05,$fc,$02,$53,$05,$49,$08	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1624 : 3621
	db	$51,$05,$fc,$03,$59,$05,$53,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1624 : 3641
	db	$53,$05,$69,$19,$fc,$0b,$fc,$29	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1625 : 3661
	db	$fc,$0d,$fc,$47,$fc,$08,$fc,$03	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1626 : 3743
	db	$fc,$21,$fc,$28,$fc,$51,$fc,$28	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1627 : 3838
	db	$fc,$29,$fc,$51,$fc,$51,$fc,$28	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1629 : 4032
	db	$fc,$2a,$fc,$08,$fc,$17,$fc,$0e	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1632 : 4275
	db	$fc,$05,$fc,$21,$fc,$1e,$fc,$33	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1633 : 4362
	db	$fc,$03,$fc,$12,$fc,$23,$fc,$14	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1635 : 4481
	db	$fc,$0d,$fc,$18,$fc,$18,$fc,$0e	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1635 : 4557
	db	$fb,$04,$fd,$10,$35,$16,$fc,$19	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1636 : 4632
	db	$fc,$0f
song_000_25_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_25_lp)*2
	dw	song_000_25_lp


song_000_26:	;Trk a
	db	$fb,$09,$fd,$1d,$fe,$02,$63,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1639 : 0
	db	$fc,$03,$5b,$05,$56,$07,$55,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1639 : 5
	db	$fc,$03,$53,$05,$4b,$07,$fc,$29	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1639 : 25
	db	$45,$02,$fc,$05,$4b,$03,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1640 : 81
	db	$48,$07,$4b,$03,$fc,$05,$46,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1640 : 94
	db	$fc,$03,$4b,$02,$fc,$2e,$45,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1640 : 111
	db	$fc,$05,$4b,$03,$fc,$02,$48,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1641 : 164
	db	$4b,$03,$fc,$05,$46,$02,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1641 : 182
	db	$4b,$02,$fc,$2e,$35,$02,$fc,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1641 : 195
	db	$3b,$03,$fc,$02,$38,$08,$46,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1642 : 250
	db	$fc,$06,$45,$02,$fc,$03,$4b,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1642 : 265
	db	$fc,$05,$4b,$14,$fc,$08,$4b,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1642 : 278
	db	$fc,$03,$4b,$05,$fc,$03,$4b,$0c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1642 : 313
	db	$fc,$08,$fd,$1c,$55,$07,$59,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1643 : 336
	db	$60,$08,$fd,$1b,$61,$03,$fd,$1d	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1643 : 356
	db	$60,$11,$fc,$08,$fd,$1c,$60,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1643 : 367
	db	$fc,$03,$60,$05,$fc,$02,$60,$15	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1643 : 394
	db	$65,$02,$fc,$05,$60,$03,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1644 : 425
	db	$60,$05,$fc,$03,$60,$14,$65,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1644 : 437
	db	$fc,$05,$60,$02,$fc,$03,$60,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1644 : 468
	db	$fc,$02,$5a,$03,$fc,$05,$5a,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1644 : 483
	db	$fc,$02,$5a,$05,$fc,$03,$5a,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1645 : 496
	db	$fc,$05,$5a,$03,$fc,$02,$63,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1645 : 508
	db	$fc,$03,$66,$02,$65,$08,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1645 : 523
	db	$57,$08,$fd,$1b,$55,$08,$fd,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1645 : 538
	db	$50,$05,$fd,$1b,$47,$07,$fd,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1645 : 554
	db	$45,$08,$40,$05,$39,$08,$35,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1646 : 566
	db	$40,$05,$39,$08,$45,$07,$50,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1646 : 594
	db	$49,$08,$55,$08,$60,$05,$59,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1646 : 619
	db	$fd,$1b,$65,$03,$fd,$1a,$67,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1647 : 647
	db	$fd,$1b,$65,$02,$67,$03,$65,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1647 : 655
	db	$fd,$1a,$67,$02,$fd,$1b,$65,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1647 : 665
	db	$fd,$1a,$67,$05,$fd,$1b,$65,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1647 : 670
	db	$fd,$1a,$67,$02,$fd,$1b,$65,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1647 : 678
	db	$fd,$1a,$67,$03,$65,$02,$fc,$26	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1647 : 685
	db	$fc,$51,$fc,$1c,$fd,$1c,$65,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1648 : 728
	db	$67,$07,$60,$08,$fc,$05,$58,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1649 : 842
	db	$60,$07,$fc,$05,$58,$08,$55,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1649 : 870
	db	$fc,$06,$50,$07,$4a,$08,$fc,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1650 : 897
	db	$45,$07,$4a,$03,$50,$05,$4a,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1650 : 923
	db	$47,$08,$53,$07,$fc,$05,$4a,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1650 : 943
	db	$57,$02,$58,$05,$57,$05,$53,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1651 : 971
	db	$5a,$08,$fc,$05,$57,$07,$60,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1651 : 991
	db	$fc,$21,$55,$07,$59,$03,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1651 : 1019
	db	$60,$05,$fc,$03,$fd,$1d,$65,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1652 : 1064
	db	$fd,$1c,$65,$05,$60,$03,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1652 : 1074
	db	$5b,$05,$fc,$02,$5a,$03,$5a,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1652 : 1085
	db	$57,$02,$fc,$03,$53,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1652 : 1100
	db	$4a,$29,$fc,$3c,$fc,$51,$36,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1652 : 1112
	db	$fc,$03,$fd,$1d,$4a,$05,$46,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1655 : 1299
	db	$4a,$02,$fc,$05,$50,$03,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1655 : 1315
	db	$fd,$1c,$46,$03,$fc,$05,$55,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1655 : 1327
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1655 : 1337
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1659 : 1618
	db	$fc,$21,$fd,$1b,$53,$07,$45,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1663 : 1942
	db	$45,$05,$47,$05,$58,$47,$53,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1663 : 1985
	db	$fc,$05,$53,$26,$fc,$02,$53,$15	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1664 : 2071
	db	$58,$14,$5a,$42,$fc,$05,$53,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1665 : 2137
	db	$fc,$05,$53,$32,$fc,$0b,$60,$0a	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1666 : 2233
	db	$63,$05,$fc,$05,$61,$23,$fd,$1a	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1667 : 2309
	db	$60,$03,$5b,$02,$fd,$1b,$58,$5b	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1668 : 2354
	db	$fc,$0a,$45,$05,$fc,$05,$47,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1669 : 2450
	db	$fc,$06,$59,$02,$58,$4c,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1669 : 2475
	db	$5a,$47,$47,$05,$fc,$05,$61,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1670 : 2561
	db	$60,$9f,$fc,$1c,$fc,$51,$fc,$51	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1671 : 2645
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1676 : 2994
	db	$fd,$1c,$6a,$05,$fc,$03,$66,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1680 : 3317
	db	$61,$08,$60,$05,$fc,$02,$5a,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1680 : 3330
	db	$56,$08,$53,$05,$fc,$02,$4a,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1680 : 3350
	db	$53,$08,$5a,$05,$fc,$03,$56,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1680 : 3370
	db	$6a,$19,$fc,$3f,$69,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1680 : 3391
	db	$66,$05,$61,$07,$60,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1682 : 3487
	db	$59,$05,$56,$08,$53,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1682 : 3507
	db	$49,$05,$51,$08,$59,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1682 : 3527
	db	$53,$05,$69,$1a,$fc,$16,$fc,$2a	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1682 : 3547
	db	$fc,$0d,$fc,$47,$63,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1684 : 3642
	db	$5b,$03,$5b,$02,$56,$09,$55,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1685 : 3734
	db	$fc,$03,$53,$05,$fd,$1b,$4b,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1685 : 3753
	db	$fc,$29,$fd,$1d,$45,$02,$fc,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1685 : 3769
	db	$4b,$03,$fc,$03,$48,$07,$4b,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1686 : 3817
	db	$fc,$05,$46,$02,$fc,$03,$4b,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1686 : 3833
	db	$fc,$2e,$45,$02,$fc,$05,$4b,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1686 : 3845
	db	$fc,$02,$48,$08,$4b,$03,$fc,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1687 : 3901
	db	$46,$02,$fc,$03,$4b,$02,$fc,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1687 : 3919
	db	$fc,$29,$35,$02,$fc,$05,$fd,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1687 : 3931
	db	$3b,$03,$fc,$02,$38,$08,$fd,$1d	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1688 : 3979
	db	$46,$02,$fc,$06,$fd,$1c,$45,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1688 : 3992
	db	$fc,$03,$4b,$07,$fd,$1d,$4b,$14	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1688 : 4002
	db	$fc,$08,$4b,$02,$fc,$03,$fd,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1688 : 4032
	db	$4b,$03,$fc,$05,$fd,$1d,$4b,$14	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1688 : 4045
	db	$fd,$1c,$55,$05,$fc,$02,$fd,$1b	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1689 : 4073
	db	$59,$05,$fd,$1c,$60,$08,$fd,$1b	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1689 : 4080
	db	$61,$03,$fd,$1c,$60,$11,$fc,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1689 : 4093
	db	$fd,$1b,$60,$02,$fc,$03,$60,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1689 : 4121
	db	$fc,$03,$60,$14,$fd,$1c,$65,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1689 : 4131
	db	$fc,$05,$fd,$1b,$60,$03,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1690 : 4156
	db	$60,$05,$fc,$03,$60,$15,$fd,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1690 : 4166
	db	$65,$02,$fc,$06,$fd,$1b,$60,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1690 : 4195
	db	$fc,$03,$60,$05,$fc,$03,$5a,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1690 : 4205
	db	$fc,$05,$5a,$03,$fc,$03,$5a,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1691 : 4218
	db	$fc,$03,$fd,$1c,$5a,$02,$fc,$06	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1691 : 4234
	db	$fd,$1b,$5a,$02,$fc,$03,$fd,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1691 : 4245
	db	$63,$05,$fc,$03,$fd,$1b,$61,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1691 : 4250
	db	$fd,$1c,$60,$05,$60,$0c,$fc,$08	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1691 : 4261
	db	$fd,$1b,$60,$02,$fc,$03,$60,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1691 : 4286
	db	$fc,$03,$60,$14,$fd,$1c,$65,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1691 : 4296
	db	$fc,$05,$fd,$1b,$60,$03,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1692 : 4321
	db	$60,$06,$fc,$02,$60,$15,$fd,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1692 : 4331
	db	$65,$02,$fc,$05,$fd,$1b,$60,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1692 : 4360
	db	$fc,$02,$60,$05,$fc,$03,$fd,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1692 : 4370
	db	$5a,$03,$fc,$05,$fd,$1b,$5a,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1693 : 4380
	db	$fc,$03,$fd,$1c,$5a,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1693 : 4390
	db	$5a,$02,$fc,$06,$fd,$1b,$5a,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1693 : 4401
	db	$fc,$03,$fd,$1c,$63,$06,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1693 : 4411
	db	$65,$0e,$65,$14,$65,$25,$65,$17	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1693 : 4422
	db	$65,$04,$fc,$3a,$fc,$0f
song_000_26_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_26_lp)*2
	dw	song_000_26_lp


song_000_27:	;Trk b
	db	$fc,$51,$fb,$09,$fd,$1d,$fe,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1697 : 0
	db	$3b,$02,$fc,$05,$53,$03,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1698 : 81
	db	$4b,$07,$56,$03,$fc,$05,$53,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1698 : 94
	db	$fc,$03,$43,$02,$fc,$2e,$3b,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1698 : 111
	db	$fc,$05,$53,$03,$fc,$02,$4b,$08	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1699 : 164
	db	$56,$03,$fc,$05,$53,$02,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1699 : 182
	db	$43,$02,$fc,$2e,$2b,$02,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1699 : 195
	db	$43,$03,$fc,$02,$3b,$08,$3b,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1700 : 250
	db	$fc,$06,$4b,$02,$fc,$03,$53,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1700 : 265
	db	$56,$14,$fc,$08,$56,$02,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1700 : 283
	db	$56,$05,$fc,$03,$56,$0c,$fc,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1700 : 316
	db	$fd,$1b,$66,$03,$fd,$1d,$65,$11	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1701 : 364
	db	$fc,$08,$fd,$1c,$65,$02,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1701 : 384
	db	$65,$05,$fc,$02,$65,$03,$fd,$1b	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1701 : 397
	db	$67,$05,$65,$03,$fd,$1c,$67,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1702 : 407
	db	$65,$05,$fd,$1b,$67,$03,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1702 : 417
	db	$fd,$1c,$65,$03,$fc,$02,$65,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1702 : 432
	db	$fc,$03,$65,$02,$fd,$1b,$67,$06	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1702 : 442
	db	$65,$02,$fd,$1c,$67,$03,$65,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1702 : 453
	db	$fd,$1b,$67,$02,$fc,$08,$fd,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1702 : 463
	db	$60,$02,$fc,$03,$60,$05,$fc,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1702 : 473
	db	$63,$03,$fc,$05,$60,$03,$fc,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1703 : 485
	db	$61,$05,$fc,$03,$63,$02,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1703 : 498
	db	$60,$03,$fc,$11,$60,$05,$fc,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1703 : 513
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1704 : 566
	db	$fd,$1d,$68,$03,$6a,$02,$68,$08	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1707 : 849
	db	$fd,$1c,$65,$08,$fc,$14,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1707 : 862
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1709 : 971
	db	$fd,$1d,$40,$05,$fc,$03,$fd,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1713 : 1294
	db	$43,$05,$40,$08,$fd,$1d,$40,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1713 : 1302
	db	$fc,$05,$fd,$1c,$43,$03,$fc,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1713 : 1317
	db	$fd,$1d,$56,$03,$fc,$2d,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1713 : 1327
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1715 : 1456
	db	$fc,$51,$fc,$51,$fc,$21,$fd,$1b	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1719 : 1780
	db	$43,$07,$55,$03,$55,$05,$57,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1721 : 1975
	db	$48,$47,$43,$05,$fc,$05,$43,$26	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1721 : 1995
	db	$fc,$02,$43,$15,$48,$14,$4a,$42	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1723 : 2114
	db	$fc,$05,$43,$05,$fc,$05,$43,$32	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1724 : 2223
	db	$fc,$0b,$50,$0a,$53,$05,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1725 : 2288
	db	$51,$23,$fd,$1a,$50,$03,$4b,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1725 : 2319
	db	$fd,$1b,$48,$5b,$fc,$0a,$55,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1726 : 2359
	db	$fc,$05,$57,$05,$fc,$06,$49,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1727 : 2465
	db	$48,$4c,$fc,$02,$4a,$47,$57,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1727 : 2483
	db	$fc,$05,$51,$03,$50,$9f,$fc,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1729 : 2637
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1732 : 2832
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1736 : 3156
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1740 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1742 : 3655
	db	$fc,$29,$fd,$1d,$3b,$02,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1743 : 3769
	db	$53,$03,$fc,$03,$4b,$07,$56,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1744 : 3817
	db	$fc,$05,$53,$02,$fc,$03,$43,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1744 : 3833
	db	$fc,$2e,$3b,$02,$fc,$05,$53,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1744 : 3845
	db	$fc,$02,$4b,$08,$56,$03,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1745 : 3901
	db	$53,$02,$fc,$03,$43,$02,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1745 : 3919
	db	$fc,$29,$2b,$02,$fc,$05,$fd,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1745 : 3931
	db	$43,$03,$fc,$02,$3b,$08,$fd,$1d	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1746 : 3979
	db	$3b,$02,$fc,$06,$fd,$1c,$4b,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1746 : 3992
	db	$fc,$03,$53,$07,$fd,$1d,$56,$14	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1746 : 4002
	db	$fc,$08,$56,$02,$fc,$03,$fd,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1746 : 4032
	db	$56,$03,$fc,$05,$fd,$1d,$56,$14	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1746 : 4045
	db	$fc,$14,$fd,$1b,$66,$03,$fd,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1747 : 4073
	db	$65,$11,$fc,$08,$65,$02,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1747 : 4096
	db	$fd,$1b,$65,$05,$fc,$03,$fd,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1747 : 4126
	db	$65,$02,$fd,$1b,$67,$05,$65,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1748 : 4134
	db	$67,$02,$65,$05,$67,$03,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1748 : 4144
	db	$65,$03,$fc,$02,$fd,$1c,$65,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1748 : 4161
	db	$fc,$03,$65,$03,$fd,$1b,$67,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1748 : 4171
	db	$65,$02,$67,$03,$65,$05,$67,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1748 : 4182
	db	$fc,$08,$60,$02,$fc,$03,$60,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1748 : 4195
	db	$fc,$03,$fd,$1c,$63,$02,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1748 : 4213
	db	$fd,$1b,$60,$03,$fc,$03,$fd,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1749 : 4223
	db	$61,$05,$fc,$03,$63,$02,$fc,$06	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1749 : 4229
	db	$fd,$1b,$60,$02,$fc,$0b,$66,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1749 : 4245
	db	$fd,$1c,$65,$05,$65,$0c,$fc,$08	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1749 : 4261
	db	$65,$02,$fc,$03,$fd,$1b,$65,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1749 : 4286
	db	$fc,$03,$fd,$1c,$65,$02,$fd,$1b	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1749 : 4296
	db	$67,$05,$65,$03,$67,$02,$65,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1750 : 4301
	db	$67,$03,$fc,$07,$65,$03,$fc,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1750 : 4316
	db	$fd,$1c,$65,$06,$fc,$02,$65,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1750 : 4331
	db	$fd,$1b,$67,$05,$65,$02,$67,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1750 : 4342
	db	$65,$05,$67,$03,$fc,$07,$60,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1750 : 4352
	db	$fc,$02,$60,$05,$fc,$03,$fd,$1c	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1750 : 4370
	db	$63,$03,$fc,$05,$fd,$1b,$60,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1751 : 4380
	db	$fc,$03,$fd,$1c,$61,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1751 : 4390
	db	$63,$02,$fc,$06,$fd,$1b,$60,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1751 : 4401
	db	$fc,$19,$fc,$14,$fc,$0c,$fc,$19	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_ID_style.mml: 1751 : 4411
	db	$fc,$17,$fc,$3e,$fc,$0f
song_000_27_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_27_lp)*2
	dw	song_000_27_lp

