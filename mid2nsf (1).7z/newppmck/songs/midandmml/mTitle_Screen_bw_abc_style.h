; Title: Title_Screen_bw_abc_style
; Composer: 
; Maker: 
; Programer: mid2mml for ppmck Ver1.0�� & stgig

	.bank	0
	.if TOTAL_SONGS > 1
song_addr_table:
	dw	song_000_track_table
	.if (ALLOW_BANK_SWITCH)
song_bank_table:
	dw	song_000_bank_table
	.endif ; ALLOW_BANK_SWITCH
	.endif ; TOTAL_SONGS > 1
song_000_track_table:
	dw	song_000_00
	dw	song_000_01
	dw	song_000_02
	dw	song_000_03
	dw	song_000_04
	dw	song_000_05
	dw	song_000_06
	dw	song_000_07
	dw	song_000_08
	dw	song_000_09
	dw	song_000_10
	dw	song_000_11
	dw	song_000_12
	dw	song_000_13
	dw	song_000_14
	dw	song_000_15
	dw	song_000_16
	dw	song_000_17
	dw	song_000_18
	dw	song_000_19
	dw	song_000_20
	dw	song_000_21
	dw	song_000_22
	dw	song_000_23
	dw	song_000_24
	dw	song_000_25
	dw	song_000_26
	dw	song_000_27
	.if (ALLOW_BANK_SWITCH)
song_000_bank_table:
	db	bank(song_000_00)*2
	db	bank(song_000_01)*2
	db	bank(song_000_02)*2
	db	bank(song_000_03)*2
	db	bank(song_000_04)*2
	db	bank(song_000_05)*2
	db	bank(song_000_06)*2
	db	bank(song_000_07)*2
	db	bank(song_000_08)*2
	db	bank(song_000_09)*2
	db	bank(song_000_10)*2
	db	bank(song_000_11)*2
	db	bank(song_000_12)*2
	db	bank(song_000_13)*2
	db	bank(song_000_14)*2
	db	bank(song_000_15)*2
	db	bank(song_000_16)*2
	db	bank(song_000_17)*2
	db	bank(song_000_18)*2
	db	bank(song_000_19)*2
	db	bank(song_000_20)*2
	db	bank(song_000_21)*2
	db	bank(song_000_22)*2
	db	bank(song_000_23)*2
	db	bank(song_000_24)*2
	db	bank(song_000_25)*2
	db	bank(song_000_26)*2
	db	bank(song_000_27)*2
	.endif

song_000_00:	;Trk A
	db	$ee
	db	bank(song_000_00_bnk002)*2
	dw	song_000_00_bnk002

	.bank	2
song_000_00_bnk002:
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 123 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 127 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 131 : 647
	db	$fc,$14,$fb,$06,$fd,$12,$fe,$03	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 135 : 971
	db	$22,$05,$fc,$03,$23,$05,$2b,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 135 : 991
	db	$30,$0d,$31,$02,$fc,$05,$31,$03	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 135 : 1011
	db	$30,$6f,$fc,$08,$23,$05,$fc,$02	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 135 : 1034
	db	$1a,$03,$fc,$02,$23,$08,$30,$47	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 137 : 1160
	db	$fc,$32,$fc,$51,$fc,$51,$fc,$29	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 138 : 1244
	db	$fb,$05,$fd,$09,$fe,$04,$17,$0a	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 141 : 1497
	db	$fc,$1e,$fc,$30,$25,$05,$fc,$1c	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 141 : 1507
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 143 : 1618
	db	$fc,$14,$fb,$06,$fd,$12,$fe,$03	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 147 : 1942
	db	$23,$05,$fc,$03,$35,$05,$37,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 147 : 1962
	db	$28,$03,$28,$44,$23,$05,$fc,$05	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 147 : 1982
	db	$23,$26,$fc,$03,$23,$14,$28,$14	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 148 : 2063
	db	$2a,$42,$fc,$05,$23,$05,$fc,$05	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 149 : 2144
	db	$23,$33,$fc,$0a,$30,$0a,$33,$05	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 150 : 2225
	db	$fc,$05,$31,$23,$fc,$03,$fd,$11	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 151 : 2301
	db	$29,$03,$fd,$12,$28,$5b,$fc,$0a	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 151 : 2344
	db	$35,$05,$fc,$05,$37,$05,$fc,$05	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 153 : 2448
	db	$fd,$11,$29,$02,$fd,$12,$28,$4c	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 153 : 2468
	db	$fc,$03,$2a,$47,$37,$05,$fc,$05	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 154 : 2546
	db	$31,$02,$30,$9f,$fc,$29,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 155 : 2630
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 159 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 163 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 167 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 169 : 3726
	db	$fc,$51,$fc,$28,$fc,$29,$fc,$51	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 170 : 3810
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 173 : 4053
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 175 : 4223
	db	$fc,$1e,$fc,$33,$fc,$03,$fc,$12	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 176 : 4299
	db	$fc,$23,$fc,$14,$fc,$0c,$fc,$19	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 177 : 4401
	db	$fc,$17,$fc,$3e,$fc,$0f
song_000_00_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_00_lp)*2
	dw	song_000_00_lp


song_000_01:	;Trk B
	db	$fc,$28,$fb,$07,$fd,$0c,$fe,$05	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 181 : 0
	db	$05,$21,$fc,$08,$fd,$0b,$0f,$1c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 181 : 40
	db	$fc,$0c,$fd,$0c,$05,$1c,$fc,$0d	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 182 : 109
	db	$fd,$0b,$0f,$1e,$fc,$0a,$fd,$0c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 183 : 162
	db	$05,$1c,$fc,$0d,$fd,$0b,$0f,$1c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 183 : 202
	db	$fc,$0c,$0f,$14,$fc,$08,$0f,$02	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 184 : 271
	db	$fc,$03,$0f,$05,$fc,$03,$06,$14	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 184 : 313
	db	$fc,$14,$05,$14,$fc,$14,$fc,$29	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 185 : 344
	db	$fd,$0c,$05,$28,$fd,$0b,$03,$15	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 186 : 445
	db	$fc,$14,$05,$14,$fc,$14,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 187 : 506
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 189 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$29	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 193 : 971
	db	$00,$28,$06,$1f,$03,$0a,$fc,$28	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 196 : 1254
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 198 : 1375
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$2b	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 202 : 1699
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 205 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 209 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 213 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 217 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 221 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 225 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fd,$0c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 227 : 3726
	db	$05,$29,$fd,$0b,$0f,$28,$fd,$0c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 227 : 3769
	db	$05,$24,$fc,$05,$fd,$0b,$0f,$23	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 228 : 3850
	db	$fc,$05,$fd,$0c,$05,$24,$fc,$05	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 229 : 3926
	db	$fd,$0b,$0f,$23,$fc,$05,$fd,$0c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 230 : 3972
	db	$0f,$12,$fc,$0a,$fd,$0b,$0f,$02	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 230 : 4012
	db	$fc,$03,$0f,$05,$fc,$03,$06,$14	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 230 : 4042
	db	$fc,$14,$fd,$0c,$05,$29,$fc,$28	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 231 : 4073
	db	$fd,$0b,$05,$2a,$03,$07,$03,$0e	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 232 : 4174
	db	$fc,$0a,$fc,$0b,$05,$03,$05,$05	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 233 : 4237
	db	$05,$21,$fc,$1e,$fc,$0a,$fd,$0c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 233 : 4266
	db	$05,$29,$fd,$0b,$03,$03,$03,$12	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 234 : 4339
	db	$fc,$23,$fc,$14,$fc,$0c,$fc,$19	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 235 : 4401
	db	$fc,$17,$fc,$04,$05,$19,$fc,$21	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 236 : 4493
	db	$fc,$0f
song_000_01_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_01_lp)*2
	dw	song_000_01_lp


song_000_02:	;Trk C
	db	$fe,$8f,$fb,$09,$53,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 93 : 0
	db	$fc,$03,$4b,$04,$fc,$01,$46,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 239 : 5
	db	$fc,$01,$45,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 239 : 13
	db	$43,$04,$fc,$01,$3b,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 239 : 28
	db	$fc,$29,$35,$01,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 239 : 40
	db	$3b,$02,$fc,$01,$fc,$03,$38,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 240 : 88
	db	$fc,$01,$3b,$02,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 240 : 94
	db	$36,$01,$fc,$01,$fc,$03,$3b,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 240 : 109
	db	$fc,$01,$fc,$2e,$35,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 240 : 114
	db	$fc,$05,$3b,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 241 : 164
	db	$38,$07,$fc,$01,$3b,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 241 : 174
	db	$fc,$05,$36,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 241 : 185
	db	$3b,$01,$fc,$01,$fc,$2e,$25,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 241 : 195
	db	$fc,$01,$fc,$05,$2b,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 242 : 243
	db	$fc,$02,$28,$07,$fc,$01,$36,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 242 : 253
	db	$fc,$01,$fc,$06,$35,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 242 : 263
	db	$fc,$03,$3b,$01,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 242 : 273
	db	$3b,$12,$fc,$02,$fc,$08,$3b,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 242 : 283
	db	$fc,$01,$fc,$03,$3b,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 242 : 311
	db	$fc,$03,$3b,$0b,$fc,$01,$fc,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 242 : 321
	db	$45,$06,$fc,$01,$49,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 243 : 344
	db	$50,$07,$fc,$01,$51,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 243 : 356
	db	$50,$0f,$fc,$02,$fc,$08,$50,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 243 : 367
	db	$fc,$01,$fc,$03,$50,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 243 : 392
	db	$fc,$02,$50,$13,$fc,$02,$55,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 243 : 402
	db	$fc,$01,$fc,$05,$50,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 244 : 425
	db	$fc,$02,$50,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 244 : 435
	db	$50,$12,$fc,$02,$55,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 244 : 445
	db	$fc,$05,$50,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 244 : 468
	db	$50,$04,$fc,$01,$fc,$02,$4a,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 244 : 478
	db	$fc,$01,$fc,$05,$4a,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 245 : 485
	db	$fc,$02,$4a,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 245 : 496
	db	$4a,$01,$fc,$01,$fc,$05,$4a,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 245 : 506
	db	$fc,$01,$fc,$02,$53,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 245 : 513
	db	$fc,$03,$56,$01,$fc,$01,$55,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 245 : 523
	db	$fc,$01,$fc,$02,$47,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 245 : 528
	db	$45,$07,$fc,$01,$40,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 245 : 546
	db	$37,$06,$fc,$01,$35,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 245 : 559
	db	$30,$04,$fc,$01,$29,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 246 : 574
	db	$25,$06,$fc,$01,$30,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 246 : 587
	db	$29,$07,$fc,$01,$35,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 246 : 599
	db	$40,$04,$fc,$01,$39,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 246 : 614
	db	$45,$07,$fc,$01,$50,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 246 : 627
	db	$49,$06,$fc,$01,$55,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 246 : 640
	db	$57,$04,$fc,$01,$55,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 247 : 650
	db	$57,$02,$fc,$01,$55,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 247 : 657
	db	$57,$01,$fc,$01,$55,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 247 : 665
	db	$57,$04,$fc,$01,$55,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 247 : 670
	db	$57,$01,$fc,$01,$55,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 247 : 678
	db	$57,$02,$fc,$01,$55,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 247 : 685
	db	$fc,$26,$fc,$51,$fc,$1c,$55,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 247 : 690
	db	$fc,$01,$57,$06,$fc,$01,$50,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 249 : 837
	db	$fc,$01,$fc,$05,$48,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 249 : 849
	db	$50,$06,$fc,$01,$fc,$05,$48,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 249 : 870
	db	$fc,$01,$45,$06,$fc,$01,$fc,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 249 : 882
	db	$40,$06,$fc,$01,$3a,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 250 : 903
	db	$fc,$05,$35,$06,$fc,$01,$3a,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 250 : 918
	db	$fc,$01,$40,$04,$fc,$01,$3a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 250 : 930
	db	$fc,$01,$37,$07,$fc,$01,$43,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 250 : 938
	db	$fc,$01,$fc,$05,$3a,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 250 : 951
	db	$47,$01,$fc,$01,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 251 : 971
	db	$47,$04,$fc,$01,$43,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 251 : 978
	db	$4a,$07,$fc,$01,$fc,$05,$47,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 251 : 991
	db	$fc,$01,$50,$07,$fc,$01,$fc,$21	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 251 : 1004
	db	$45,$06,$fc,$01,$49,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 252 : 1052
	db	$fc,$02,$50,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 252 : 1062
	db	$55,$01,$fc,$01,$55,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 252 : 1072
	db	$50,$02,$fc,$01,$fc,$03,$4b,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 252 : 1079
	db	$fc,$01,$fc,$02,$4a,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 252 : 1085
	db	$4a,$04,$fc,$01,$47,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 252 : 1095
	db	$fc,$03,$43,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 252 : 1102
	db	$3a,$26,$fc,$03,$fc,$3c,$fc,$51	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 252 : 1112
	db	$26,$04,$fc,$01,$fc,$03,$3a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 255 : 1294
	db	$fc,$01,$36,$07,$fc,$01,$3a,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 255 : 1302
	db	$fc,$01,$fc,$05,$40,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 255 : 1315
	db	$fc,$02,$36,$02,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 255 : 1325
	db	$45,$01,$fc,$01,$fc,$26,$fc,$51	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 255 : 1335
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 257 : 1456
	db	$fc,$51,$fc,$51,$fc,$21,$43,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 261 : 1780
	db	$fc,$01,$35,$02,$fc,$01,$35,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 263 : 1975
	db	$fc,$01,$37,$04,$fc,$01,$48,$42	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 263 : 1985
	db	$fc,$05,$43,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 263 : 1995
	db	$43,$23,$fc,$03,$fc,$02,$43,$13	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 264 : 2076
	db	$fc,$02,$48,$12,$fc,$02,$4a,$3d	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 265 : 2116
	db	$fc,$05,$fc,$05,$43,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 265 : 2157
	db	$fc,$05,$43,$2e,$fc,$04,$fc,$0b	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 266 : 2233
	db	$50,$09,$fc,$01,$53,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 267 : 2299
	db	$fc,$05,$51,$20,$fc,$03,$50,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 267 : 2314
	db	$fc,$01,$4b,$01,$fc,$01,$48,$55	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 268 : 2354
	db	$fc,$06,$fc,$0a,$35,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 268 : 2359
	db	$fc,$05,$37,$04,$fc,$01,$fc,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 269 : 2465
	db	$49,$01,$fc,$01,$48,$47,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 269 : 2481
	db	$fc,$02,$4a,$42,$fc,$05,$37,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 270 : 2559
	db	$fc,$01,$fc,$05,$51,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 271 : 2632
	db	$50,$95,$fc,$0a,$fc,$1c,$fc,$51	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 271 : 2645
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 275 : 2913
	db	$fc,$51,$5a,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 279 : 3236
	db	$56,$04,$fc,$01,$51,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 280 : 3325
	db	$50,$04,$fc,$01,$fc,$02,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 280 : 3338
	db	$fc,$01,$46,$07,$fc,$01,$43,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 280 : 3345
	db	$fc,$01,$fc,$02,$3a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 280 : 3358
	db	$43,$07,$fc,$01,$4a,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 280 : 3370
	db	$fc,$03,$46,$04,$fc,$01,$5a,$17	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 280 : 3383
	db	$fc,$02,$fc,$3f,$59,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 280 : 3391
	db	$fc,$03,$56,$04,$fc,$01,$51,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 282 : 3484
	db	$fc,$01,$50,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 282 : 3492
	db	$49,$04,$fc,$01,$46,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 282 : 3507
	db	$43,$04,$fc,$01,$fc,$02,$39,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 282 : 3520
	db	$fc,$01,$41,$07,$fc,$01,$49,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 282 : 3527
	db	$fc,$01,$fc,$02,$43,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 282 : 3540
	db	$59,$18,$fc,$02,$fc,$16,$fc,$2a	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 282 : 3552
	db	$fc,$0d,$fc,$47,$53,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 284 : 3642
	db	$fc,$03,$4b,$02,$fc,$01,$4b,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 285 : 3731
	db	$fc,$01,$46,$08,$fc,$01,$45,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 285 : 3737
	db	$fc,$01,$fc,$03,$43,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 285 : 3748
	db	$3b,$07,$fc,$01,$fc,$29,$35,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 285 : 3761
	db	$fc,$01,$fc,$05,$3b,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 286 : 3810
	db	$fc,$03,$38,$06,$fc,$01,$3b,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 286 : 3820
	db	$fc,$01,$fc,$05,$36,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 286 : 3830
	db	$fc,$03,$3b,$01,$fc,$01,$fc,$2e	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 286 : 3840
	db	$35,$01,$fc,$01,$fc,$05,$3b,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 287 : 3891
	db	$fc,$01,$fc,$02,$38,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 287 : 3898
	db	$3b,$02,$fc,$01,$fc,$05,$36,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 287 : 3911
	db	$fc,$01,$fc,$03,$3b,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 287 : 3919
	db	$fc,$05,$fc,$29,$25,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 287 : 3926
	db	$fc,$05,$2b,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 288 : 3974
	db	$28,$07,$fc,$01,$36,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 288 : 3984
	db	$fc,$06,$35,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 288 : 3994
	db	$3b,$06,$fc,$01,$3b,$12,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 288 : 4005
	db	$fc,$08,$3b,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 288 : 4032
	db	$3b,$02,$fc,$01,$fc,$05,$3b,$12	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 288 : 4045
	db	$fc,$02,$45,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 289 : 4053
	db	$49,$04,$fc,$01,$50,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 289 : 4080
	db	$51,$02,$fc,$01,$50,$0f,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 289 : 4093
	db	$fc,$08,$50,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 289 : 4113
	db	$50,$04,$fc,$01,$fc,$03,$50,$12	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 289 : 4126
	db	$fc,$02,$55,$01,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 290 : 4134
	db	$50,$02,$fc,$01,$fc,$02,$50,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 290 : 4161
	db	$fc,$01,$fc,$03,$50,$13,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 290 : 4166
	db	$55,$01,$fc,$01,$fc,$06,$50,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 290 : 4195
	db	$fc,$01,$fc,$03,$50,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 290 : 4203
	db	$fc,$03,$4a,$01,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 290 : 4213
	db	$4a,$02,$fc,$01,$fc,$03,$4a,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 291 : 4223
	db	$fc,$01,$fc,$03,$4a,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 291 : 4229
	db	$fc,$06,$4a,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 291 : 4239
	db	$53,$04,$fc,$01,$fc,$03,$51,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 291 : 4250
	db	$fc,$01,$50,$04,$fc,$01,$50,$0b	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 291 : 4258
	db	$fc,$01,$fc,$08,$50,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 291 : 4266
	db	$fc,$03,$50,$04,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 291 : 4288
	db	$50,$12,$fc,$02,$55,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 292 : 4299
	db	$fc,$05,$50,$02,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 292 : 4321
	db	$50,$05,$fc,$01,$fc,$02,$50,$13	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 292 : 4331
	db	$fc,$02,$55,$01,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 292 : 4339
	db	$50,$02,$fc,$01,$fc,$02,$50,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 292 : 4367
	db	$fc,$01,$fc,$03,$4a,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 292 : 4372
	db	$fc,$05,$4a,$01,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 293 : 4383
	db	$4a,$04,$fc,$01,$fc,$03,$4a,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 293 : 4393
	db	$fc,$01,$fc,$06,$4a,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 293 : 4401
	db	$fc,$03,$53,$05,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 293 : 4411
	db	$55,$0d,$fc,$01,$55,$12,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 293 : 4422
	db	$55,$22,$fc,$03,$55,$15,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 293 : 4456
	db	$55,$03,$fc,$01,$fc,$3a,$fc,$0f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 294 : 4516

song_000_02_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_02_lp)*2
	dw	song_000_02_lp


song_000_03:	;Trk D
	db	$fe,$8f,$fc,$51,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 93 : 0
	db	$fc,$28,$fd,$2a,$52,$29,$52,$14	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 300 : 243
	db	$52,$14,$52,$51,$52,$28,$52,$29	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 301 : 344
	db	$52,$51,$fc,$28,$fc,$29,$52,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 303 : 526
	db	$fc,$28,$fc,$51,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 306 : 769
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$29	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 310 : 1052
	db	$52,$51,$fc,$28,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 313 : 1335
	db	$fc,$3d,$52,$51,$fc,$14,$fc,$28	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 317 : 1618
	db	$52,$51,$fc,$29,$fc,$28,$52,$03	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 319 : 1820
	db	$52,$56,$fc,$21,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 321 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 325 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 329 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 333 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 337 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 341 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$52,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 343 : 3726
	db	$fc,$29,$fc,$28,$fc,$29,$fc,$28	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 344 : 3850
	db	$52,$29,$52,$14,$52,$14,$52,$51	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 346 : 4012
	db	$52,$2a,$52,$07,$52,$0e,$52,$0a	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 348 : 4174
	db	$52,$0b,$52,$03,$52,$05,$52,$3f	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 349 : 4247
	db	$52,$0a,$52,$29,$52,$03,$52,$12	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 350 : 4329
	db	$52,$15,$52,$0e,$52,$14,$52,$25	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 351 : 4401
	db	$52,$04,$fc,$13,$fc,$3e,$fc,$0f	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 352 : 4493

song_000_03_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_03_lp)*2
	dw	song_000_03_lp


song_000_04:	;Trk E
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 355 : 0
	db	$f4,$50,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 359 : 324
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 363 : 647
	db	$f4,$51,$f4,$51,$f4,$50,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 367 : 971
	db	$f4,$29,$00,$0c,$00,$08,$00,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 371 : 1294
	db	$00,$07,$00,$08,$00,$05,$00,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 371 : 1368
	db	$00,$0c,$00,$08,$00,$0c,$00,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 372 : 1396
	db	$00,$0d,$00,$07,$00,$08,$00,$05	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 372 : 1436
	db	$00,$07,$00,$0d,$00,$08,$00,$0c	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 373 : 1469
	db	$00,$08,$00,$0c,$00,$08,$00,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 373 : 1509
	db	$00,$05,$00,$07,$00,$0d,$00,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 374 : 1545
	db	$00,$07,$00,$05,$00,$1c,$00,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 374 : 1578
	db	$00,$05,$00,$14,$00,$07,$00,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 375 : 1626
	db	$00,$08,$00,$0c,$00,$08,$00,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 375 : 1671
	db	$00,$06,$00,$07,$00,$0d,$00,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 376 : 1706
	db	$00,$0d,$00,$08,$00,$14,$00,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 376 : 1739
	db	$00,$05,$00,$08,$00,$0d,$00,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 377 : 1787
	db	$00,$0d,$00,$07,$00,$0d,$00,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 377 : 1820
	db	$00,$07,$00,$05,$00,$08,$00,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 378 : 1861
	db	$00,$07,$00,$0d,$00,$07,$00,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 378 : 1894
	db	$00,$08,$00,$07,$00,$05,$00,$08	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 378 : 1934
	db	$00,$0d,$00,$0a,$00,$47,$f4,$30	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 379 : 1962
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$50	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 381 : 2104
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 385 : 2427
	db	$f4,$51,$f4,$51,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 389 : 2751
	db	$f4,$51,$f4,$50,$f4,$51,$f4,$51	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 393 : 3075
	db	$f4,$51,$f4,$51,$f4,$28,$f4,$2a	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 397 : 3398
	db	$f4,$0d,$f4,$47,$f4,$08,$f4,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 400 : 3642
	db	$f4,$20,$f4,$29,$f4,$51,$f4,$28	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 401 : 3737
	db	$f4,$29,$f4,$51,$f4,$51,$f4,$28	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 403 : 3931
	db	$f4,$2a,$f4,$07,$f4,$18,$f4,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 406 : 4174
	db	$f4,$05,$f4,$21,$f4,$1e,$f4,$33	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 407 : 4261
	db	$00,$03,$00,$12,$00,$15,$00,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 409 : 4380
	db	$00,$08,$00,$0c,$00,$03,$00,$09	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 409 : 4436
	db	$00,$10,$00,$09,$00,$17,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 410 : 4468
	db	$00,$49
song_000_04_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_04_lp)*2
	dw	song_000_04_lp


song_000_05:	;Trk F
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 413 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 417 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 421 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 425 : 971
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 429 : 1294
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$14	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 433 : 1618
	db	$fb,$08,$fd,$1e,$fe,$00,$38,$14	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 436 : 1881
	db	$fc,$29,$fc,$2b,$fc,$26,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 436 : 1901
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 439 : 2104
	db	$fc,$51,$fc,$29,$fd,$1d,$3a,$28	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 443 : 2427
	db	$41,$29,$fc,$28,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 445 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 448 : 2832
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 452 : 3156
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 456 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 458 : 3655
	db	$fc,$29,$fc,$51,$fc,$28,$fc,$29	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 459 : 3769
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 462 : 3972
	db	$fc,$07,$fc,$18,$fc,$0e,$fc,$05	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 465 : 4216
	db	$fc,$21,$fc,$1e,$fc,$33,$fc,$03	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 465 : 4266
	db	$fc,$12,$fc,$23,$fc,$14,$fc,$0c	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 467 : 4383
	db	$fc,$19,$fc,$17,$fc,$3e,$fc,$0f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 468 : 4468

song_000_05_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_05_lp)*2
	dw	song_000_05_lp


song_000_06:	;Trk G
	db	$fc,$28,$fb,$00,$fd,$20,$fe,$40	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 471 : 0
	db	$60,$06,$fc,$02,$60,$05,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 471 : 40
	db	$fc,$03,$60,$05,$fc,$02,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 471 : 58
	db	$60,$05,$fc,$03,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 471 : 73
	db	$63,$06,$63,$05,$fc,$02,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 472 : 88
	db	$fc,$03,$63,$05,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 472 : 106
	db	$60,$05,$fc,$03,$60,$05,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 472 : 121
	db	$fc,$03,$60,$05,$fc,$02,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 472 : 139
	db	$60,$05,$fc,$03,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 472 : 154
	db	$63,$05,$63,$05,$fc,$03,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 473 : 169
	db	$fc,$03,$63,$05,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 473 : 187
	db	$60,$05,$fc,$03,$60,$05,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 473 : 202
	db	$fc,$02,$60,$06,$fc,$02,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 473 : 220
	db	$60,$05,$fc,$03,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 473 : 235
	db	$63,$05,$63,$05,$fc,$03,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 474 : 250
	db	$fc,$03,$63,$05,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 474 : 268
	db	$65,$05,$fc,$03,$65,$05,$65,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 474 : 283
	db	$fc,$02,$65,$05,$fc,$03,$65,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 474 : 301
	db	$65,$05,$fc,$03,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 474 : 316
	db	$63,$05,$63,$05,$fc,$03,$fd,$22	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 475 : 331
	db	$40,$05,$fc,$02,$fd,$21,$40,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 475 : 344
	db	$50,$06,$fc,$02,$fd,$22,$55,$14	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 475 : 356
	db	$fc,$08,$fd,$21,$55,$02,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 475 : 384
	db	$55,$05,$fc,$02,$fd,$22,$55,$17	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 475 : 397
	db	$fc,$05,$fd,$21,$55,$03,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 476 : 427
	db	$55,$05,$fc,$03,$fd,$22,$55,$17	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 476 : 437
	db	$fc,$05,$fd,$21,$55,$02,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 476 : 468
	db	$55,$05,$fc,$02,$fd,$22,$41,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 476 : 478
	db	$fc,$05,$fd,$21,$41,$03,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 477 : 488
	db	$41,$05,$fc,$03,$fd,$22,$43,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 477 : 498
	db	$fc,$05,$fd,$21,$43,$03,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 477 : 508
	db	$43,$05,$fc,$03,$65,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 477 : 518
	db	$fd,$20,$50,$03,$fc,$02,$50,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 477 : 533
	db	$fc,$02,$50,$05,$fc,$03,$50,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 477 : 544
	db	$fc,$03,$50,$05,$fc,$02,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 477 : 556
	db	$fc,$03,$50,$02,$fc,$03,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 478 : 571
	db	$fc,$03,$50,$05,$fc,$02,$50,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 478 : 584
	db	$fc,$02,$50,$05,$fc,$03,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 478 : 597
	db	$fc,$02,$fd,$1f,$50,$03,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 478 : 612
	db	$fd,$20,$50,$05,$fc,$03,$fd,$1f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 478 : 619
	db	$50,$05,$fc,$03,$50,$02,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 478 : 627
	db	$50,$05,$fc,$02,$fd,$20,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 478 : 640
	db	$fc,$03,$50,$02,$fc,$03,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 479 : 652
	db	$fc,$02,$50,$05,$fc,$03,$50,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 479 : 665
	db	$fc,$02,$50,$05,$fc,$03,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 479 : 678
	db	$fc,$02,$50,$03,$fc,$02,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 479 : 693
	db	$fc,$03,$50,$05,$fc,$02,$50,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 479 : 705
	db	$fc,$03,$50,$05,$fc,$02,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 479 : 718
	db	$fc,$03,$50,$02,$fc,$03,$50,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 480 : 733
	db	$fc,$02,$50,$05,$fc,$03,$50,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 480 : 746
	db	$fc,$03,$4b,$05,$fc,$03,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 480 : 758
	db	$fc,$02,$63,$05,$63,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 480 : 774
	db	$63,$05,$fc,$02,$63,$05,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 480 : 789
	db	$fc,$03,$63,$05,$fc,$03,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 480 : 806
	db	$63,$05,$fc,$02,$63,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 481 : 822
	db	$63,$05,$62,$05,$fc,$02,$61,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 481 : 837
	db	$fc,$03,$61,$05,$61,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 481 : 854
	db	$61,$05,$fc,$02,$61,$05,$61,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 481 : 870
	db	$fc,$03,$61,$05,$fc,$02,$61,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 481 : 887
	db	$61,$05,$fc,$02,$61,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 482 : 903
	db	$61,$05,$61,$05,$fc,$02,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 482 : 918
	db	$fc,$03,$53,$05,$53,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 482 : 935
	db	$53,$05,$fc,$02,$53,$05,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 482 : 951
	db	$fc,$03,$61,$05,$fc,$02,$61,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 482 : 968
	db	$61,$05,$fc,$03,$61,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 483 : 983
	db	$61,$05,$62,$05,$fc,$02,$fd,$1f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 483 : 999
	db	$60,$05,$fc,$03,$fd,$20,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 483 : 1011
	db	$fd,$1f,$60,$05,$fc,$02,$60,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 483 : 1024
	db	$fc,$02,$fd,$20,$60,$05,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 483 : 1037
	db	$fc,$03,$60,$05,$fc,$02,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 483 : 1049
	db	$fd,$1f,$60,$05,$fc,$03,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 484 : 1064
	db	$60,$05,$fc,$02,$fd,$1f,$60,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 484 : 1072
	db	$fd,$20,$5b,$05,$fc,$02,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 484 : 1085
	db	$fc,$03,$63,$05,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 484 : 1097
	db	$63,$05,$fc,$03,$fd,$1f,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 484 : 1112
	db	$63,$05,$fc,$03,$fd,$20,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 484 : 1125
	db	$fc,$02,$63,$05,$fd,$1f,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 485 : 1138
	db	$fc,$03,$fd,$20,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 485 : 1150
	db	$63,$05,$62,$06,$fc,$02,$61,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 485 : 1160
	db	$fc,$03,$61,$05,$fd,$1f,$61,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 485 : 1178
	db	$fc,$02,$fd,$21,$61,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 485 : 1191
	db	$fd,$20,$61,$05,$61,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 485 : 1201
	db	$fd,$21,$61,$06,$fc,$02,$fd,$1f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 486 : 1213
	db	$61,$05,$fd,$20,$61,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 486 : 1221
	db	$fd,$21,$61,$05,$fc,$02,$fd,$1f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 486 : 1234
	db	$61,$05,$fd,$21,$61,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 486 : 1241
	db	$fd,$1f,$54,$05,$fc,$03,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 486 : 1254
	db	$54,$05,$fd,$1f,$54,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 486 : 1262
	db	$fd,$21,$54,$05,$fc,$03,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 486 : 1274
	db	$54,$05,$54,$05,$fc,$02,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 486 : 1282
	db	$fc,$03,$fd,$21,$60,$05,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 487 : 1299
	db	$60,$05,$fc,$03,$fd,$21,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 487 : 1307
	db	$fc,$02,$fd,$20,$60,$05,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 487 : 1320
	db	$60,$05,$fc,$03,$fd,$22,$39,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 487 : 1327
	db	$fc,$05,$fd,$20,$50,$03,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 487 : 1337
	db	$fd,$21,$50,$06,$fc,$02,$49,$14	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 487 : 1347
	db	$fc,$29,$3a,$05,$fc,$02,$39,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 488 : 1375
	db	$3a,$05,$fc,$03,$3a,$14,$fc,$29	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 488 : 1428
	db	$50,$02,$fc,$0a,$4b,$08,$38,$14	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 489 : 1497
	db	$fc,$29,$fd,$22,$40,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 490 : 1537
	db	$fd,$21,$43,$03,$fc,$02,$fd,$22	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 490 : 1585
	db	$40,$05,$fc,$03,$53,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 490 : 1590
	db	$fd,$21,$43,$03,$fc,$02,$53,$08	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 490 : 1605
	db	$fd,$22,$56,$05,$fc,$03,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 491 : 1618
	db	$53,$05,$56,$07,$53,$05,$fc,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 491 : 1626
	db	$43,$05,$40,$07,$fc,$29,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 491 : 1646
	db	$fc,$51,$fc,$51,$fc,$28,$50,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 493 : 1780
	db	$50,$03,$fc,$05,$53,$02,$fc,$08	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 495 : 1985
	db	$fd,$20,$53,$02,$fc,$08,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 495 : 2003
	db	$50,$02,$fc,$08,$50,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 495 : 2013
	db	$53,$03,$fc,$07,$fd,$20,$53,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 496 : 2033
	db	$fc,$07,$fd,$21,$50,$03,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 496 : 2046
	db	$50,$05,$fc,$06,$53,$02,$fc,$08	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 496 : 2063
	db	$fd,$20,$53,$02,$fc,$08,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 496 : 2084
	db	$50,$02,$fc,$08,$50,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 496 : 2094
	db	$53,$02,$fc,$08,$fd,$20,$53,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 497 : 2114
	db	$fc,$07,$fd,$21,$50,$03,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 497 : 2127
	db	$50,$05,$fc,$05,$53,$03,$fc,$08	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 497 : 2144
	db	$fd,$20,$53,$02,$fc,$08,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 497 : 2165
	db	$50,$02,$fc,$08,$50,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 497 : 2175
	db	$53,$02,$fc,$08,$fd,$20,$53,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 498 : 2195
	db	$fc,$07,$fd,$21,$50,$03,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 498 : 2208
	db	$50,$05,$fc,$05,$53,$03,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 498 : 2225
	db	$fd,$20,$53,$03,$fc,$08,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 498 : 2245
	db	$50,$02,$fc,$08,$50,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 498 : 2256
	db	$53,$02,$fc,$08,$fd,$20,$53,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 499 : 2276
	db	$fc,$08,$fd,$21,$50,$03,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 499 : 2288
	db	$53,$05,$fc,$05,$55,$03,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 499 : 2306
	db	$55,$03,$fc,$07,$fd,$20,$53,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 499 : 2326
	db	$fc,$08,$fd,$21,$53,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 499 : 2339
	db	$55,$02,$fc,$08,$55,$02,$fc,$08	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 500 : 2357
	db	$53,$02,$fc,$08,$53,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 500 : 2377
	db	$55,$03,$fc,$07,$55,$03,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 500 : 2397
	db	$53,$03,$fc,$07,$53,$06,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 500 : 2417
	db	$55,$02,$fc,$08,$55,$02,$fc,$08	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 501 : 2438
	db	$57,$02,$fc,$08,$4b,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 501 : 2458
	db	$54,$03,$fc,$07,$54,$03,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 501 : 2478
	db	$54,$03,$fc,$07,$54,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 501 : 2498
	db	$54,$03,$fc,$08,$54,$02,$fc,$08	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 502 : 2518
	db	$53,$02,$fc,$30,$fc,$29,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 502 : 2539
	db	$fc,$05,$fd,$20,$50,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 503 : 2635
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 503 : 2660
	db	$fc,$05,$fd,$20,$50,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 504 : 2675
	db	$53,$06,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 504 : 2700
	db	$fc,$05,$fd,$20,$50,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 504 : 2716
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 504 : 2741
	db	$fc,$05,$fd,$20,$50,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 505 : 2756
	db	$53,$05,$fc,$05,$fd,$21,$53,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 505 : 2781
	db	$fc,$05,$fd,$20,$50,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 505 : 2797
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 505 : 2822
	db	$fc,$05,$fd,$20,$50,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 506 : 2837
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 506 : 2862
	db	$fc,$06,$fd,$20,$50,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 506 : 2877
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 506 : 2903
	db	$fc,$05,$fd,$20,$50,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 507 : 2918
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 507 : 2943
	db	$fc,$05,$fd,$20,$51,$05,$fc,$10	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 507 : 2958
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 507 : 2984
	db	$fc,$05,$fd,$20,$51,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 508 : 2999
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 508 : 3024
	db	$fc,$05,$fd,$20,$51,$05,$fc,$10	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 508 : 3039
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 508 : 3065
	db	$fc,$05,$fd,$20,$51,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 509 : 3080
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 509 : 3105
	db	$fc,$05,$fd,$20,$51,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 509 : 3120
	db	$53,$05,$fc,$06,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 509 : 3145
	db	$fc,$05,$fd,$20,$51,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 510 : 3161
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 510 : 3186
	db	$fc,$05,$fd,$20,$51,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 510 : 3201
	db	$53,$05,$fc,$05,$fd,$21,$53,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 510 : 3226
	db	$fc,$06,$51,$05,$fc,$0f,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 511 : 3241
	db	$53,$05,$fc,$2d,$fc,$51,$fc,$51	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 511 : 3267
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 514 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 516 : 3655
	db	$fd,$21,$60,$06,$fc,$02,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 517 : 3769
	db	$60,$05,$60,$05,$fc,$03,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 517 : 3777
	db	$fc,$02,$fd,$21,$60,$05,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 517 : 3795
	db	$60,$05,$fc,$03,$fd,$21,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 517 : 3802
	db	$fc,$02,$fd,$20,$63,$06,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 518 : 3815
	db	$fc,$02,$63,$05,$fc,$03,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 518 : 3828
	db	$63,$05,$fd,$20,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 518 : 3838
	db	$fd,$21,$60,$05,$fc,$03,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 518 : 3850
	db	$60,$05,$60,$05,$fc,$03,$60,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 518 : 3858
	db	$fc,$02,$fd,$21,$60,$05,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 518 : 3876
	db	$60,$05,$fc,$03,$fd,$21,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 518 : 3883
	db	$fc,$02,$fd,$20,$63,$05,$63,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 519 : 3896
	db	$fc,$02,$63,$05,$fc,$03,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 519 : 3909
	db	$63,$05,$fd,$20,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 519 : 3919
	db	$fd,$21,$60,$05,$fc,$03,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 519 : 3931
	db	$60,$05,$60,$05,$fc,$02,$60,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 519 : 3939
	db	$fc,$02,$fd,$21,$60,$05,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 519 : 3957
	db	$60,$05,$fc,$03,$fd,$21,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 519 : 3964
	db	$fc,$02,$fd,$20,$63,$05,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 520 : 3977
	db	$fc,$03,$63,$05,$fc,$03,$fd,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 520 : 3989
	db	$63,$05,$fd,$20,$63,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 520 : 4000
	db	$fd,$21,$65,$05,$fc,$03,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 520 : 4012
	db	$65,$05,$65,$05,$fc,$02,$65,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 520 : 4020
	db	$fc,$03,$fd,$21,$65,$05,$fd,$20	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 520 : 4037
	db	$65,$05,$fc,$03,$fd,$21,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 520 : 4045
	db	$fc,$02,$fd,$20,$63,$05,$63,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 521 : 4058
	db	$fc,$03,$fd,$22,$40,$05,$fc,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 521 : 4070
	db	$fd,$21,$40,$05,$50,$08,$fd,$22	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 521 : 4080
	db	$55,$14,$fc,$08,$fd,$21,$55,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 521 : 4093
	db	$fc,$03,$55,$02,$fc,$06,$fd,$22	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 521 : 4123
	db	$55,$16,$fc,$05,$fd,$21,$55,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 522 : 4134
	db	$fc,$02,$55,$03,$fc,$05,$fd,$22	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 522 : 4164
	db	$55,$17,$fc,$06,$fd,$21,$55,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 522 : 4174
	db	$fc,$03,$55,$02,$fc,$06,$41,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 522 : 4205
	db	$fc,$05,$41,$03,$fc,$03,$41,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 523 : 4218
	db	$fc,$03,$43,$02,$fc,$06,$43,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 523 : 4234
	db	$fc,$03,$43,$05,$fc,$03,$fd,$22	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 523 : 4247
	db	$55,$03,$55,$05,$55,$0c,$fc,$08	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 523 : 4258
	db	$fd,$21,$55,$02,$fc,$03,$55,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 523 : 4286
	db	$fc,$05,$fd,$22,$55,$16,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 523 : 4294
	db	$fd,$21,$55,$03,$fc,$02,$55,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 524 : 4326
	db	$fc,$05,$fd,$22,$55,$17,$fc,$05	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 524 : 4334
	db	$fd,$21,$55,$03,$fc,$02,$55,$03	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 524 : 4367
	db	$fc,$05,$41,$03,$fc,$05,$41,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 524 : 4375
	db	$fc,$03,$41,$05,$fc,$03,$43,$02	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 525 : 4390
	db	$fc,$06,$43,$02,$fc,$03,$43,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 525 : 4403
	db	$fc,$02,$50,$0e,$50,$14,$50,$25	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 525 : 4420
	db	$50,$17,$50,$04,$25,$19,$fc,$21	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 526 : 4493
	db	$fc,$0f
song_000_06_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_06_lp)*2
	dw	song_000_06_lp


song_000_07:	;Trk H
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 529 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 533 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 537 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 541 : 971
	db	$fc,$51,$fc,$3d,$fb,$00,$fd,$21	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 545 : 1294
	db	$fe,$40,$57,$14,$fc,$35,$41,$05	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 546 : 1436
	db	$fc,$0f,$4a,$08,$fc,$51,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 547 : 1514
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$2b	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 550 : 1699
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 553 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 557 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 561 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 565 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 569 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 573 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 575 : 3726
	db	$fc,$51,$fc,$28,$fc,$29,$fc,$51	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 576 : 3810
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 579 : 4053
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 581 : 4223
	db	$fc,$1e,$fc,$33,$fc,$03,$fc,$12	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 582 : 4299
	db	$fc,$23,$fc,$14,$fc,$0c,$fc,$19	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 583 : 4401
	db	$fc,$17,$fc,$3e,$fc,$0f
song_000_07_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_07_lp)*2
	dw	song_000_07_lp


song_000_08:	;Trk I
	db	$fc,$51,$fd,$24,$fe,$06,$35,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 587 : 0
	db	$fc,$05,$3b,$03,$fc,$03,$36,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 588 : 83
	db	$fc,$02,$46,$03,$fc,$05,$3b,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 588 : 99
	db	$fc,$03,$35,$05,$fc,$2b,$45,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 588 : 111
	db	$fc,$05,$4b,$03,$fc,$02,$46,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 589 : 164
	db	$fc,$05,$53,$03,$fc,$05,$4b,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 589 : 177
	db	$fc,$03,$45,$02,$fc,$2e,$35,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 589 : 192
	db	$fc,$05,$3b,$03,$fc,$02,$36,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 590 : 245
	db	$fc,$05,$46,$02,$fc,$06,$45,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 590 : 258
	db	$fc,$03,$4b,$05,$fc,$02,$fd,$25	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 590 : 273
	db	$46,$14,$fc,$08,$53,$02,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 590 : 283
	db	$53,$05,$fc,$03,$46,$14,$3b,$14	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 590 : 316
	db	$40,$08,$fc,$0c,$39,$08,$fc,$0c	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 591 : 364
	db	$35,$15,$fc,$07,$fd,$24,$34,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 592 : 404
	db	$fc,$02,$34,$05,$fc,$03,$fd,$25	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 592 : 435
	db	$51,$17,$fc,$05,$fd,$24,$48,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 592 : 445
	db	$45,$07,$3a,$03,$fc,$05,$45,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 592 : 478
	db	$fc,$02,$51,$05,$fc,$03,$53,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 593 : 496
	db	$fc,$05,$47,$03,$fc,$02,$53,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 593 : 508
	db	$fc,$03,$45,$07,$fc,$21,$fc,$51	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 593 : 523
	db	$fc,$29,$35,$1e,$39,$03,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 595 : 647
	db	$30,$3d,$fc,$0a,$33,$02,$fc,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 596 : 728
	db	$33,$19,$fc,$03,$32,$02,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 597 : 809
	db	$31,$05,$fc,$02,$30,$9b,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 597 : 842
	db	$35,$0a,$fc,$03,$39,$05,$fc,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 599 : 1011
	db	$30,$72,$fc,$08,$fd,$25,$3a,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 599 : 1031
	db	$37,$03,$fc,$02,$3a,$08,$fd,$24	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 601 : 1160
	db	$30,$72,$fc,$07,$36,$05,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 601 : 1173
	db	$fc,$05,$46,$05,$fc,$03,$45,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 603 : 1302
	db	$fc,$05,$4a,$03,$fc,$02,$50,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 603 : 1317
	db	$45,$02,$fc,$12,$39,$0d,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 603 : 1335
	db	$45,$03,$fc,$05,$45,$02,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 604 : 1375
	db	$45,$02,$fc,$06,$45,$02,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 604 : 1388
	db	$50,$08,$3a,$02,$fc,$05,$42,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 604 : 1408
	db	$fc,$02,$43,$03,$fc,$19,$4a,$19	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 604 : 1426
	db	$fc,$03,$49,$03,$fc,$02,$48,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 605 : 1481
	db	$fc,$05,$45,$02,$fc,$05,$45,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 605 : 1492
	db	$fc,$02,$44,$08,$45,$02,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 605 : 1507
	db	$4a,$06,$fc,$02,$44,$03,$fc,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 605 : 1529
	db	$45,$02,$fc,$03,$44,$02,$fc,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 606 : 1545
	db	$45,$0d,$44,$02,$fc,$06,$46,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 606 : 1557
	db	$fc,$05,$46,$03,$fc,$02,$46,$12	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 606 : 1580
	db	$fc,$0a,$48,$03,$fc,$05,$48,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 606 : 1608
	db	$fc,$03,$48,$11,$fc,$03,$48,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 607 : 1628
	db	$fc,$05,$40,$03,$fc,$0a,$45,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 607 : 1653
	db	$fc,$05,$49,$6f,$fc,$0a,$50,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 607 : 1674
	db	$fc,$05,$4a,$02,$fc,$03,$50,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 609 : 1803
	db	$fc,$02,$51,$03,$fc,$26,$55,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 609 : 1818
	db	$fc,$12,$48,$14,$45,$05,$fc,$0f	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 610 : 1863
	db	$47,$15,$fc,$2b,$fc,$26,$fc,$51	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 610 : 1921
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 613 : 2104
	db	$fc,$51,$fc,$51,$fc,$29,$48,$3c	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 617 : 2427
	db	$fc,$0a,$33,$06,$fc,$05,$33,$37	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 620 : 2690
	db	$fc,$05,$33,$05,$fc,$05,$48,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 621 : 2766
	db	$fc,$05,$46,$3d,$fc,$0a,$33,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 621 : 2786
	db	$fc,$05,$33,$3b,$fc,$02,$30,$0a	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 622 : 2867
	db	$33,$05,$fc,$05,$45,$1f,$47,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 623 : 2943
	db	$fc,$05,$48,$5b,$fc,$0a,$45,$0a	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 623 : 2989
	db	$48,$05,$fc,$05,$51,$4e,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 625 : 3105
	db	$50,$26,$fc,$02,$4a,$26,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 626 : 3196
	db	$fd,$23,$46,$4e,$fc,$03,$46,$3c	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 627 : 3277
	db	$fc,$0d,$46,$05,$fc,$03,$46,$51	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 629 : 3418
	db	$46,$50,$46,$2a,$45,$0d,$45,$1d	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 630 : 3520
	db	$fd,$24,$44,$15,$4b,$15,$4b,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 632 : 3684
	db	$4b,$03,$4b,$20,$fc,$29,$35,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 633 : 3734
	db	$fc,$05,$3b,$03,$fc,$03,$36,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 634 : 3812
	db	$fc,$02,$46,$03,$fc,$05,$3b,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 634 : 3828
	db	$fc,$03,$35,$05,$fc,$2b,$45,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 634 : 3840
	db	$fc,$05,$4b,$03,$fc,$02,$46,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 635 : 3893
	db	$fc,$05,$53,$03,$fc,$05,$4b,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 635 : 3906
	db	$fc,$03,$45,$02,$fc,$05,$fc,$29	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 635 : 3921
	db	$35,$02,$fc,$05,$3b,$03,$fc,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 636 : 3972
	db	$36,$03,$fc,$05,$46,$02,$fc,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 636 : 3984
	db	$45,$02,$fc,$03,$4b,$05,$fc,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 636 : 4000
	db	$fd,$25,$46,$14,$fc,$08,$53,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 636 : 4012
	db	$fc,$03,$53,$05,$fc,$03,$46,$14	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 636 : 4042
	db	$3b,$14,$40,$08,$fc,$0c,$39,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 637 : 4073
	db	$fc,$0d,$35,$14,$fc,$07,$fd,$24	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 637 : 4121
	db	$34,$03,$fc,$02,$34,$05,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 638 : 4161
	db	$45,$17,$fc,$06,$48,$05,$45,$08	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 638 : 4174
	db	$3a,$02,$fc,$05,$45,$03,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 639 : 4216
	db	$51,$05,$fc,$03,$53,$02,$fc,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 639 : 4229
	db	$47,$02,$fc,$03,$53,$05,$fc,$03	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 639 : 4245
	db	$fd,$25,$40,$03,$40,$05,$fc,$0c	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 639 : 4258
	db	$39,$08,$fc,$0d,$35,$14,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 639 : 4278
	db	$fd,$24,$34,$03,$fc,$02,$34,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 640 : 4326
	db	$fc,$02,$45,$17,$fc,$05,$48,$05	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 640 : 4337
	db	$45,$08,$3a,$03,$fc,$05,$45,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 640 : 4372
	db	$fc,$03,$51,$05,$fc,$03,$53,$02	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 641 : 4390
	db	$fc,$06,$47,$02,$fc,$03,$53,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 641 : 4403
	db	$fc,$02,$45,$0e,$45,$14,$45,$25	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 641 : 4420
	db	$45,$17,$45,$04,$45,$19,$fc,$21	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 642 : 4493
	db	$fc,$0f
song_000_08_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_08_lp)*2
	dw	song_000_08_lp


song_000_09:	;Trk J
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 645 : 0
	db	$fd,$25,$fe,$06,$56,$14,$fc,$15	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 648 : 283
	db	$56,$14,$43,$14,$fc,$28,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 649 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 651 : 485
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 655 : 809
	db	$fc,$50,$fc,$51,$fc,$29,$fd,$24	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 659 : 1133
	db	$49,$02,$fc,$12,$49,$0d,$fc,$07	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 661 : 1335
	db	$39,$03,$fc,$0a,$40,$02,$fc,$42	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 662 : 1375
	db	$fc,$49,$53,$06,$fc,$02,$40,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 663 : 1456
	db	$fc,$05,$41,$02,$fc,$03,$40,$02	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 664 : 1540
	db	$fc,$05,$41,$0d,$40,$02,$fc,$06	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 664 : 1552
	db	$43,$02,$fc,$05,$43,$03,$fc,$02	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 664 : 1578
	db	$43,$12,$fc,$0a,$43,$03,$fc,$05	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 664 : 1590
	db	$43,$02,$fc,$03,$43,$11,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 665 : 1626
	db	$43,$02,$fc,$2e,$fc,$51,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 665 : 1651
	db	$fc,$51,$fc,$2b,$fc,$26,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 668 : 1861
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 671 : 2104
	db	$fc,$51,$fc,$51,$fc,$29,$40,$3f	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 675 : 2427
	db	$fc,$07,$43,$06,$fc,$05,$43,$37	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 678 : 2693
	db	$fc,$05,$43,$05,$fc,$05,$43,$05	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 679 : 2766
	db	$fc,$05,$3a,$3d,$fc,$0a,$43,$05	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 679 : 2786
	db	$fc,$05,$43,$3b,$fc,$3f,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 680 : 2867
	db	$fc,$51,$fc,$50,$fc,$29,$fd,$23	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 683 : 3075
	db	$50,$4e,$fc,$03,$50,$3c,$fc,$0d	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 685 : 3277
	db	$51,$05,$fc,$03,$50,$51,$50,$50	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 687 : 3431
	db	$50,$2a,$51,$0d,$51,$1d,$fd,$24	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 689 : 3600
	db	$52,$15,$43,$15,$55,$08,$55,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 690 : 3684
	db	$55,$0b,$56,$15,$fc,$29,$fc,$51	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 691 : 3737
	db	$fc,$28,$fc,$29,$fc,$28,$fd,$25	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 693 : 3891
	db	$56,$14,$fc,$15,$56,$14,$43,$14	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 694 : 4012
	db	$fc,$29,$fc,$28,$fc,$2a,$fc,$07	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 695 : 4093
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 697 : 4223
	db	$fc,$1e,$fc,$33,$fc,$03,$fc,$12	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 698 : 4299
	db	$fc,$15,$55,$0e,$55,$14,$55,$25	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 699 : 4401
	db	$55,$17,$55,$04,$fc,$3a,$fc,$0f	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 700 : 4493

song_000_09_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_09_lp)*2
	dw	song_000_09_lp


song_000_10:	;Trk K
	db	$fc,$28,$fd,$28,$fe,$07,$4b,$33	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 703 : 0
	db	$fc,$0a,$4b,$03,$fc,$0a,$4b,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 704 : 91
	db	$fc,$05,$4b,$33,$fc,$0a,$4b,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 704 : 116
	db	$fc,$0a,$4b,$02,$fc,$05,$4b,$33	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 705 : 185
	db	$fc,$0a,$4b,$02,$fc,$0b,$4b,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 706 : 253
	db	$fc,$05,$4b,$33,$fc,$0a,$4b,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 706 : 278
	db	$fc,$12,$45,$05,$fc,$0f,$39,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 707 : 346
	db	$fc,$03,$50,$02,$fc,$03,$50,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 707 : 389
	db	$fc,$05,$35,$15,$35,$14,$35,$28	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 707 : 399
	db	$3a,$1f,$37,$0a,$fd,$27,$65,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 709 : 485
	db	$fc,$02,$60,$05,$57,$08,$55,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 709 : 531
	db	$fc,$03,$50,$05,$47,$07,$45,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 709 : 551
	db	$fc,$03,$40,$05,$39,$08,$35,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 710 : 571
	db	$fc,$02,$40,$05,$39,$08,$45,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 710 : 592
	db	$fc,$02,$fd,$26,$50,$05,$fd,$27	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 710 : 612
	db	$49,$08,$55,$05,$fc,$03,$fd,$26	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 710 : 619
	db	$60,$05,$fd,$27,$59,$07,$65,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 710 : 635
	db	$fc,$3d,$fc,$21,$fd,$28,$49,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 711 : 667
	db	$fc,$03,$50,$50,$fc,$29,$fc,$51	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 712 : 766
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 715 : 971
	db	$fc,$29,$35,$21,$39,$05,$fc,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 719 : 1294
	db	$40,$4a,$fc,$07,$43,$1c,$42,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 720 : 1375
	db	$fc,$02,$41,$05,$fc,$03,$40,$51	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 721 : 1487
	db	$fc,$28,$fc,$28,$fd,$29,$45,$08	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 722 : 1578
	db	$fc,$05,$fd,$28,$49,$05,$fc,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 723 : 1666
	db	$50,$74,$fc,$05,$53,$03,$fc,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 723 : 1679
	db	$52,$02,$fc,$03,$53,$05,$fc,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 725 : 1808
	db	$45,$1f,$fc,$02,$48,$03,$fc,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 725 : 1820
	db	$45,$3c,$3b,$15,$44,$28,$18,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 726 : 1861
	db	$18,$81,$fc,$0a,$17,$12,$fc,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 727 : 1985
	db	$16,$77,$fc,$03,$fc,$14,$20,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 729 : 2144
	db	$15,$a2,$14,$51,$1a,$28,$19,$29	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 731 : 2306
	db	$18,$51,$fc,$28,$fc,$28,$16,$51	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 735 : 2630
	db	$fc,$29,$fc,$51,$fc,$51,$fc,$51	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 738 : 2872
	db	$fc,$50,$fc,$51,$fd,$27,$5a,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 742 : 3156
	db	$fc,$03,$56,$05,$51,$08,$50,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 744 : 3322
	db	$fc,$02,$4a,$05,$46,$08,$43,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 744 : 3343
	db	$fc,$02,$3a,$05,$43,$08,$4a,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 744 : 3363
	db	$fc,$03,$46,$05,$5a,$35,$fc,$23	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 744 : 3383
	db	$59,$08,$56,$05,$51,$07,$50,$08	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 746 : 3479
	db	$49,$05,$46,$08,$43,$07,$39,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 746 : 3507
	db	$41,$08,$49,$07,$43,$05,$59,$2e	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 746 : 3532
	db	$fc,$02,$1a,$28,$fc,$02,$19,$0d	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 747 : 3598
	db	$19,$1a,$fc,$03,$18,$12,$fc,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 748 : 3655
	db	$17,$13,$fc,$02,$fd,$28,$16,$08	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 748 : 3705
	db	$16,$03,$16,$0b,$fd,$27,$15,$15	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 749 : 3734
	db	$fd,$28,$4b,$33,$fc,$0a,$4b,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 749 : 3769
	db	$fc,$0a,$4b,$05,$fc,$02,$4b,$33	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 750 : 3833
	db	$fc,$0a,$4b,$03,$fc,$0a,$4b,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 751 : 3901
	db	$fc,$02,$4b,$33,$fc,$0a,$4b,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 751 : 3929
	db	$fc,$0b,$4b,$05,$fc,$02,$4b,$33	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 752 : 3994
	db	$fc,$0a,$fd,$29,$4b,$02,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 753 : 4063
	db	$4b,$06,$fc,$02,$fd,$28,$45,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 753 : 4085
	db	$fc,$0f,$39,$05,$fc,$03,$50,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 753 : 4098
	db	$fc,$03,$50,$02,$fc,$06,$35,$14	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 753 : 4123
	db	$35,$14,$fd,$29,$35,$2a,$3a,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 754 : 4154
	db	$3a,$18,$37,$0b,$fd,$28,$45,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 755 : 4223
	db	$45,$02,$fc,$03,$fc,$0c,$39,$05	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 755 : 4261
	db	$fc,$03,$50,$02,$fc,$03,$50,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 755 : 4283
	db	$fc,$05,$fd,$29,$35,$14,$35,$0a	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 755 : 4294
	db	$35,$0a,$35,$29,$fd,$28,$3a,$03	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 756 : 4329
	db	$3a,$12,$3a,$0a,$37,$09,$fc,$02	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 757 : 4383
	db	$fd,$29,$35,$0e,$35,$14,$35,$25	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 757 : 4422
	db	$35,$17,$35,$04,$fd,$28,$35,$16	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 758 : 4493
	db	$fc,$24,$fc,$0f
song_000_10_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_10_lp)*2
	dw	song_000_10_lp


song_000_11:	;Trk L
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 761 : 0
	db	$fc,$28,$fd,$28,$fe,$07,$50,$14	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 765 : 324
	db	$fc,$14,$40,$15,$fc,$07,$50,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 765 : 384
	db	$fc,$02,$50,$03,$fc,$2d,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 766 : 435
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 768 : 566
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 772 : 890
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 776 : 1213
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 780 : 1537
	db	$55,$1f,$fc,$02,$45,$05,$fc,$03	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 783 : 1820
	db	$55,$51,$50,$28,$fc,$03,$fc,$26	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 784 : 1861
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 786 : 2023
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 790 : 2347
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 794 : 2670
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 798 : 2994
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 802 : 3317
	db	$fc,$2a,$fc,$0d,$fc,$47,$fc,$08	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 805 : 3600
	db	$fc,$03,$fc,$20,$fc,$29,$fc,$51	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 807 : 3734
	db	$fc,$28,$fc,$29,$fc,$51,$fc,$28	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 809 : 3891
	db	$50,$14,$fc,$15,$40,$14,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 811 : 4093
	db	$50,$03,$fc,$02,$50,$03,$fc,$05	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 812 : 4161
	db	$fc,$2a,$fc,$07,$fc,$18,$fc,$0b	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 812 : 4174
	db	$50,$03,$50,$05,$50,$0c,$fc,$15	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 813 : 4258
	db	$fd,$29,$40,$14,$fc,$07,$fd,$28	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 814 : 4299
	db	$50,$03,$fc,$02,$50,$03,$fc,$2e	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 814 : 4326
	db	$fc,$03,$fc,$12,$fc,$23,$fc,$14	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 815 : 4380
	db	$fc,$0c,$fc,$19,$fc,$17,$fc,$3e	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 815 : 4456
	db	$fc,$0f
song_000_11_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_11_lp)*2
	dw	song_000_11_lp


song_000_12:	;Trk M
	db	$fc,$14,$fb,$05,$fd,$09,$fe,$01	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 819 : 0
	db	$4a,$05,$fc,$03,$45,$05,$3a,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 819 : 20
	db	$35,$03,$fd,$08,$35,$03,$fc,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 819 : 40
	db	$fd,$09,$35,$03,$fd,$08,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 819 : 48
	db	$35,$03,$fc,$02,$35,$03,$fd,$09	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 819 : 53
	db	$35,$02,$35,$03,$fc,$02,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 819 : 61
	db	$35,$02,$35,$03,$fc,$05,$3b,$26	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 819 : 71
	db	$fc,$02,$35,$03,$35,$02,$fc,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 820 : 119
	db	$35,$02,$fd,$08,$35,$03,$fd,$09	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 820 : 129
	db	$35,$03,$fc,$02,$fd,$08,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 820 : 134
	db	$fd,$09,$35,$02,$35,$03,$fc,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 820 : 142
	db	$35,$03,$35,$02,$35,$03,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 820 : 149
	db	$3b,$26,$fc,$02,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 821 : 162
	db	$fc,$03,$35,$02,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 821 : 207
	db	$fc,$03,$35,$02,$35,$03,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 821 : 217
	db	$fc,$02,$35,$03,$35,$02,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 821 : 228
	db	$fc,$05,$3b,$26,$fc,$02,$fd,$0a	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 821 : 238
	db	$35,$17,$fc,$05,$fd,$09,$3a,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 822 : 283
	db	$fc,$03,$3a,$03,$fc,$05,$45,$11	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 822 : 313
	db	$fc,$03,$3b,$12,$fc,$02,$30,$17	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 823 : 341
	db	$fc,$11,$fc,$29,$30,$19,$fc,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 823 : 387
	db	$47,$02,$fc,$03,$47,$02,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 824 : 473
	db	$3b,$03,$3b,$02,$fc,$03,$3b,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 825 : 485
	db	$3b,$02,$3b,$03,$fc,$02,$3b,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 825 : 496
	db	$3b,$02,$3b,$03,$fc,$02,$3b,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 825 : 506
	db	$3b,$02,$3b,$03,$fc,$02,$3b,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 825 : 516
	db	$fd,$0a,$34,$3d,$fc,$3c,$fc,$29	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 825 : 526
	db	$fd,$09,$34,$3c,$fc,$3d,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 827 : 688
	db	$fc,$51,$fc,$14,$fb,$06,$fd,$12	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 830 : 890
	db	$fe,$02,$49,$05,$fc,$03,$4a,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 831 : 991
	db	$44,$07,$45,$0d,$47,$02,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 831 : 1004
	db	$45,$72,$fc,$08,$4a,$05,$fc,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 831 : 1031
	db	$47,$03,$fc,$02,$4a,$08,$45,$47	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 833 : 1160
	db	$fc,$0a,$fb,$05,$fd,$09,$fe,$01	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 834 : 1244
	db	$40,$26,$fc,$02,$34,$03,$34,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 834 : 1254
	db	$fc,$03,$34,$02,$34,$03,$34,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 835 : 1299
	db	$fc,$02,$34,$03,$34,$02,$34,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 835 : 1310
	db	$fc,$02,$34,$03,$34,$02,$34,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 835 : 1320
	db	$fc,$02,$fd,$0a,$34,$03,$fd,$09	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 835 : 1330
	db	$35,$21,$fc,$07,$fc,$29,$38,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 835 : 1335
	db	$fc,$02,$42,$05,$38,$08,$42,$14	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 836 : 1421
	db	$fc,$29,$37,$05,$fc,$0f,$37,$14	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 837 : 1456
	db	$fc,$29,$35,$0a,$fc,$02,$35,$14	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 838 : 1537
	db	$fc,$08,$35,$05,$fc,$03,$47,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 838 : 1610
	db	$35,$14,$fc,$07,$3b,$0b,$fc,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 839 : 1631
	db	$35,$08,$3b,$14,$fc,$28,$37,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 839 : 1671
	db	$fc,$03,$37,$05,$33,$08,$37,$14	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 840 : 1744
	db	$fc,$51,$fc,$51,$fc,$14,$fb,$06	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 841 : 1780
	db	$fd,$12,$fe,$02,$53,$05,$fc,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 843 : 1962
	db	$fd,$11,$45,$05,$fd,$12,$47,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 843 : 1970
	db	$58,$03,$58,$44,$53,$05,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 843 : 1982
	db	$53,$26,$fc,$03,$53,$14,$58,$14	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 844 : 2063
	db	$5a,$42,$fc,$05,$53,$05,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 845 : 2144
	db	$53,$33,$fc,$0a,$60,$0a,$63,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 846 : 2225
	db	$fc,$05,$61,$23,$fc,$03,$fd,$11	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 847 : 2301
	db	$59,$03,$fd,$12,$58,$5b,$fc,$0a	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 847 : 2344
	db	$45,$05,$fc,$05,$47,$05,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 849 : 2448
	db	$fd,$11,$59,$02,$fd,$12,$58,$4c	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 849 : 2468
	db	$fc,$03,$5a,$47,$47,$05,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 850 : 2546
	db	$61,$02,$60,$9f,$fc,$29,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 851 : 2630
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 855 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 859 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 863 : 3560
	db	$fb,$05,$fd,$09,$fe,$01,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3726
	db	$35,$02,$fc,$03,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3729
	db	$35,$03,$fc,$03,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3739
	db	$35,$03,$fc,$03,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3750
	db	$35,$03,$fc,$03,$35,$02,$35,$08	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3761
	db	$35,$03,$fd,$08,$35,$02,$fd,$09	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3777
	db	$35,$03,$fc,$02,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3782
	db	$35,$03,$fc,$02,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3792
	db	$35,$03,$fc,$02,$35,$03,$fd,$0a	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 865 : 3802
	db	$3b,$28,$fd,$09,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 866 : 3810
	db	$fc,$03,$35,$02,$fd,$08,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 866 : 3855
	db	$fd,$09,$35,$03,$fc,$02,$fd,$08	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 866 : 3863
	db	$35,$03,$fd,$09,$35,$02,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 866 : 3868
	db	$fc,$02,$35,$03,$35,$02,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 866 : 3876
	db	$fc,$02,$35,$03,$fd,$0a,$3b,$28	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 866 : 3886
	db	$fd,$09,$35,$03,$35,$02,$fc,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 867 : 3931
	db	$35,$02,$fd,$08,$35,$03,$fd,$09	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 867 : 3939
	db	$35,$02,$fc,$03,$fd,$08,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 867 : 3944
	db	$fd,$09,$35,$03,$fd,$08,$35,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 867 : 3951
	db	$fc,$02,$fd,$09,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 867 : 3957
	db	$35,$03,$fc,$02,$35,$03,$3b,$28	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 867 : 3964
	db	$35,$12,$fc,$02,$35,$03,$35,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 868 : 4012
	db	$fc,$03,$3a,$02,$fc,$03,$3a,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 868 : 4037
	db	$fc,$05,$45,$28,$35,$12,$fc,$17	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 868 : 4048
	db	$fc,$28,$3b,$1a,$fc,$03,$50,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 870 : 4134
	db	$fc,$03,$50,$02,$fc,$06,$31,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 870 : 4205
	db	$31,$0b,$fc,$03,$31,$0a,$31,$08	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 871 : 4223
	db	$fc,$03,$35,$03,$35,$05,$35,$0a	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 871 : 4255
	db	$fc,$17,$fc,$1e,$fc,$0a,$3b,$1c	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 871 : 4276
	db	$50,$03,$fc,$02,$50,$03,$fc,$05	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 872 : 4367
	db	$3b,$03,$3b,$02,$fc,$03,$3b,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 873 : 4380
	db	$3b,$03,$3b,$02,$fc,$03,$3b,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 873 : 4390
	db	$3b,$02,$3b,$03,$fc,$03,$3b,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 873 : 4401
	db	$3b,$03,$3b,$03,$fc,$03,$3b,$02	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 873 : 4411
	db	$35,$0b,$fc,$03,$35,$08,$3b,$09	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 873 : 4422
	db	$fc,$03,$fc,$03,$35,$09,$35,$04	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 873 : 4453
	db	$fc,$0c,$35,$09,$35,$04,$fc,$06	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 874 : 4472
	db	$35,$04,$fc,$03,$35,$03,$fc,$03	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 874 : 4503
	db	$fc,$04,$fd,$0a,$35,$21,$fc,$19	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 874 : 4516
	db	$fc,$0f
song_000_12_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_12_lp)*2
	dw	song_000_12_lp


song_000_13:	;Trk N
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 877 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 881 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 885 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$29	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 889 : 971
	db	$fb,$04,$fd,$0f,$fe,$00,$20,$21	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 892 : 1254
	db	$fc,$07,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 892 : 1287
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 896 : 1537
	db	$fc,$51,$fc,$2b,$fc,$26,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 900 : 1861
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 903 : 2104
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 907 : 2427
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 911 : 2751
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 915 : 3075
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 919 : 3398
	db	$fc,$0d,$fc,$47,$fc,$08,$fc,$03	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 922 : 3642
	db	$fc,$20,$fc,$29,$fc,$51,$fc,$28	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 923 : 3737
	db	$fc,$29,$fc,$51,$fc,$51,$fc,$28	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 925 : 3931
	db	$fc,$2a,$fc,$07,$fc,$18,$fc,$0e	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 928 : 4174
	db	$fc,$05,$fc,$21,$fc,$1e,$fc,$33	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 929 : 4261
	db	$fc,$03,$fc,$12,$fc,$23,$fc,$14	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 931 : 4380
	db	$fc,$0c,$fc,$19,$fc,$17,$fc,$3e	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 931 : 4456
	db	$fc,$0f
song_000_13_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_13_lp)*2
	dw	song_000_13_lp


song_000_14:	;Trk O
	db	$fc,$51,$fb,$04,$fd,$1b,$2b,$28	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 935 : 0
	db	$2b,$29,$fd,$1a,$2b,$28,$fd,$1b	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 936 : 121
	db	$25,$29,$25,$28,$2b,$17,$fc,$05	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 937 : 202
	db	$2b,$02,$fc,$03,$fd,$1a,$2b,$03	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 938 : 311
	db	$fc,$05,$fd,$1b,$26,$26,$fc,$2a	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 938 : 319
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$29	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 940 : 404
	db	$25,$1b,$fc,$03,$29,$03,$fc,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 943 : 688
	db	$fd,$1a,$40,$3d,$fc,$0a,$23,$02	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 944 : 728
	db	$fc,$08,$fd,$1b,$43,$1c,$42,$02	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 944 : 801
	db	$fc,$03,$fd,$1a,$41,$05,$fc,$02	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 945 : 839
	db	$fd,$1b,$40,$9b,$fc,$07,$fd,$1c	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 945 : 849
	db	$25,$0d,$fd,$1a,$29,$05,$fc,$02	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 947 : 1011
	db	$fd,$1b,$40,$72,$fc,$08,$2a,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 947 : 1031
	db	$fd,$1a,$27,$03,$fc,$02,$fd,$1b	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 949 : 1160
	db	$2a,$08,$40,$72,$fc,$07,$fc,$29	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 949 : 1165
	db	$fd,$1c,$25,$02,$fc,$12,$fd,$1b	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 951 : 1335
	db	$25,$14,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 951 : 1355
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 955 : 1618
	db	$fc,$2b,$fc,$26,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 959 : 1942
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 962 : 2185
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 966 : 2508
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 970 : 2832
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 974 : 3156
	db	$fc,$51,$ee
	db	bank(song_000_14_bnk003)*2
	dw	song_000_14_bnk003

	.bank	3
	.org	$e000
song_000_14_bnk003:
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 979 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 981 : 3726
	db	$2b,$28,$fd,$1c,$2b,$29,$fd,$1b	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 982 : 3810
	db	$2b,$14,$fc,$14,$fd,$1c,$25,$29	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 983 : 3891
	db	$fd,$1b,$25,$14,$fc,$14,$fd,$1c	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 984 : 3972
	db	$2b,$14,$fc,$15,$26,$28,$fc,$29	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 984 : 4012
	db	$fc,$28,$fc,$2a,$fc,$07,$fc,$18	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 986 : 4134
	db	$fc,$0e,$fc,$05,$fc,$21,$fc,$1e	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 987 : 4247
	db	$fc,$33,$fc,$03,$fc,$12,$fc,$23	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 988 : 4329
	db	$fc,$14,$fc,$0c,$fc,$19,$fc,$17	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 989 : 4436
	db	$fc,$3e,$fc,$0f
song_000_14_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_14_lp)*2
	dw	song_000_14_lp


song_000_15:	;Trk P
	db	$fc,$28,$fb,$00,$ef,$07,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 993 : 0
	db	$fe,$00,$69,$06,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 993 : 40
	db	$69,$05,$69,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 993 : 48
	db	$69,$05,$fc,$02,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 993 : 61
	db	$fc,$03,$69,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 993 : 78
	db	$69,$06,$fd,$02,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 994 : 88
	db	$69,$05,$fc,$03,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 994 : 101
	db	$fc,$02,$69,$05,$fc,$03,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 994 : 119
	db	$69,$05,$69,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 994 : 129
	db	$69,$05,$fc,$02,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 994 : 142
	db	$fc,$03,$69,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 994 : 159
	db	$69,$05,$fd,$02,$69,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 995 : 169
	db	$69,$05,$fc,$03,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 995 : 182
	db	$fc,$02,$69,$05,$fc,$03,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 995 : 200
	db	$69,$05,$69,$05,$fc,$02,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 995 : 210
	db	$69,$06,$fc,$02,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 995 : 222
	db	$fc,$03,$69,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 995 : 240
	db	$69,$05,$fd,$02,$69,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 996 : 250
	db	$69,$05,$fc,$03,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 996 : 263
	db	$fc,$02,$69,$05,$fc,$03,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 996 : 281
	db	$69,$05,$69,$05,$fc,$02,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 996 : 291
	db	$69,$05,$fc,$03,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 996 : 303
	db	$fc,$03,$69,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 996 : 321
	db	$69,$05,$fd,$02,$69,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 997 : 331
	db	$fd,$03,$45,$05,$fc,$02,$55,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 997 : 344
	db	$55,$06,$fc,$02,$59,$03,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 997 : 356
	db	$fd,$02,$57,$02,$fc,$03,$fd,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 997 : 372
	db	$59,$0a,$fc,$05,$59,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 997 : 377
	db	$fd,$02,$59,$05,$fc,$02,$fd,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 997 : 397
	db	$5a,$03,$fc,$05,$fd,$02,$57,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 998 : 404
	db	$fc,$02,$fd,$03,$5a,$0a,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 998 : 415
	db	$5a,$03,$fc,$02,$5a,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 998 : 432
	db	$60,$02,$fc,$06,$5b,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 998 : 445
	db	$61,$0a,$fc,$05,$61,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 998 : 458
	db	$61,$05,$fc,$02,$63,$03,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 998 : 478
	db	$60,$03,$fc,$02,$61,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 999 : 493
	db	$63,$02,$fc,$05,$62,$03,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 999 : 506
	db	$63,$05,$fc,$03,$60,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 999 : 518
	db	$fd,$02,$69,$03,$fc,$02,$69,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 999 : 533
	db	$fc,$02,$fd,$01,$6a,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 999 : 544
	db	$69,$02,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 999 : 554
	db	$fd,$02,$69,$05,$fc,$03,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1000 : 566
	db	$69,$02,$fc,$03,$69,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1000 : 574
	db	$6a,$05,$fc,$02,$69,$03,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1000 : 587
	db	$69,$05,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1000 : 599
	db	$69,$03,$fc,$02,$69,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1000 : 614
	db	$6a,$05,$fc,$03,$69,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1000 : 627
	db	$69,$05,$fc,$02,$fd,$02,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1000 : 640
	db	$fc,$03,$fd,$01,$69,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1001 : 652
	db	$69,$05,$fc,$02,$fd,$02,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1001 : 660
	db	$fc,$03,$fd,$01,$69,$03,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1001 : 672
	db	$69,$05,$fc,$03,$fd,$02,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1001 : 680
	db	$fc,$02,$fd,$01,$69,$03,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1001 : 693
	db	$69,$05,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1001 : 700
	db	$69,$03,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1001 : 715
	db	$69,$05,$fc,$03,$69,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1002 : 728
	db	$69,$05,$fc,$02,$69,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1002 : 741
	db	$69,$02,$fc,$03,$68,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1002 : 756
	db	$fd,$02,$6a,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1002 : 769
	db	$6a,$05,$6a,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1002 : 776
	db	$6a,$05,$fc,$02,$fd,$01,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1002 : 789
	db	$6a,$05,$fc,$03,$fd,$02,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1002 : 801
	db	$fc,$03,$fd,$01,$6a,$05,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1003 : 814
	db	$fc,$02,$6a,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1003 : 827
	db	$6a,$05,$fd,$01,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1003 : 837
	db	$fd,$02,$68,$05,$fc,$03,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1003 : 849
	db	$68,$05,$68,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1003 : 857
	db	$68,$05,$fc,$02,$68,$05,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1003 : 870
	db	$fc,$03,$68,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1003 : 887
	db	$68,$06,$fd,$02,$68,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1004 : 897
	db	$68,$05,$fc,$03,$fd,$01,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1004 : 910
	db	$fd,$02,$68,$05,$fc,$02,$70,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1004 : 923
	db	$fc,$03,$fd,$01,$70,$05,$70,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1004 : 935
	db	$fc,$03,$fd,$02,$70,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1004 : 948
	db	$fd,$01,$70,$05,$fd,$02,$70,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1004 : 958
	db	$fc,$03,$6a,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1004 : 968
	db	$6a,$05,$6a,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1005 : 978
	db	$6a,$05,$fc,$03,$6a,$05,$6b,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1005 : 991
	db	$fc,$02,$fd,$01,$69,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1005 : 1009
	db	$69,$05,$69,$05,$fc,$02,$fd,$00	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1005 : 1019
	db	$69,$06,$fc,$02,$fd,$01,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1005 : 1031
	db	$69,$05,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1005 : 1044
	db	$fd,$02,$69,$05,$fd,$00,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1006 : 1059
	db	$fc,$03,$fd,$02,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1006 : 1069
	db	$fd,$00,$69,$06,$fd,$02,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1006 : 1079
	db	$fc,$02,$fd,$01,$6a,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1006 : 1090
	db	$fd,$02,$6a,$05,$fd,$01,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1006 : 1100
	db	$fc,$02,$fd,$02,$6a,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1006 : 1110
	db	$fd,$01,$6a,$05,$6a,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1006 : 1120
	db	$6a,$05,$fc,$02,$fd,$02,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1007 : 1133
	db	$fd,$01,$6a,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1007 : 1145
	db	$6a,$05,$fc,$02,$fd,$01,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1007 : 1153
	db	$fd,$02,$69,$06,$fc,$02,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1007 : 1165
	db	$fc,$03,$fd,$01,$68,$05,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1007 : 1178
	db	$fc,$02,$fd,$02,$68,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1007 : 1191
	db	$fd,$01,$68,$05,$68,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1007 : 1201
	db	$fd,$03,$68,$06,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1008 : 1213
	db	$68,$05,$fd,$02,$68,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1008 : 1221
	db	$fd,$03,$68,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1008 : 1234
	db	$68,$05,$fd,$02,$68,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1008 : 1241
	db	$fd,$01,$70,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1008 : 1254
	db	$70,$05,$fd,$01,$70,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1008 : 1262
	db	$fd,$02,$70,$05,$fc,$03,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1008 : 1274
	db	$70,$05,$fd,$02,$70,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1008 : 1282
	db	$fd,$01,$6a,$05,$fc,$03,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1009 : 1294
	db	$6a,$05,$fd,$01,$6a,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1009 : 1302
	db	$fd,$03,$6a,$05,$fc,$02,$fd,$01	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1009 : 1315
	db	$6a,$05,$fd,$03,$6a,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1009 : 1322
	db	$60,$02,$fc,$05,$fd,$02,$55,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1009 : 1335
	db	$fc,$02,$fd,$03,$55,$06,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1009 : 1345
	db	$55,$14,$fc,$29,$43,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1009 : 1355
	db	$fd,$02,$57,$05,$fd,$03,$43,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1010 : 1423
	db	$fc,$03,$57,$14,$fc,$29,$48,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1010 : 1433
	db	$fc,$02,$60,$03,$fc,$02,$41,$08	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1011 : 1502
	db	$55,$14,$fc,$29,$46,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1011 : 1517
	db	$5a,$03,$fc,$02,$56,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1012 : 1585
	db	$56,$05,$fc,$02,$60,$03,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1012 : 1598
	db	$6a,$08,$70,$05,$fc,$03,$6a,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1012 : 1610
	db	$60,$07,$58,$05,$fc,$03,$60,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1013 : 1631
	db	$58,$07,$55,$08,$fc,$05,$59,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1013 : 1651
	db	$fc,$03,$60,$71,$fc,$45,$fc,$51	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1013 : 1676
	db	$fc,$28,$fd,$02,$68,$03,$68,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1017 : 1942
	db	$fc,$05,$58,$02,$fc,$08,$58,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1017 : 1988
	db	$fc,$08,$68,$02,$fc,$08,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1017 : 2005
	db	$fc,$05,$58,$03,$fc,$07,$58,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1018 : 2028
	db	$fc,$07,$68,$03,$fc,$07,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1018 : 2046
	db	$fc,$06,$58,$02,$fc,$08,$58,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1018 : 2068
	db	$fc,$08,$68,$02,$fc,$08,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1018 : 2086
	db	$fc,$05,$58,$02,$fc,$08,$58,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1019 : 2109
	db	$fc,$07,$68,$03,$fc,$07,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1019 : 2127
	db	$fc,$05,$56,$03,$fc,$08,$56,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1019 : 2149
	db	$fc,$08,$68,$02,$fc,$08,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1019 : 2167
	db	$fc,$05,$56,$02,$fc,$08,$56,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1020 : 2190
	db	$fc,$07,$68,$03,$fc,$07,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1020 : 2208
	db	$fc,$05,$56,$03,$fc,$07,$56,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1020 : 2230
	db	$fc,$08,$68,$02,$fc,$08,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1020 : 2248
	db	$fc,$05,$56,$02,$fc,$08,$56,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1021 : 2271
	db	$fc,$08,$68,$03,$fc,$07,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1021 : 2288
	db	$fc,$05,$58,$03,$fc,$07,$58,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1021 : 2311
	db	$fc,$07,$68,$03,$fc,$08,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1021 : 2329
	db	$fc,$05,$58,$02,$fc,$08,$58,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1022 : 2352
	db	$fc,$08,$68,$02,$fc,$08,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1022 : 2369
	db	$fc,$05,$58,$03,$fc,$07,$58,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1022 : 2392
	db	$fc,$07,$68,$03,$fc,$07,$68,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1022 : 2410
	db	$fc,$05,$58,$02,$fc,$08,$58,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1023 : 2433
	db	$fc,$08,$63,$02,$fc,$08,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1023 : 2450
	db	$fc,$05,$58,$03,$fc,$07,$58,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1023 : 2473
	db	$fc,$07,$68,$03,$fc,$07,$68,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1023 : 2491
	db	$fc,$05,$58,$03,$fc,$08,$58,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1024 : 2513
	db	$fc,$08,$68,$02,$fc,$30,$fc,$29	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1024 : 2531
	db	$58,$05,$fc,$05,$58,$05,$fc,$0f	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1025 : 2630
	db	$fd,$01,$58,$05,$fc,$05,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1025 : 2660
	db	$58,$05,$fc,$05,$fd,$01,$58,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1026 : 2670
	db	$fc,$0f,$fd,$02,$58,$06,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1026 : 2685
	db	$58,$05,$fc,$05,$fd,$01,$58,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1026 : 2711
	db	$fc,$0f,$58,$05,$fc,$05,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1026 : 2726
	db	$58,$05,$fc,$05,$fd,$01,$58,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1027 : 2751
	db	$fc,$0f,$fd,$02,$58,$05,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1027 : 2766
	db	$56,$06,$fc,$05,$fd,$01,$56,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1027 : 2791
	db	$fc,$0f,$56,$05,$fc,$05,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1027 : 2807
	db	$56,$05,$fc,$05,$fd,$01,$56,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1028 : 2832
	db	$fc,$0f,$fd,$02,$56,$05,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1028 : 2847
	db	$56,$05,$fc,$06,$fd,$01,$56,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1028 : 2872
	db	$fc,$0f,$56,$05,$fc,$05,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1028 : 2888
	db	$56,$05,$fc,$05,$fd,$01,$56,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1029 : 2913
	db	$fc,$0f,$fd,$02,$56,$05,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1029 : 2928
	db	$55,$05,$fc,$05,$fd,$01,$55,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1029 : 2953
	db	$fc,$10,$55,$05,$fc,$05,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1029 : 2968
	db	$55,$05,$fc,$05,$fd,$01,$55,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1030 : 2994
	db	$fc,$0f,$fd,$02,$55,$05,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1030 : 3009
	db	$55,$05,$fc,$05,$fd,$01,$55,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1030 : 3034
	db	$fc,$10,$55,$05,$fc,$05,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1030 : 3049
	db	$55,$05,$fc,$05,$fd,$01,$55,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1031 : 3075
	db	$fc,$0f,$fd,$02,$54,$05,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1031 : 3090
	db	$54,$05,$fc,$05,$fd,$01,$54,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1031 : 3115
	db	$fc,$0f,$54,$05,$fc,$06,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1031 : 3130
	db	$54,$05,$fc,$05,$fd,$01,$54,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1032 : 3156
	db	$fc,$0f,$fd,$02,$54,$05,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1032 : 3171
	db	$54,$05,$fc,$05,$fd,$01,$54,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1032 : 3196
	db	$fc,$0f,$54,$05,$fc,$05,$fd,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1032 : 3211
	db	$54,$05,$fc,$06,$54,$05,$fc,$0f	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1033 : 3236
	db	$54,$05,$fc,$2d,$fc,$51,$fc,$51	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1033 : 3267
	db	$fc,$51,$fc,$28,$fc,$2a,$fc,$0d	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1036 : 3479
	db	$fc,$47,$fc,$08,$fc,$03,$fc,$20	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1038 : 3655
	db	$69,$06,$fc,$02,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1039 : 3769
	db	$fc,$03,$69,$05,$fc,$02,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1039 : 3787
	db	$69,$05,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1039 : 3802
	db	$69,$06,$69,$05,$fc,$02,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1040 : 3817
	db	$fc,$03,$69,$05,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1040 : 3835
	db	$69,$05,$fc,$03,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1040 : 3850
	db	$fc,$03,$69,$05,$fc,$02,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1040 : 3868
	db	$69,$05,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1040 : 3883
	db	$69,$05,$69,$06,$fc,$02,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1041 : 3898
	db	$fc,$03,$69,$05,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1041 : 3916
	db	$69,$05,$fc,$03,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1041 : 3931
	db	$fc,$02,$69,$06,$fc,$02,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1041 : 3949
	db	$69,$05,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1041 : 3964
	db	$69,$05,$69,$05,$fc,$03,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1042 : 3979
	db	$fc,$03,$69,$05,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1042 : 3997
	db	$69,$05,$fc,$03,$69,$05,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1042 : 4012
	db	$fc,$02,$69,$05,$fc,$03,$69,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1042 : 4030
	db	$69,$05,$fc,$03,$69,$05,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1042 : 4045
	db	$69,$05,$69,$05,$fc,$03,$fd,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1043 : 4060
	db	$45,$05,$fc,$02,$55,$05,$55,$08	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1043 : 4073
	db	$fd,$02,$59,$03,$fc,$05,$fd,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1043 : 4093
	db	$57,$02,$fc,$03,$59,$0a,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1043 : 4101
	db	$59,$02,$fc,$03,$59,$02,$fc,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1043 : 4121
	db	$5a,$02,$fc,$05,$fd,$02,$57,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1044 : 4134
	db	$fc,$02,$fd,$03,$5a,$0a,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1044 : 4144
	db	$5a,$03,$fc,$02,$fd,$02,$5a,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1044 : 4161
	db	$fc,$05,$fd,$03,$60,$03,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1044 : 4169
	db	$fd,$02,$5b,$02,$fc,$03,$fd,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1044 : 4182
	db	$61,$0a,$fc,$06,$61,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1044 : 4187
	db	$fd,$02,$61,$02,$fc,$06,$fd,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1044 : 4208
	db	$63,$02,$fc,$05,$60,$03,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1045 : 4216
	db	$61,$05,$fc,$03,$63,$02,$fc,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1045 : 4229
	db	$62,$02,$fc,$03,$63,$05,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1045 : 4245
	db	$fd,$02,$59,$03,$fc,$05,$57,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1045 : 4258
	db	$fc,$03,$fd,$03,$59,$0a,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1045 : 4268
	db	$59,$02,$fc,$03,$59,$03,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1045 : 4286
	db	$5a,$02,$fc,$05,$fd,$02,$57,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1046 : 4299
	db	$fc,$02,$5a,$0a,$fc,$05,$fd,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1046 : 4309
	db	$5a,$03,$fc,$02,$5a,$03,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1046 : 4326
	db	$60,$03,$fc,$05,$fd,$02,$5b,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1046 : 4339
	db	$fc,$03,$61,$0a,$fc,$05,$fd,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1046 : 4349
	db	$61,$03,$fc,$02,$61,$03,$fc,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1046 : 4367
	db	$63,$03,$fc,$05,$60,$02,$fc,$03	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1047 : 4380
	db	$61,$05,$fc,$03,$63,$02,$fc,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1047 : 4393
	db	$62,$02,$fc,$03,$63,$06,$fc,$02	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1047 : 4409
	db	$fd,$02,$70,$0e,$70,$14,$70,$25	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1047 : 4422
	db	$fd,$03,$45,$04,$fc,$06,$45,$04	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1048 : 4493
	db	$fc,$03,$45,$03,$fc,$03,$fc,$04	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1048 : 4507
	db	$45,$19,$fc,$21,$fc,$0f
song_000_15_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_15_lp)*2
	dw	song_000_15_lp


song_000_16:	;Trk Q
	db	$fc,$28,$fb,$00,$ef,$07,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1051 : 0
	db	$fe,$01,$75,$06,$fc,$02,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1051 : 40
	db	$75,$05,$75,$05,$fc,$03,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1051 : 48
	db	$75,$05,$fc,$02,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1051 : 61
	db	$fc,$03,$75,$05,$fc,$02,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1051 : 78
	db	$75,$06,$fd,$02,$75,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1052 : 88
	db	$75,$05,$fc,$03,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1052 : 101
	db	$fc,$02,$75,$05,$fc,$03,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1052 : 119
	db	$75,$05,$75,$05,$fc,$03,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1052 : 129
	db	$75,$05,$fc,$02,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1052 : 142
	db	$fc,$03,$75,$05,$fc,$02,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1052 : 159
	db	$75,$05,$fd,$02,$75,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1053 : 169
	db	$75,$05,$fc,$03,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1053 : 182
	db	$fc,$02,$75,$05,$fc,$03,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1053 : 200
	db	$75,$05,$75,$05,$fc,$02,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1053 : 210
	db	$75,$06,$fc,$02,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1053 : 222
	db	$fc,$03,$75,$05,$fc,$02,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1053 : 240
	db	$75,$05,$fd,$02,$75,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1054 : 250
	db	$75,$05,$fc,$03,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1054 : 263
	db	$fc,$2b,$75,$05,$fc,$02,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1054 : 281
	db	$75,$05,$fd,$02,$75,$05,$fc,$3f	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1055 : 331
	db	$fc,$51,$fc,$30,$75,$03,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1056 : 404
	db	$75,$06,$fc,$02,$fd,$01,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1057 : 538
	db	$fc,$03,$75,$02,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1057 : 551
	db	$fc,$02,$fd,$02,$75,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1057 : 564
	db	$fd,$01,$75,$02,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1058 : 574
	db	$fc,$03,$75,$05,$fc,$02,$75,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1058 : 584
	db	$fc,$02,$75,$05,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1058 : 597
	db	$fc,$02,$75,$03,$fc,$02,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1058 : 612
	db	$fc,$03,$75,$05,$fc,$03,$75,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1058 : 624
	db	$fc,$03,$75,$05,$fc,$02,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1058 : 637
	db	$75,$05,$fc,$03,$fd,$01,$75,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1059 : 647
	db	$fc,$03,$75,$05,$fc,$02,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1059 : 657
	db	$75,$05,$fc,$03,$fd,$01,$75,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1059 : 667
	db	$fc,$02,$75,$05,$fc,$03,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1059 : 678
	db	$75,$05,$fc,$02,$fd,$01,$75,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1059 : 688
	db	$fc,$02,$75,$05,$fc,$03,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1059 : 698
	db	$75,$05,$fc,$02,$fd,$01,$75,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1059 : 708
	db	$fc,$03,$75,$05,$fc,$02,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1059 : 718
	db	$fc,$03,$75,$02,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1060 : 733
	db	$fc,$02,$fd,$02,$75,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1060 : 746
	db	$fd,$01,$75,$02,$fc,$03,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1060 : 756
	db	$74,$05,$fc,$03,$67,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1060 : 761
	db	$fd,$01,$67,$05,$67,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1060 : 776
	db	$fd,$02,$67,$05,$fc,$02,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1060 : 789
	db	$67,$05,$67,$05,$fc,$03,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1060 : 796
	db	$67,$05,$fc,$03,$fd,$01,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1061 : 809
	db	$67,$05,$fc,$02,$67,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1061 : 822
	db	$fd,$02,$67,$05,$fd,$01,$66,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1061 : 837
	db	$fc,$02,$fd,$02,$65,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1061 : 847
	db	$fd,$01,$65,$05,$65,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1061 : 857
	db	$fd,$02,$65,$05,$fc,$02,$65,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1061 : 870
	db	$65,$05,$fc,$03,$65,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1061 : 882
	db	$fd,$01,$65,$06,$fd,$02,$65,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1062 : 897
	db	$fc,$02,$65,$05,$fc,$03,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1062 : 908
	db	$65,$05,$fd,$02,$65,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1062 : 918
	db	$67,$05,$fc,$03,$fd,$01,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1062 : 930
	db	$67,$05,$fc,$03,$fd,$02,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1062 : 943
	db	$fc,$02,$fd,$01,$67,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1062 : 956
	db	$67,$05,$fc,$03,$67,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1062 : 963
	db	$fd,$01,$67,$05,$67,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1063 : 978
	db	$fd,$02,$67,$05,$fc,$03,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1063 : 991
	db	$67,$05,$fc,$02,$fd,$01,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1063 : 1004
	db	$fc,$03,$75,$05,$75,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1063 : 1016
	db	$fd,$02,$75,$06,$fc,$02,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1063 : 1031
	db	$75,$05,$75,$05,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1063 : 1039
	db	$fc,$02,$fd,$02,$75,$05,$fd,$00	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1064 : 1057
	db	$75,$05,$fc,$03,$fd,$02,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1064 : 1064
	db	$fc,$02,$fd,$00,$75,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1064 : 1077
	db	$74,$05,$fc,$02,$fd,$01,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1064 : 1085
	db	$fc,$03,$fd,$02,$67,$05,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1064 : 1097
	db	$67,$05,$fc,$02,$fd,$02,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1064 : 1105
	db	$fc,$03,$fd,$01,$67,$05,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1064 : 1117
	db	$fc,$03,$67,$05,$fc,$02,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1064 : 1130
	db	$67,$05,$fd,$01,$67,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1065 : 1140
	db	$fd,$02,$67,$05,$fc,$02,$fd,$01	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1065 : 1153
	db	$67,$05,$fd,$02,$66,$06,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1065 : 1160
	db	$65,$05,$fc,$03,$fd,$01,$65,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1065 : 1173
	db	$65,$05,$fc,$02,$fd,$02,$65,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1065 : 1186
	db	$fc,$03,$fd,$01,$65,$05,$65,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1065 : 1198
	db	$fc,$02,$fd,$03,$65,$06,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1065 : 1211
	db	$fd,$01,$65,$05,$fd,$02,$65,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1066 : 1221
	db	$fc,$03,$fd,$03,$65,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1066 : 1231
	db	$fd,$01,$65,$05,$fd,$02,$65,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1066 : 1241
	db	$fc,$03,$fd,$01,$67,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1066 : 1251
	db	$fd,$02,$67,$05,$fd,$01,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1066 : 1262
	db	$fc,$02,$fd,$02,$67,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1066 : 1272
	db	$fd,$01,$67,$05,$fd,$02,$67,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1066 : 1282
	db	$fc,$02,$fd,$01,$63,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1066 : 1292
	db	$fd,$02,$63,$05,$fd,$01,$63,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1067 : 1302
	db	$fc,$03,$fd,$03,$63,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1067 : 1312
	db	$fd,$01,$63,$05,$fd,$03,$63,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1067 : 1322
	db	$fc,$03,$65,$02,$fc,$12,$65,$14	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1067 : 1332
	db	$fc,$29,$53,$05,$fc,$02,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1068 : 1375
	db	$53,$05,$fd,$03,$53,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1068 : 1423
	db	$53,$14,$fc,$29,$51,$05,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1068 : 1436
	db	$48,$05,$fc,$03,$60,$02,$fc,$0a	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1069 : 1509
	db	$6a,$08,$fc,$51,$fc,$51,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1069 : 1529
	db	$fc,$51,$fc,$51,$fc,$2b,$fc,$26	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1073 : 1780
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1076 : 2023
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$29	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1080 : 2347
	db	$50,$05,$fc,$05,$fd,$02,$50,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1083 : 2630
	db	$fc,$0f,$50,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1083 : 2645
	db	$50,$05,$fc,$05,$fd,$02,$50,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1084 : 2670
	db	$fc,$0f,$50,$06,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1084 : 2685
	db	$50,$05,$fc,$05,$fd,$02,$50,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1084 : 2711
	db	$fc,$0f,$50,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1084 : 2726
	db	$50,$05,$fc,$05,$fd,$02,$50,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1085 : 2751
	db	$fc,$0f,$50,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1085 : 2766
	db	$50,$06,$fc,$05,$fd,$02,$50,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1085 : 2791
	db	$fc,$0f,$50,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1085 : 2807
	db	$50,$05,$fc,$05,$fd,$02,$50,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1086 : 2832
	db	$fc,$0f,$50,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1086 : 2847
	db	$50,$05,$fc,$06,$fd,$02,$50,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1086 : 2872
	db	$fc,$0f,$50,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1086 : 2888
	db	$50,$05,$fc,$05,$fd,$02,$50,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1087 : 2913
	db	$fc,$0f,$50,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1087 : 2928
	db	$51,$05,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1087 : 2953
	db	$fc,$10,$51,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1087 : 2968
	db	$51,$05,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1088 : 2994
	db	$fc,$0f,$51,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1088 : 3009
	db	$51,$05,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1088 : 3034
	db	$fc,$10,$51,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1088 : 3049
	db	$51,$05,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1089 : 3075
	db	$fc,$0f,$51,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1089 : 3090
	db	$51,$05,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1089 : 3115
	db	$fc,$0f,$51,$05,$fc,$06,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1089 : 3130
	db	$51,$05,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1090 : 3156
	db	$fc,$0f,$51,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1090 : 3171
	db	$51,$05,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1090 : 3196
	db	$fc,$0f,$51,$05,$fc,$05,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1090 : 3211
	db	$51,$05,$fc,$06,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1091 : 3236
	db	$fc,$0f,$51,$05,$fc,$2d,$fc,$51	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1091 : 3252
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1093 : 3398
	db	$fc,$0d,$fc,$47,$fc,$08,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1096 : 3642
	db	$fc,$20,$75,$06,$fc,$02,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1097 : 3737
	db	$75,$05,$fc,$03,$75,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1097 : 3782
	db	$75,$05,$75,$05,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1097 : 3797
	db	$fc,$02,$75,$06,$75,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1098 : 3815
	db	$75,$05,$fc,$03,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1098 : 3830
	db	$fc,$02,$75,$05,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1098 : 3848
	db	$75,$05,$fc,$03,$75,$05,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1098 : 3863
	db	$75,$05,$75,$05,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1098 : 3878
	db	$fc,$02,$75,$05,$75,$06,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1099 : 3896
	db	$75,$05,$fc,$03,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1099 : 3911
	db	$fc,$02,$75,$05,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1099 : 3929
	db	$75,$05,$fc,$02,$75,$06,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1099 : 3944
	db	$75,$05,$75,$05,$fc,$03,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1099 : 3959
	db	$fc,$02,$75,$05,$75,$05,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1100 : 3977
	db	$75,$05,$fc,$03,$75,$05,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1100 : 3992
	db	$fc,$2b,$75,$05,$fc,$02,$75,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1100 : 4010
	db	$75,$05,$fc,$40,$fc,$28,$fc,$2a	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1101 : 4065
	db	$fc,$07,$fc,$18,$fc,$0e,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1103 : 4216
	db	$fc,$21,$fc,$1e,$fc,$33,$fc,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1103 : 4266
	db	$fc,$12,$fc,$15,$fd,$03,$49,$06	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1105 : 4383
	db	$fc,$08,$45,$03,$fc,$05,$45,$03	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1105 : 4428
	db	$fc,$09,$fc,$03,$45,$03,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1105 : 4447
	db	$45,$04,$fc,$0c,$45,$03,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1106 : 4468
	db	$fc,$17,$fc,$3e,$fc,$0f
song_000_16_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_16_lp)*2
	dw	song_000_16_lp


song_000_17:	;Trk R
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1109 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1113 : 324
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1117 : 647
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1121 : 971
	db	$fc,$51,$fc,$51,$fc,$49,$fb,$00	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1125 : 1294
	db	$ef,$07,$fd,$03,$fe,$02,$63,$08	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1127 : 1529
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1128 : 1537
	db	$fc,$51,$fc,$2b,$fc,$26,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1132 : 1861
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1135 : 2104
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1139 : 2427
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1143 : 2751
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1147 : 3075
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1151 : 3398
	db	$fc,$0d,$fc,$47,$fc,$08,$fc,$03	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1154 : 3642
	db	$fc,$20,$fc,$29,$fc,$51,$fc,$28	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1155 : 3737
	db	$fc,$29,$fc,$51,$fc,$51,$fc,$28	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1157 : 3931
	db	$fc,$2a,$fc,$07,$fc,$18,$fc,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1160 : 4174
	db	$fc,$05,$fc,$21,$fc,$1e,$fc,$33	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1161 : 4261
	db	$fc,$03,$fc,$12,$fc,$23,$fc,$14	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1163 : 4380
	db	$fc,$0c,$fc,$19,$fc,$17,$fc,$3e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1163 : 4456
	db	$fc,$0f
song_000_17_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_17_lp)*2
	dw	song_000_17_lp


song_000_18:	;Trk S
	db	$fc,$51,$fb,$01,$ef,$07,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1167 : 0
	db	$fe,$03,$3b,$02,$fc,$05,$53,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1168 : 81
	db	$fc,$03,$4b,$05,$fc,$02,$53,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1168 : 91
	db	$fc,$05,$53,$02,$fc,$03,$4b,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1168 : 104
	db	$fc,$2b,$4b,$02,$fc,$05,$63,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1168 : 119
	db	$fc,$02,$5b,$08,$66,$03,$fc,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1169 : 172
	db	$63,$02,$fc,$03,$5b,$02,$fc,$2e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1169 : 190
	db	$3b,$02,$fc,$05,$53,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1170 : 243
	db	$4b,$08,$53,$02,$fc,$06,$5b,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1170 : 255
	db	$fc,$03,$63,$05,$fc,$02,$5b,$14	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1170 : 273
	db	$fc,$08,$66,$02,$fc,$03,$66,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1170 : 303
	db	$fc,$03,$5b,$14,$3b,$14,$fc,$28	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1170 : 321
	db	$fc,$1c,$47,$03,$fc,$02,$47,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1172 : 404
	db	$fc,$03,$51,$17,$fc,$11,$63,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1172 : 442
	db	$fc,$05,$60,$03,$fc,$02,$51,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1173 : 488
	db	$fc,$03,$50,$02,$fc,$05,$62,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1173 : 503
	db	$fc,$02,$53,$05,$fc,$03,$65,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1173 : 516
	db	$fc,$21,$fc,$51,$fc,$29,$35,$1e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1173 : 533
	db	$39,$03,$fc,$07,$50,$3d,$fc,$0a	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1175 : 718
	db	$fd,$04,$33,$02,$fc,$08,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1176 : 799
	db	$53,$19,$fc,$03,$52,$02,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1177 : 809
	db	$51,$05,$fc,$02,$50,$9b,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1177 : 842
	db	$35,$0a,$fc,$03,$39,$05,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1179 : 1011
	db	$50,$72,$fc,$08,$3a,$07,$37,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1179 : 1031
	db	$fc,$02,$3a,$08,$50,$72,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1181 : 1163
	db	$50,$05,$fc,$03,$50,$02,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1183 : 1294
	db	$4a,$08,$5a,$02,$fc,$05,$60,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1183 : 1307
	db	$fc,$02,$66,$08,$50,$02,$fc,$12	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1183 : 1325
	db	$55,$0d,$fc,$07,$59,$03,$fc,$0a	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1183 : 1355
	db	$60,$02,$fc,$06,$65,$02,$fc,$0a	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1184 : 1388
	db	$50,$08,$53,$02,$fc,$26,$63,$19	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1184 : 1408
	db	$fc,$03,$62,$03,$fc,$02,$61,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1185 : 1481
	db	$fc,$05,$60,$02,$fc,$05,$60,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1185 : 1492
	db	$fc,$02,$5b,$08,$60,$02,$fc,$0a	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1185 : 1507
	db	$4a,$06,$fc,$02,$60,$03,$fc,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1185 : 1529
	db	$61,$02,$fc,$03,$60,$02,$fc,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1186 : 1545
	db	$61,$0d,$60,$02,$fc,$06,$46,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1186 : 1557
	db	$fc,$05,$46,$03,$fc,$02,$46,$12	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1186 : 1580
	db	$fc,$0a,$48,$03,$fc,$05,$48,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1186 : 1608
	db	$fc,$03,$48,$11,$fc,$03,$48,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1187 : 1628
	db	$fc,$2e,$fc,$51,$fc,$51,$fc,$28	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1187 : 1653
	db	$52,$05,$fc,$0f,$4b,$15,$fc,$2b	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1190 : 1901
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1191 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1195 : 2266
	db	$fc,$29,$48,$3c,$fc,$0a,$50,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1199 : 2589
	db	$fc,$05,$50,$37,$fc,$05,$50,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1200 : 2706
	db	$fc,$05,$48,$05,$fc,$05,$5a,$3d	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1201 : 2776
	db	$fc,$0a,$46,$05,$fc,$05,$46,$3b	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1202 : 2852
	db	$fc,$02,$50,$0a,$53,$05,$fc,$2e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1203 : 2931
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$29	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1204 : 2994
	db	$fd,$04,$5a,$4e,$fc,$03,$5a,$3c	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1207 : 3277
	db	$fc,$0d,$5a,$05,$fc,$03,$59,$51	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1209 : 3418
	db	$59,$50,$5a,$2a,$5a,$0d,$5a,$1d	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1210 : 3520
	db	$5a,$15,$fd,$05,$63,$15,$50,$08	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1212 : 3684
	db	$50,$03,$50,$0b,$4b,$15,$fc,$29	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1213 : 3734
	db	$3b,$02,$fc,$05,$53,$03,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1214 : 3810
	db	$4b,$05,$fc,$02,$53,$03,$fc,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1214 : 3823
	db	$53,$02,$fc,$03,$4b,$05,$fc,$2b	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1214 : 3838
	db	$4b,$02,$fc,$05,$63,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1215 : 3891
	db	$5b,$08,$66,$03,$fc,$05,$63,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1215 : 3903
	db	$fc,$03,$5b,$02,$fc,$05,$fc,$29	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1215 : 3921
	db	$3b,$02,$fc,$05,$53,$03,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1216 : 3972
	db	$4b,$08,$53,$02,$fc,$06,$5b,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1216 : 3984
	db	$fc,$03,$63,$05,$fc,$02,$5b,$14	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1216 : 4002
	db	$fc,$08,$66,$02,$fc,$03,$66,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1216 : 4032
	db	$fc,$03,$5b,$14,$3b,$14,$fc,$29	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1216 : 4050
	db	$fc,$1b,$47,$03,$fc,$02,$47,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1218 : 4134
	db	$fc,$03,$fd,$04,$60,$17,$fc,$13	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1218 : 4171
	db	$fd,$05,$63,$02,$fc,$05,$60,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1219 : 4216
	db	$fc,$03,$fd,$04,$51,$05,$fc,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1219 : 4226
	db	$50,$02,$fc,$06,$fd,$05,$62,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1219 : 4237
	db	$fc,$03,$fd,$04,$53,$05,$fc,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1219 : 4247
	db	$fc,$05,$fc,$21,$fc,$1b,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1219 : 4261
	db	$47,$03,$fc,$02,$47,$06,$fc,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1220 : 4326
	db	$fd,$04,$60,$17,$fc,$12,$fd,$05	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1220 : 4339
	db	$63,$03,$fc,$05,$fd,$04,$60,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1221 : 4380
	db	$fc,$03,$51,$05,$fc,$03,$50,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1221 : 4390
	db	$fc,$06,$62,$02,$fc,$03,$53,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1221 : 4403
	db	$fc,$02,$fd,$05,$59,$0e,$59,$14	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1221 : 4420
	db	$59,$25,$59,$17,$59,$04,$45,$19	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1221 : 4456
	db	$fc,$21,$fc,$0f
song_000_18_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_18_lp)*2
	dw	song_000_18_lp


song_000_19:	;Trk T
	db	$fc,$28,$fb,$02,$ef,$07,$fd,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1225 : 0
	db	$fe,$04,$35,$29,$2b,$28,$35,$29	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1225 : 40
	db	$2b,$28,$35,$29,$2b,$28,$2b,$14	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1227 : 162
	db	$fc,$08,$2b,$02,$fc,$03,$2b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1228 : 303
	db	$fc,$05,$36,$14,$2b,$14,$fc,$28	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1228 : 319
	db	$fc,$29,$31,$19,$fc,$03,$38,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1230 : 404
	db	$35,$07,$3a,$1a,$fc,$02,$37,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1230 : 478
	db	$33,$08,$25,$9a,$fc,$08,$35,$1e	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1231 : 518
	db	$30,$03,$fc,$07,$25,$29,$27,$50	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1233 : 718
	db	$28,$51,$2a,$29,$27,$21,$26,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1235 : 849
	db	$25,$51,$33,$29,$2a,$28,$31,$51	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1237 : 1011
	db	$30,$28,$36,$29,$25,$07,$fc,$0d	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1240 : 1254
	db	$25,$14,$fc,$29,$33,$02,$fc,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1241 : 1355
	db	$37,$03,$fc,$0a,$33,$14,$fc,$29	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1242 : 1423
	db	$31,$07,$fc,$0d,$31,$14,$fc,$29	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1243 : 1497
	db	$30,$07,$3a,$05,$36,$14,$fc,$08	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1244 : 1578
	db	$36,$08,$43,$05,$40,$14,$3b,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1245 : 1618
	db	$35,$08,$fc,$05,$30,$05,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1245 : 1658
	db	$35,$0c,$39,$05,$fc,$03,$fc,$14	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1245 : 1679
	db	$39,$14,$33,$03,$fc,$05,$33,$02	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1246 : 1719
	db	$fc,$03,$32,$08,$33,$14,$fc,$28	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1246 : 1749
	db	$31,$14,$fc,$0d,$38,$05,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1247 : 1820
	db	$40,$14,$38,$14,$37,$08,$fc,$0c	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1248 : 1861
	db	$32,$15,$34,$14,$30,$14,$28,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1248 : 1921
	db	$28,$63,$fc,$14,$fc,$14,$27,$14	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1249 : 1985
	db	$26,$7a,$fc,$14,$30,$14,$35,$79	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1251 : 2144
	db	$fc,$29,$24,$0a,$28,$0a,$34,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1255 : 2427
	db	$33,$0a,$31,$0a,$33,$0b,$31,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1255 : 2498
	db	$2b,$0a,$2a,$28,$29,$29,$28,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1256 : 2539
	db	$33,$0a,$40,$0a,$3a,$0a,$38,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1257 : 2640
	db	$3a,$0a,$38,$0a,$fd,$06,$37,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1258 : 2680
	db	$fd,$07,$33,$41,$fc,$05,$32,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1258 : 2711
	db	$fd,$06,$26,$0b,$fd,$07,$31,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1259 : 2791
	db	$fd,$06,$3a,$0a,$fd,$07,$38,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1259 : 2812
	db	$fd,$06,$36,$0a,$fd,$07,$38,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1260 : 2832
	db	$fd,$06,$36,$0a,$fd,$07,$35,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1260 : 2852
	db	$33,$51,$fc,$29,$fc,$51,$fc,$51	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1260 : 2872
	db	$fc,$50,$fc,$29,$33,$9f,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1264 : 3156
	db	$38,$9f,$fc,$02,$3a,$28,$fc,$02	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1267 : 3439
	db	$39,$0d,$39,$1a,$fc,$03,$38,$12	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1270 : 3642
	db	$fc,$03,$37,$13,$fc,$02,$36,$08	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1270 : 3702
	db	$36,$03,$36,$0b,$35,$05,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1271 : 3734
	db	$2b,$05,$28,$08,$35,$29,$2b,$28	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1271 : 3756
	db	$35,$29,$2b,$28,$35,$29,$2b,$28	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1272 : 3850
	db	$2b,$14,$fc,$08,$2b,$02,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1274 : 4012
	db	$2b,$05,$fc,$03,$36,$14,$2b,$14	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1274 : 4045
	db	$fc,$29,$fc,$28,$31,$1d,$38,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1275 : 4093
	db	$35,$08,$3a,$07,$3a,$16,$37,$02	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1276 : 4208
	db	$37,$03,$33,$08,$fc,$03,$fc,$05	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1277 : 4247
	db	$fc,$21,$fc,$1e,$fc,$0a,$31,$1c	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1277 : 4266
	db	$38,$05,$35,$08,$3a,$03,$3a,$12	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1278 : 4367
	db	$3a,$08,$37,$05,$33,$08,$25,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1279 : 4401
	db	$fc,$0b,$25,$06,$fc,$02,$25,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1279 : 4425
	db	$fc,$09,$fc,$03,$25,$06,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1279 : 4447
	db	$25,$04,$fc,$0c,$25,$06,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1280 : 4468
	db	$25,$04,$fc,$06,$25,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1280 : 4493
	db	$25,$06,$fc,$04,$25,$19,$fc,$21	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1280 : 4510
	db	$fc,$0f
song_000_19_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_19_lp)*2
	dw	song_000_19_lp


song_000_20:	;Trk U
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1283 : 0
	db	$fc,$28,$fb,$03,$ef,$07,$fd,$0d	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1287 : 324
	db	$fe,$05,$45,$05,$fc,$0f,$fd,$0e	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1287 : 364
	db	$53,$05,$fc,$0f,$60,$15,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1287 : 384
	db	$55,$03,$fc,$02,$fd,$0d,$55,$03	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1288 : 432
	db	$fc,$05,$fd,$0e,$51,$28,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1288 : 440
	db	$fc,$51,$fc,$51,$fc,$21,$fd,$0d	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1290 : 566
	db	$47,$05,$fc,$03,$50,$50,$fc,$29	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1292 : 761
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1294 : 890
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1298 : 1213
	db	$fc,$51,$fc,$28,$fd,$0e,$45,$08	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1302 : 1537
	db	$fc,$05,$49,$05,$fc,$03,$50,$74	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1303 : 1666
	db	$fc,$05,$53,$03,$fc,$05,$52,$02	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1305 : 1795
	db	$fc,$03,$53,$05,$fc,$02,$51,$1f	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1305 : 1810
	db	$fc,$02,$68,$05,$fc,$03,$50,$28	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1305 : 1851
	db	$52,$08,$fc,$21,$47,$28,$fc,$03	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1306 : 1901
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1307 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1311 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1315 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1319 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1323 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1327 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1329 : 3726
	db	$fc,$51,$fc,$28,$fc,$29,$fc,$51	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1330 : 3810
	db	$fc,$28,$45,$05,$fc,$0f,$53,$05	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1333 : 4053
	db	$fc,$10,$60,$14,$fc,$07,$55,$03	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1333 : 4118
	db	$fc,$02,$fd,$0d,$55,$03,$fc,$05	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1334 : 4164
	db	$fd,$0e,$51,$2a,$fc,$07,$fc,$18	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1334 : 4174
	db	$fc,$0b,$45,$03,$45,$02,$fc,$03	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1335 : 4247
	db	$fc,$0c,$53,$05,$fc,$10,$60,$14	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1335 : 4266
	db	$fc,$07,$55,$03,$fc,$02,$fd,$0d	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1336 : 4319
	db	$55,$03,$fc,$05,$fd,$0e,$51,$29	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1336 : 4331
	db	$fc,$03,$fc,$12,$fc,$23,$fc,$14	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1337 : 4380
	db	$fc,$0c,$fc,$19,$fc,$17,$fc,$3e	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1337 : 4456
	db	$fc,$0f
song_000_20_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_20_lp)*2
	dw	song_000_20_lp


song_000_21:	;Trk V
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1341 : 0
	db	$fc,$28,$fb,$03,$ef,$07,$fd,$0e	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1345 : 324
	db	$fe,$06,$50,$05,$fc,$23,$fc,$1c	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1345 : 364
	db	$50,$03,$fc,$02,$fd,$0d,$50,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1346 : 432
	db	$fc,$2d,$fc,$51,$fc,$51,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1346 : 440
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1350 : 728
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1354 : 1052
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1358 : 1375
	db	$fc,$51,$fc,$51,$fc,$51,$fd,$0e	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1362 : 1699
	db	$67,$28,$fc,$03,$fc,$26,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1365 : 1942
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1367 : 2104
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1371 : 2427
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1375 : 2751
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1379 : 3075
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1383 : 3398
	db	$fc,$0d,$fc,$47,$fc,$08,$fc,$03	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1386 : 3642
	db	$fc,$20,$fc,$29,$fc,$51,$fc,$28	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1387 : 3737
	db	$fc,$29,$fc,$51,$fc,$28,$50,$05	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1389 : 3931
	db	$fc,$24,$fc,$1b,$50,$03,$fc,$02	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1391 : 4098
	db	$fd,$0d,$50,$03,$fc,$05,$fc,$2a	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1392 : 4166
	db	$fc,$07,$fc,$18,$fc,$0b,$fd,$0e	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1393 : 4216
	db	$50,$03,$50,$02,$fc,$03,$fc,$21	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1393 : 4258
	db	$fc,$1b,$50,$03,$fc,$02,$fd,$0d	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1394 : 4299
	db	$50,$03,$fc,$2e,$fc,$03,$fc,$12	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1394 : 4331
	db	$fc,$23,$fc,$14,$fc,$0c,$fc,$19	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1395 : 4401
	db	$fc,$17,$fc,$3e,$fc,$0f
song_000_21_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_21_lp)*2
	dw	song_000_21_lp


song_000_22:	;Trk W
	db	$fc,$28,$fb,$04,$ef,$07,$fd,$10	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1399 : 0
	db	$fe,$07,$45,$29,$2b,$28,$45,$29	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1399 : 40
	db	$2b,$28,$45,$29,$2b,$28,$2b,$17	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1401 : 162
	db	$fc,$05,$2b,$02,$fc,$03,$2b,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1402 : 306
	db	$fc,$05,$46,$26,$fc,$2a,$fc,$29	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1402 : 319
	db	$35,$26,$fc,$02,$33,$15,$3a,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1404 : 445
	db	$45,$0c,$fc,$1c,$fc,$51,$fc,$29	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1405 : 526
	db	$45,$1b,$fc,$03,$49,$03,$fc,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1407 : 688
	db	$40,$3d,$fc,$0a,$43,$02,$fc,$08	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1408 : 728
	db	$43,$1c,$fd,$0f,$42,$02,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1409 : 809
	db	$41,$05,$fc,$02,$fd,$10,$40,$9b	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1409 : 842
	db	$fc,$07,$45,$0d,$49,$05,$fc,$02	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1411 : 1004
	db	$40,$72,$fc,$08,$4a,$07,$47,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1411 : 1031
	db	$fc,$02,$4a,$08,$40,$72,$fc,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1413 : 1163
	db	$3a,$1c,$fc,$03,$36,$0a,$40,$02	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1415 : 1294
	db	$fc,$12,$40,$14,$fc,$29,$33,$02	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1415 : 1337
	db	$fc,$0a,$37,$05,$fc,$03,$33,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1416 : 1418
	db	$fc,$29,$31,$02,$fc,$12,$31,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1417 : 1456
	db	$fc,$29,$30,$02,$fc,$05,$3a,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1418 : 1537
	db	$fc,$02,$36,$05,$fc,$17,$36,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1418 : 1588
	db	$fc,$05,$43,$02,$fc,$03,$36,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1419 : 1621
	db	$38,$07,$35,$03,$fc,$0a,$30,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1419 : 1651
	db	$fc,$03,$35,$14,$fc,$14,$39,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1419 : 1676
	db	$33,$03,$fc,$05,$33,$02,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1420 : 1739
	db	$32,$08,$33,$14,$fc,$28,$31,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1420 : 1752
	db	$fc,$0d,$38,$05,$fc,$03,$40,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1421 : 1840
	db	$38,$14,$37,$05,$fc,$24,$fc,$2b	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1422 : 1881
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1423 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1427 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1431 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1435 : 2913
	db	$fc,$29,$33,$8d,$fc,$15,$38,$8d	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1439 : 3236
	db	$fc,$14,$fc,$2a,$fc,$0d,$fc,$47	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1443 : 3580
	db	$fc,$08,$fc,$03,$fc,$20,$45,$29	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1445 : 3726
	db	$2b,$28,$45,$29,$2b,$14,$fc,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1446 : 3810
	db	$45,$29,$2b,$14,$fc,$14,$2b,$14	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1447 : 3931
	db	$fc,$08,$fc,$05,$2b,$03,$fc,$05	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1448 : 4032
	db	$46,$28,$fc,$29,$fc,$28,$35,$27	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1449 : 4053
	db	$fc,$03,$33,$07,$33,$0e,$3a,$0a	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1450 : 4213
	db	$3a,$0b,$fc,$03,$fc,$05,$fc,$21	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1451 : 4247
	db	$fc,$1e,$fc,$0a,$35,$26,$fc,$03	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1452 : 4299
	db	$33,$03,$33,$12,$3a,$15,$35,$0e	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1453 : 4380
	db	$35,$14,$35,$25,$35,$17,$35,$04	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1453 : 4436
	db	$35,$19,$fc,$21,$fc,$0f
song_000_22_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_22_lp)*2
	dw	song_000_22_lp


song_000_23:	;Trk X
	db	$fc,$51,$fb,$09,$fd,$19,$fe,$81	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1457 : 0
	db	$3b,$02,$fc,$05,$53,$03,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1458 : 81
	db	$4b,$07,$56,$03,$fc,$05,$53,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1458 : 94
	db	$fc,$03,$43,$02,$fc,$2e,$3b,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1458 : 111
	db	$fc,$05,$53,$03,$fc,$02,$4b,$08	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1459 : 164
	db	$56,$03,$fc,$05,$53,$02,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1459 : 182
	db	$43,$02,$fc,$2e,$2b,$02,$fc,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1459 : 195
	db	$43,$03,$fc,$02,$3b,$08,$3b,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1460 : 250
	db	$fc,$06,$4b,$02,$fc,$03,$53,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1460 : 265
	db	$56,$14,$fc,$08,$56,$02,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1460 : 283
	db	$56,$05,$fc,$03,$56,$0c,$fc,$1c	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1460 : 316
	db	$fd,$18,$66,$03,$fd,$19,$65,$11	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1461 : 364
	db	$fc,$08,$fd,$18,$65,$02,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1461 : 384
	db	$65,$05,$fc,$02,$65,$03,$67,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1461 : 397
	db	$65,$03,$67,$02,$65,$05,$67,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1462 : 412
	db	$fc,$07,$65,$03,$fc,$02,$65,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1462 : 425
	db	$fc,$03,$65,$02,$67,$06,$65,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1462 : 442
	db	$67,$03,$65,$05,$67,$02,$fc,$08	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1462 : 455
	db	$60,$02,$fc,$03,$60,$05,$fc,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1462 : 473
	db	$fd,$19,$63,$03,$fc,$05,$fd,$18	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1463 : 485
	db	$60,$03,$fc,$02,$61,$05,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1463 : 493
	db	$fd,$19,$63,$02,$fc,$05,$fd,$18	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1463 : 506
	db	$60,$03,$fc,$11,$60,$05,$fc,$1c	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1463 : 513
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$28	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1464 : 566
	db	$fd,$19,$68,$03,$6a,$02,$68,$08	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1467 : 849
	db	$fd,$18,$65,$08,$fc,$14,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1467 : 862
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1469 : 971
	db	$fd,$19,$40,$05,$fc,$03,$43,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1473 : 1294
	db	$40,$08,$40,$02,$fc,$05,$43,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1473 : 1307
	db	$fc,$02,$56,$03,$fc,$2d,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1473 : 1325
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1475 : 1456
	db	$fc,$51,$fc,$51,$fc,$21,$fd,$17	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1479 : 1780
	db	$43,$07,$55,$03,$55,$05,$57,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1481 : 1975
	db	$48,$1e,$48,$2b,$43,$06,$fc,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1481 : 1995
	db	$43,$1e,$43,$0a,$fc,$03,$43,$14	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1482 : 2079
	db	$48,$14,$4a,$1e,$4a,$26,$fc,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1483 : 2142
	db	$43,$05,$fc,$05,$43,$1f,$43,$17	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1484 : 2235
	db	$fc,$0a,$50,$0a,$53,$05,$fc,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1485 : 2299
	db	$51,$1e,$51,$08,$fd,$16,$50,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1485 : 2329
	db	$4b,$03,$fd,$17,$48,$47,$48,$16	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1486 : 2369
	db	$fc,$0a,$55,$06,$fc,$05,$57,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1487 : 2465
	db	$fc,$05,$49,$02,$48,$1c,$48,$33	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1487 : 2491
	db	$fc,$02,$4a,$1e,$4a,$2b,$57,$06	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1488 : 2577
	db	$fc,$05,$51,$02,$50,$1c,$50,$53	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1489 : 2658
	db	$50,$35,$fc,$1c,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1491 : 2776
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1494 : 3019
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$29	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1498 : 3343
	db	$fc,$29,$fc,$0d,$fc,$47,$fc,$08	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1501 : 3626
	db	$fc,$03,$fc,$21,$fc,$28,$fd,$19	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1503 : 3759
	db	$3b,$03,$fc,$05,$53,$02,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1504 : 3835
	db	$4b,$07,$56,$03,$fc,$05,$53,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1504 : 3848
	db	$fc,$02,$43,$03,$fc,$2d,$3b,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1504 : 3866
	db	$fc,$05,$53,$02,$fc,$03,$4b,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1505 : 3919
	db	$56,$03,$fc,$05,$53,$02,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1505 : 3936
	db	$43,$02,$fc,$06,$fc,$28,$2b,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1505 : 3949
	db	$fc,$05,$43,$02,$fc,$03,$3b,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1506 : 4000
	db	$3b,$03,$fc,$05,$4b,$02,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1506 : 4017
	db	$53,$07,$56,$15,$fc,$07,$56,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1506 : 4030
	db	$fc,$02,$56,$03,$fc,$05,$56,$14	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1506 : 4068
	db	$fc,$14,$fd,$17,$66,$03,$fd,$18	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1507 : 4098
	db	$65,$12,$fc,$07,$65,$03,$fc,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1507 : 4121
	db	$65,$05,$fc,$03,$65,$02,$fd,$17	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1507 : 4151
	db	$67,$05,$65,$03,$67,$02,$65,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1508 : 4161
	db	$67,$03,$fc,$08,$fd,$18,$65,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1508 : 4176
	db	$fc,$03,$65,$05,$fc,$02,$65,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1508 : 4189
	db	$fd,$17,$67,$05,$65,$03,$67,$02	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1508 : 4202
	db	$65,$05,$67,$03,$fc,$08,$fd,$18	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1508 : 4212
	db	$60,$02,$fc,$03,$60,$05,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1508 : 4228
	db	$63,$02,$fc,$06,$60,$02,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1509 : 4241
	db	$61,$05,$fc,$03,$63,$03,$fc,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1509 : 4254
	db	$60,$02,$fc,$0b,$fd,$17,$66,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1509 : 4270
	db	$fd,$18,$65,$05,$65,$0d,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1509 : 4286
	db	$65,$03,$fc,$02,$65,$05,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1509 : 4311
	db	$65,$02,$fd,$17,$67,$05,$65,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1510 : 4324
	db	$67,$02,$65,$06,$67,$02,$fc,$08	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1510 : 4334
	db	$fd,$18,$65,$02,$fc,$03,$65,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1510 : 4352
	db	$fc,$02,$65,$03,$fd,$17,$67,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1510 : 4362
	db	$65,$03,$67,$02,$65,$05,$67,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1510 : 4372
	db	$fc,$08,$fd,$18,$60,$02,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1510 : 4385
	db	$60,$05,$fc,$02,$63,$03,$fc,$05	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1510 : 4398
	db	$60,$03,$fc,$02,$61,$05,$fc,$03	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1511 : 4413
	db	$63,$03,$fc,$05,$60,$03,$fc,$18	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1511 : 4426
	db	$fc,$14,$fc,$0d,$fc,$19,$fc,$17	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1511 : 4461
	db	$fc,$3d,$fc,$0f
song_000_23_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_23_lp)*2
	dw	song_000_23_lp


song_000_24:	;Trk Y
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1515 : 0
	db	$fc,$50,$fc,$51,$fc,$51,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1519 : 324
	db	$fc,$29,$fb,$08,$fd,$14,$fe,$81	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1523 : 647
	db	$40,$79,$40,$28,$3a,$7a,$3a,$28	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1523 : 688
	db	$38,$7a,$38,$28,$3a,$28,$fd,$13	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1525 : 1011
	db	$41,$06,$fc,$02,$41,$05,$41,$05	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1527 : 1213
	db	$fc,$03,$41,$05,$fc,$02,$41,$05	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1527 : 1231
	db	$fc,$30,$fc,$51,$fc,$51,$fc,$29	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1527 : 1246
	db	$fd,$14,$41,$28,$fc,$51,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1530 : 1497
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1533 : 1699
	db	$fc,$29,$fd,$15,$41,$28,$40,$15	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1537 : 2022
	db	$48,$14,$42,$05,$fc,$0f,$3b,$14	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1538 : 2124
	db	$50,$15,$3a,$14,$fd,$14,$43,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1539 : 2184
	db	$43,$77,$43,$a1,$43,$26,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1539 : 2228
	db	$43,$79,$43,$a2,$43,$28,$41,$7a	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1541 : 2549
	db	$41,$a2,$41,$28,$41,$28,$43,$29	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1544 : 2994
	db	$51,$28,$54,$29,$fc,$28,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1546 : 3277
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1549 : 3479
	db	$fc,$51,$fc,$51,$fc,$50,$fc,$51	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1553 : 3803
	db	$fc,$51,$fc,$51,$fc,$29,$fc,$29	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1557 : 4126
	db	$fc,$0d,$fc,$47,$fc,$08,$fc,$03	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1560 : 4370
	db	$fc,$21,$fc,$28,$fc,$51,$fc,$28	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1561 : 4465
	db	$fc,$29,$fc,$51,$fc,$51,$fc,$28	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1563 : 4659
	db	$fc,$2a,$fc,$07,$fc,$18,$fc,$0e	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1566 : 4902
	db	$fc,$05,$fc,$21,$fc,$1e,$fc,$33	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1567 : 4989
	db	$fc,$03,$fc,$12,$fc,$23,$fc,$14	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1569 : 5108
	db	$fc,$0d,$fc,$18,$fc,$18,$fc,$3d	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1569 : 5184
	db	$fc,$0f
song_000_24_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_24_lp)*2
	dw	song_000_24_lp


song_000_25:	;Trk Z
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1573 : 0
	db	$fc,$50,$fc,$45,$fb,$09,$fd,$18	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1577 : 324
	db	$fe,$81,$65,$02,$fc,$03,$65,$05	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1578 : 473
	db	$fc,$02,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1578 : 483
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1582 : 728
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1586 : 1052
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1590 : 1375
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$2b	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1594 : 1699
	db	$fc,$26,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1597 : 1985
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1601 : 2266
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1605 : 2589
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$50	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1609 : 2913
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1613 : 3236
	db	$fc,$28,$fc,$2a,$fc,$0d,$fc,$47	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1617 : 3560
	db	$fc,$08,$fc,$03,$fc,$20,$fc,$29	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1619 : 3726
	db	$fc,$51,$fc,$28,$fc,$29,$fc,$51	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1620 : 3810
	db	$fc,$51,$fc,$28,$fc,$1d,$65,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1623 : 4053
	db	$fc,$03,$65,$05,$fc,$03,$fc,$07	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1624 : 4205
	db	$fc,$18,$fc,$0e,$fc,$05,$fc,$21	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1625 : 4223
	db	$fc,$1e,$fc,$26,$65,$03,$fc,$02	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1626 : 4299
	db	$65,$05,$fc,$03,$fc,$03,$fc,$12	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1626 : 4372
	db	$fc,$23,$fc,$14,$fc,$0c,$fc,$19	;Trk Z; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1627 : 4401
	db	$fc,$17,$fc,$3e,$fc,$0f
song_000_25_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_25_lp)*2
	dw	song_000_25_lp


song_000_26:	;Trk a
	db	$fb,$08,$fd,$15,$fe,$06,$5b,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1631 : 0
	db	$fc,$03,$fd,$14,$4b,$05,$46,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1631 : 5
	db	$46,$05,$fc,$03,$46,$05,$35,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1631 : 20
	db	$35,$29,$35,$28,$35,$29,$35,$28	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1631 : 40
	db	$35,$29,$35,$28,$43,$17,$fc,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1633 : 202
	db	$43,$02,$fc,$03,$43,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1634 : 311
	db	$43,$14,$3b,$14,$fc,$28,$fc,$51	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1635 : 324
	db	$fc,$29,$55,$07,$fd,$13,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1637 : 485
	db	$45,$06,$fc,$02,$45,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1637 : 538
	db	$45,$05,$45,$05,$fc,$02,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1637 : 554
	db	$fc,$03,$45,$05,$45,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1638 : 571
	db	$45,$05,$fc,$02,$45,$05,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1638 : 587
	db	$fc,$03,$45,$05,$fc,$02,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1638 : 604
	db	$45,$05,$fc,$03,$45,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1638 : 619
	db	$45,$05,$45,$05,$fc,$02,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1638 : 635
	db	$fc,$03,$45,$05,$45,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1639 : 652
	db	$45,$05,$fc,$03,$45,$05,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1639 : 667
	db	$fc,$03,$45,$05,$fc,$02,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1639 : 685
	db	$45,$05,$fc,$03,$45,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1639 : 700
	db	$45,$06,$45,$05,$fc,$02,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1639 : 715
	db	$fc,$03,$45,$05,$45,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1640 : 733
	db	$45,$05,$fc,$03,$45,$05,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1640 : 748
	db	$fc,$03,$47,$05,$fc,$02,$47,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1640 : 766
	db	$47,$05,$fc,$03,$47,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1640 : 781
	db	$47,$05,$47,$05,$fc,$03,$47,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1640 : 796
	db	$fc,$03,$47,$05,$47,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1641 : 814
	db	$47,$05,$fc,$03,$47,$05,$47,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1641 : 829
	db	$fc,$02,$45,$05,$fc,$03,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1641 : 847
	db	$45,$05,$fc,$03,$45,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1641 : 862
	db	$45,$05,$45,$05,$fc,$03,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1641 : 877
	db	$fc,$02,$45,$06,$45,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1642 : 895
	db	$45,$05,$fc,$03,$45,$05,$45,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1642 : 910
	db	$fc,$02,$44,$05,$fc,$03,$44,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1642 : 928
	db	$44,$05,$fc,$03,$44,$05,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1642 : 943
	db	$44,$05,$44,$05,$fc,$03,$44,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1642 : 958
	db	$fc,$02,$44,$05,$44,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1643 : 976
	db	$44,$05,$fc,$03,$44,$05,$44,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1643 : 991
	db	$fc,$2b,$fc,$51,$fc,$28,$fd,$15	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1643 : 1009
	db	$31,$14,$fd,$14,$31,$14,$fd,$15	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1645 : 1173
	db	$31,$15,$45,$14,$fd,$14,$30,$28	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1646 : 1213
	db	$fd,$15,$4a,$1c,$fc,$03,$46,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1647 : 1294
	db	$fc,$03,$fd,$14,$45,$21,$49,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1647 : 1332
	db	$fc,$02,$50,$4f,$fc,$02,$53,$1c	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1647 : 1373
	db	$52,$03,$fc,$02,$51,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1649 : 1484
	db	$38,$28,$3a,$29,$fc,$28,$fc,$28	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1649 : 1497
	db	$35,$03,$fc,$0a,$30,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1651 : 1658
	db	$35,$0c,$37,$05,$fc,$03,$35,$14	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1651 : 1679
	db	$45,$0d,$fc,$07,$47,$03,$fc,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1652 : 1719
	db	$fc,$05,$46,$08,$47,$14,$4a,$0f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1652 : 1747
	db	$49,$02,$45,$03,$50,$12,$fc,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1653 : 1795
	db	$31,$29,$35,$28,$35,$05,$fc,$0f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1653 : 1820
	db	$32,$15,$30,$14,$47,$14,$fd,$13	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1654 : 1921
	db	$30,$03,$30,$9d,$fc,$02,$30,$a2	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1655 : 1982
	db	$fd,$14,$31,$a2,$fd,$13,$31,$51	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1659 : 2306
	db	$fd,$14,$33,$28,$34,$29,$fc,$28	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1662 : 2549
	db	$fc,$51,$fc,$51,$fc,$51,$36,$0a	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1664 : 2670
	db	$3a,$0a,$46,$0a,$40,$0a,$41,$8e	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1667 : 2923
	db	$fc,$3d,$fc,$50,$fc,$51,$fc,$51	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1669 : 3095
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1673 : 3398
	db	$fc,$0d,$fc,$47,$5b,$05,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1676 : 3642
	db	$4b,$03,$4b,$02,$46,$09,$46,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1677 : 3734
	db	$fc,$03,$46,$05,$35,$08,$35,$29	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1677 : 3753
	db	$35,$28,$35,$29,$fc,$28,$35,$29	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1678 : 3810
	db	$fc,$28,$43,$17,$fc,$05,$43,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1680 : 3972
	db	$fc,$03,$43,$03,$fc,$05,$43,$14	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1680 : 4042
	db	$3b,$14,$fc,$29,$fc,$28,$fc,$2a	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1681 : 4073
	db	$fc,$07,$fc,$18,$fc,$0e,$fc,$05	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1683 : 4216
	db	$fc,$21,$fc,$1e,$fc,$33,$fc,$03	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1683 : 4266
	db	$fc,$12,$fc,$15,$45,$0e,$45,$14	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1685 : 4383
	db	$45,$25,$45,$17,$45,$04,$35,$19	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1685 : 4456
	db	$fc,$21,$fc,$0f
song_000_26_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_26_lp)*2
	dw	song_000_26_lp


song_000_27:	;Trk b
	db	$fb,$08,$fd,$14,$fe,$06,$55,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1689 : 0
	db	$fc,$03,$55,$05,$53,$07,$4b,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1689 : 5
	db	$fc,$03,$43,$05,$3b,$07,$43,$29	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1689 : 25
	db	$fc,$28,$43,$29,$fc,$28,$43,$29	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1690 : 81
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$30	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1692 : 243
	db	$fd,$13,$49,$05,$49,$06,$fc,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1695 : 533
	db	$4a,$05,$fc,$03,$49,$05,$49,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1695 : 546
	db	$fc,$02,$49,$05,$fc,$03,$49,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1695 : 564
	db	$49,$05,$fc,$03,$4a,$05,$fc,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1696 : 579
	db	$49,$05,$49,$05,$fc,$03,$49,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1696 : 594
	db	$fc,$02,$49,$05,$49,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1696 : 612
	db	$4a,$05,$fc,$03,$49,$05,$49,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1696 : 627
	db	$fc,$02,$4a,$05,$fc,$03,$49,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1696 : 645
	db	$49,$05,$fc,$02,$4a,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1697 : 660
	db	$49,$05,$49,$05,$fc,$03,$49,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1697 : 675
	db	$fc,$02,$49,$05,$49,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1697 : 693
	db	$49,$05,$fc,$02,$49,$06,$49,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1697 : 708
	db	$fc,$02,$49,$05,$fc,$03,$49,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1697 : 726
	db	$49,$05,$fc,$02,$49,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1698 : 741
	db	$49,$05,$49,$05,$fc,$03,$4a,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1698 : 756
	db	$fc,$02,$4a,$05,$4a,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1698 : 774
	db	$4a,$05,$fc,$02,$4a,$05,$4a,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1698 : 789
	db	$fc,$03,$4a,$05,$fc,$03,$4a,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1698 : 806
	db	$4a,$05,$fc,$02,$4a,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1699 : 822
	db	$4a,$05,$4a,$05,$fc,$02,$48,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1699 : 837
	db	$fc,$03,$48,$05,$48,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1699 : 854
	db	$48,$05,$fc,$02,$48,$05,$48,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1699 : 870
	db	$fc,$03,$48,$05,$fc,$02,$48,$06	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1699 : 887
	db	$48,$05,$fc,$02,$48,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1700 : 903
	db	$48,$05,$48,$05,$fc,$02,$47,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1700 : 918
	db	$fc,$03,$47,$05,$47,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1700 : 935
	db	$47,$05,$fc,$02,$47,$05,$47,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1700 : 951
	db	$fc,$03,$fd,$14,$37,$21,$fd,$13	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1700 : 968
	db	$41,$05,$fc,$2b,$fc,$51,$fc,$28	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1701 : 1004
	db	$fd,$15,$35,$14,$fd,$14,$28,$14	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1703 : 1173
	db	$fd,$15,$38,$15,$41,$14,$fd,$14	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1704 : 1213
	db	$3a,$28,$40,$26,$fc,$03,$35,$21	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1704 : 1254
	db	$39,$05,$fc,$02,$40,$4f,$fc,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1705 : 1368
	db	$43,$1c,$42,$03,$fc,$02,$41,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1707 : 1456
	db	$fc,$03,$50,$51,$fc,$28,$fc,$28	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1707 : 1494
	db	$39,$03,$fc,$0a,$35,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1709 : 1658
	db	$39,$0c,$3a,$05,$fc,$03,$40,$14	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1709 : 1679
	db	$39,$0d,$fc,$07,$43,$03,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1710 : 1719
	db	$fc,$05,$42,$08,$43,$14,$53,$11	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1710 : 1747
	db	$51,$03,$43,$12,$fc,$02,$38,$29	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1711 : 1797
	db	$28,$28,$4b,$05,$fc,$0f,$52,$15	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1712 : 1861
	db	$44,$14,$34,$14,$fd,$13,$38,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1713 : 1942
	db	$38,$9d,$fc,$02,$36,$a2,$fd,$14	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1713 : 1985
	db	$35,$a2,$fd,$13,$34,$51,$fd,$14	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1717 : 2306
	db	$47,$28,$4a,$29,$fc,$28,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1720 : 2549
	db	$fc,$51,$fc,$51,$fc,$51,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1723 : 2751
	db	$fc,$51,$fc,$50,$fc,$51,$fc,$51	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1727 : 3075
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1731 : 3398
	db	$fc,$0d,$fc,$47,$55,$05,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1734 : 3642
	db	$55,$03,$55,$02,$53,$09,$4b,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1735 : 3734
	db	$fc,$03,$43,$05,$3b,$08,$43,$29	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1735 : 3753
	db	$fc,$28,$43,$29,$fc,$28,$43,$29	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1736 : 3810
	db	$fc,$51,$fc,$51,$fc,$28,$fc,$2a	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1738 : 3972
	db	$fc,$07,$fc,$18,$fc,$0e,$fc,$05	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1741 : 4216
	db	$fc,$21,$fc,$1e,$fc,$33,$fc,$03	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1741 : 4266
	db	$fc,$12,$fc,$15,$39,$0e,$39,$14	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1743 : 4383
	db	$39,$25,$39,$17,$39,$04,$25,$19	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mTitle_Screen_bw_abc_style.mml: 1743 : 4456
	db	$fc,$21,$fc,$0f
song_000_27_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_27_lp)*2
	dw	song_000_27_lp

