; Title: mrpgbattle
; Composer: 
; Maker: 
; Programer: mid2mml for ppmck Ver1.0�� & stgig

	.bank	0
	.if TOTAL_SONGS > 1
song_addr_table:
	dw	song_000_track_table
	.if (ALLOW_BANK_SWITCH)
song_bank_table:
	dw	song_000_bank_table
	.endif ; ALLOW_BANK_SWITCH
	.endif ; TOTAL_SONGS > 1
song_000_track_table:
	dw	song_000_00
	dw	song_000_01
	dw	song_000_02
	dw	song_000_03
	dw	song_000_04
	dw	song_000_05
	dw	song_000_06
	dw	song_000_07
	dw	song_000_08
	dw	song_000_09
	dw	song_000_10
	dw	song_000_11
	dw	song_000_12
	dw	song_000_13
	dw	song_000_14
	dw	song_000_15
	dw	song_000_16
	dw	song_000_17
	dw	song_000_18
	dw	song_000_19
	dw	song_000_20
	dw	song_000_21
	dw	song_000_22
	dw	song_000_23
	dw	song_000_24
	dw	song_000_25
	dw	song_000_26
	dw	song_000_27
	.if (ALLOW_BANK_SWITCH)
song_000_bank_table:
	db	bank(song_000_00)*2
	db	bank(song_000_01)*2
	db	bank(song_000_02)*2
	db	bank(song_000_03)*2
	db	bank(song_000_04)*2
	db	bank(song_000_05)*2
	db	bank(song_000_06)*2
	db	bank(song_000_07)*2
	db	bank(song_000_08)*2
	db	bank(song_000_09)*2
	db	bank(song_000_10)*2
	db	bank(song_000_11)*2
	db	bank(song_000_12)*2
	db	bank(song_000_13)*2
	db	bank(song_000_14)*2
	db	bank(song_000_15)*2
	db	bank(song_000_16)*2
	db	bank(song_000_17)*2
	db	bank(song_000_18)*2
	db	bank(song_000_19)*2
	db	bank(song_000_20)*2
	db	bank(song_000_21)*2
	db	bank(song_000_22)*2
	db	bank(song_000_23)*2
	db	bank(song_000_24)*2
	db	bank(song_000_25)*2
	db	bank(song_000_26)*2
	db	bank(song_000_27)*2
	.endif

song_000_00:	;Trk A
	db	$ee
	db	bank(song_000_00_bnk001)*2
	dw	song_000_00_bnk001

	.bank	1
	.org	$a000
song_000_00_bnk001:
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 117 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 121 : 443
	db	$fc,$6f,$fc,$07,$fb,$06,$fd,$0d	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 125 : 886
	db	$fe,$01,$24,$1c,$16,$14,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 126 : 1004
	db	$fc,$07,$18,$07,$fc,$07,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 126 : 1059
	db	$24,$0e,$1b,$07,$fc,$07,$24,$1b	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 126 : 1087
	db	$16,$15,$18,$07,$fc,$07,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 127 : 1142
	db	$fc,$07,$18,$07,$24,$0e,$1b,$06	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 127 : 1184
	db	$fc,$07,$24,$1c,$16,$15,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 128 : 1218
	db	$fc,$07,$18,$07,$fc,$07,$18,$06	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 128 : 1281
	db	$24,$0e,$1b,$07,$fc,$07,$24,$1c	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 128 : 1308
	db	$16,$15,$18,$07,$fc,$06,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 129 : 1364
	db	$fc,$07,$18,$07,$24,$0e,$1b,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 129 : 1405
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 130 : 1440
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 134 : 1883
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 138 : 2326
	db	$fc,$07,$24,$1c,$16,$15,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 142 : 2769
	db	$fc,$06,$18,$07,$fc,$07,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 142 : 2832
	db	$24,$0e,$1b,$07,$fc,$07,$24,$1c	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 142 : 2859
	db	$16,$14,$18,$07,$fc,$07,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 143 : 2915
	db	$fc,$07,$18,$07,$24,$0e,$1b,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 143 : 2956
	db	$fc,$07,$24,$1b,$16,$15,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 144 : 2991
	db	$fc,$07,$18,$07,$fc,$07,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 144 : 3053
	db	$24,$0e,$1b,$07,$fc,$06,$24,$1c	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 144 : 3081
	db	$16,$15,$18,$07,$fc,$07,$18,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 145 : 3136
	db	$fc,$07,$18,$07,$24,$0d,$1b,$07	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 145 : 3178
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 146 : 3212
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 150 : 3655
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk A; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 154 : 4098

song_000_00_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_00_lp)*2
	dw	song_000_00_lp


song_000_01:	;Trk B
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 160 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 164 : 443
	db	$fc,$6f,$fc,$07,$fb,$06,$fd,$0d	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 168 : 886
	db	$fe,$01,$1b,$1c,$19,$14,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 169 : 1004
	db	$fc,$07,$1b,$07,$fc,$07,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 169 : 1059
	db	$21,$0e,$23,$07,$fc,$07,$1b,$1b	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 169 : 1087
	db	$19,$15,$1b,$07,$fc,$07,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 170 : 1142
	db	$fc,$07,$1b,$07,$21,$0e,$23,$06	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 170 : 1184
	db	$fc,$07,$1b,$1c,$19,$15,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 171 : 1218
	db	$fc,$07,$1b,$07,$fc,$07,$1b,$06	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 171 : 1281
	db	$21,$0e,$23,$07,$fc,$07,$1b,$1c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 171 : 1308
	db	$19,$15,$1b,$07,$fc,$06,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 172 : 1364
	db	$fc,$07,$1b,$07,$21,$0e,$23,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 172 : 1405
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 173 : 1440
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 177 : 1883
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 181 : 2326
	db	$fc,$07,$1b,$1c,$19,$15,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 185 : 2769
	db	$fc,$06,$1b,$07,$fc,$07,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 185 : 2832
	db	$21,$0e,$23,$07,$fc,$07,$1b,$1c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 185 : 2859
	db	$19,$14,$1b,$07,$fc,$07,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 186 : 2915
	db	$fc,$07,$1b,$07,$21,$0e,$23,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 186 : 2956
	db	$fc,$07,$1b,$1b,$19,$15,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 187 : 2991
	db	$fc,$07,$1b,$07,$fc,$07,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 187 : 3053
	db	$21,$0e,$23,$07,$fc,$06,$1b,$1c	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 187 : 3081
	db	$19,$15,$1b,$07,$fc,$07,$1b,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 188 : 3136
	db	$fc,$07,$1b,$07,$21,$0d,$23,$07	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 188 : 3178
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 189 : 3212
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 193 : 3655
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk B; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 197 : 4098

song_000_01_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_01_lp)*2
	dw	song_000_01_lp


song_000_02:	;Trk C
	db	$fe,$8f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 88 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 206 : 332
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 210 : 775
	db	$fc,$6f,$fc,$6f,$fc,$07,$fb,$08	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 214 : 1218
	db	$54,$13,$fc,$02,$fc,$07,$53,$09	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 216 : 1447
	db	$fc,$01,$fc,$03,$53,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 216 : 1475
	db	$51,$06,$fc,$01,$fc,$07,$4b,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 216 : 1495
	db	$fc,$01,$fc,$07,$4b,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 216 : 1509
	db	$51,$06,$fc,$01,$fc,$07,$53,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 216 : 1530
	db	$fc,$01,$fc,$07,$54,$0d,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 216 : 1544
	db	$53,$05,$fc,$01,$fc,$07,$51,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 217 : 1572
	db	$fc,$01,$fc,$07,$4b,$34,$fc,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 217 : 1585
	db	$fc,$07,$fc,$06,$54,$13,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 217 : 1655
	db	$fc,$07,$53,$0a,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 218 : 1689
	db	$53,$06,$fc,$01,$51,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 218 : 1710
	db	$fc,$07,$4b,$06,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 218 : 1724
	db	$4b,$06,$fc,$01,$51,$05,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 218 : 1745
	db	$fc,$07,$53,$06,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 218 : 1758
	db	$4b,$0d,$fc,$01,$51,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 219 : 1779
	db	$fc,$07,$53,$06,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 219 : 1800
	db	$54,$33,$fc,$04,$fc,$07,$fc,$6f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 219 : 1821
	db	$fc,$6f,$fc,$6e,$fc,$6f,$fc,$6f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 221 : 1994
	db	$fc,$6f,$fc,$6e,$fc,$6f,$fc,$6f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 225 : 2437
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 229 : 2880
	db	$54,$13,$fc,$02,$fc,$07,$53,$09	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 232 : 3219
	db	$fc,$01,$fc,$04,$53,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 232 : 3247
	db	$51,$06,$fc,$01,$fc,$07,$4b,$05	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 232 : 3268
	db	$fc,$01,$fc,$07,$4b,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 232 : 3282
	db	$51,$06,$fc,$01,$fc,$07,$53,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 232 : 3302
	db	$fc,$01,$fc,$07,$54,$0d,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 232 : 3316
	db	$53,$06,$fc,$01,$fc,$07,$51,$06	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 233 : 3344
	db	$fc,$01,$fc,$07,$4b,$33,$fc,$04	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 233 : 3358
	db	$fc,$07,$fc,$07,$54,$13,$fc,$02	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 233 : 3427
	db	$fc,$06,$53,$0a,$fc,$01,$fc,$03	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 234 : 3462
	db	$53,$06,$fc,$01,$51,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 234 : 3482
	db	$fc,$07,$4b,$06,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 234 : 3496
	db	$4b,$06,$fc,$01,$51,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 234 : 3517
	db	$fc,$07,$53,$06,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 234 : 3531
	db	$4b,$0c,$fc,$01,$51,$06,$fc,$01	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 235 : 3552
	db	$fc,$07,$53,$06,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 235 : 3572
	db	$54,$33,$fc,$04,$fc,$07,$fc,$6f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 235 : 3593
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk C; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 237 : 3766
	db	$fc,$6f,$fc,$6f,$fc,$6f
song_000_02_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_02_lp)*2
	dw	song_000_02_lp


song_000_03:	;Trk D
	db	$fe,$8f,$fc,$68,$fd,$26,$52,$15	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 88 : 0
	db	$52,$1b,$52,$1c,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 247 : 125
	db	$52,$1c,$52,$1c,$52,$1b,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 248 : 235
	db	$52,$1c,$52,$1c,$52,$1b,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 249 : 346
	db	$52,$1c,$52,$1b,$52,$1c,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 250 : 457
	db	$52,$1b,$52,$1c,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 251 : 568
	db	$52,$1c,$52,$1c,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 252 : 678
	db	$52,$1c,$52,$1c,$52,$1b,$52,$6f	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 253 : 789
	db	$fc,$0e,$fc,$0e,$52,$1b,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 254 : 983
	db	$52,$1c,$52,$1c,$52,$1b,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 255 : 1066
	db	$52,$1c,$52,$1b,$52,$1c,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 256 : 1177
	db	$52,$1b,$52,$1c,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 257 : 1288
	db	$52,$1c,$52,$6f,$fc,$0e,$fc,$6f	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 258 : 1398
	db	$fc,$6e,$fa,$ff,$fd,$27,$55,$0e	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 261 : 1662
	db	$55,$0e,$55,$07,$55,$0e,$55,$0e	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 262 : 1786
	db	$55,$0d,$55,$07,$55,$0e,$55,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 262 : 1835
	db	$fd,$26,$52,$1c,$52,$1b,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 263 : 1897
	db	$52,$1c,$52,$1b,$52,$1c,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 263 : 1980
	db	$52,$1b,$52,$1c,$52,$1c,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 264 : 2091
	db	$52,$1b,$52,$1c,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 265 : 2202
	db	$52,$1c,$52,$1c,$52,$1b,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 266 : 2312
	db	$52,$1c,$52,$1b,$52,$1c,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 267 : 2423
	db	$52,$1c,$52,$1b,$52,$1c,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 268 : 2534
	db	$52,$6e,$fc,$0e,$fc,$0e,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 269 : 2645
	db	$52,$1b,$52,$1c,$52,$1c,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 271 : 2811
	db	$52,$1b,$52,$1c,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 272 : 2922
	db	$52,$1c,$52,$1c,$52,$1b,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 273 : 3032
	db	$52,$1c,$52,$1b,$52,$6f,$fc,$0e	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 274 : 3143
	db	$fc,$6f,$fc,$6f,$fd,$27,$55,$0d	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 276 : 3323
	db	$55,$0e,$55,$07,$55,$0e,$55,$0e	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 278 : 3558
	db	$55,$0e,$55,$07,$55,$0e,$55,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 278 : 3607
	db	$fd,$26,$52,$1c,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 279 : 3669
	db	$52,$0e,$fc,$0e,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 279 : 3752
	db	$52,$1c,$52,$0e,$fc,$0e,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 280 : 3835
	db	$52,$1c,$52,$1c,$52,$0e,$fc,$0e	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 281 : 3918
	db	$52,$1b,$52,$1c,$52,$1c,$52,$0d	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 282 : 4002
	db	$fc,$0e,$52,$1c,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 283 : 4098
	db	$52,$0e,$fc,$0e,$52,$1c,$52,$1b	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 283 : 4195
	db	$52,$1c,$52,$0e,$fc,$0e,$52,$1c	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 284 : 4278
	db	$52,$1b,$52,$1c,$52,$0e,$fc,$6f	;Trk D; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 285 : 4362

song_000_03_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_03_lp)*2
	dw	song_000_03_lp


song_000_04:	;Trk E
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 289 : 0
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 289 : 14
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 289 : 28
	db	$00,$03,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 289 : 42
	db	$00,$04,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 289 : 55
	db	$00,$04,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 289 : 69
	db	$01,$0e,$02,$07,$03,$07,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 289 : 83
	db	$02,$0e,$02,$06,$01,$15,$02,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 290 : 118
	db	$02,$03,$03,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 290 : 163
	db	$01,$15,$02,$07,$04,$06,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 290 : 194
	db	$02,$07,$01,$15,$02,$03,$02,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 291 : 242
	db	$03,$07,$02,$0e,$02,$07,$01,$14	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 291 : 277
	db	$02,$07,$04,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 291 : 325
	db	$01,$15,$02,$03,$02,$04,$03,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 292 : 360
	db	$02,$0d,$02,$07,$01,$15,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 292 : 395
	db	$04,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 293 : 443
	db	$02,$03,$02,$03,$03,$07,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 293 : 492
	db	$02,$07,$01,$15,$02,$07,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 293 : 519
	db	$02,$0e,$02,$07,$01,$14,$02,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 294 : 561
	db	$02,$03,$03,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 294 : 606
	db	$01,$15,$02,$07,$04,$07,$02,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 294 : 637
	db	$02,$07,$01,$15,$02,$04,$02,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 295 : 685
	db	$03,$07,$02,$0e,$02,$07,$01,$14	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 295 : 720
	db	$02,$07,$04,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 295 : 768
	db	$01,$15,$02,$03,$02,$04,$03,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 296 : 803
	db	$02,$0e,$02,$06,$01,$15,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 296 : 838
	db	$00,$04,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 297 : 886
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 297 : 900
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 297 : 914
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 297 : 928
	db	$00,$03,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 297 : 942
	db	$00,$04,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 297 : 955
	db	$00,$04,$00,$03,$00,$04,$00,$0a	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 297 : 969
	db	$02,$03,$02,$04,$04,$07,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 297 : 990
	db	$02,$07,$01,$14,$02,$04,$02,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 298 : 1018
	db	$03,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 298 : 1052
	db	$02,$07,$04,$07,$02,$0d,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 298 : 1101
	db	$01,$15,$02,$04,$02,$03,$03,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 299 : 1135
	db	$02,$0e,$02,$07,$01,$15,$02,$06	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 299 : 1170
	db	$04,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 300 : 1218
	db	$02,$03,$02,$04,$03,$07,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 300 : 1267
	db	$02,$07,$01,$14,$02,$07,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 300 : 1295
	db	$02,$0e,$02,$07,$01,$15,$02,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 301 : 1336
	db	$02,$04,$03,$07,$02,$0d,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 301 : 1381
	db	$01,$15,$02,$07,$04,$1c,$04,$1b	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 301 : 1412
	db	$04,$1c,$04,$1c,$04,$1b,$04,$1c	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 302 : 1495
	db	$04,$1c,$04,$1c,$04,$1b,$04,$1c	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 303 : 1606
	db	$04,$1c,$04,$1b,$00,$0e,$00,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 304 : 1717
	db	$00,$07,$00,$0e,$00,$07,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 305 : 1800
	db	$00,$0d,$00,$07,$00,$0e,$00,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 305 : 1835
	db	$04,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 306 : 1883
	db	$02,$03,$02,$03,$03,$07,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 306 : 1932
	db	$02,$07,$01,$15,$02,$07,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 306 : 1959
	db	$02,$0e,$02,$07,$01,$14,$02,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 307 : 2001
	db	$02,$03,$03,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 307 : 2046
	db	$01,$15,$02,$07,$04,$07,$02,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 307 : 2077
	db	$02,$07,$01,$15,$02,$04,$02,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 308 : 2125
	db	$03,$07,$02,$0e,$02,$07,$01,$14	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 308 : 2160
	db	$02,$07,$04,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 308 : 2208
	db	$01,$15,$02,$03,$02,$04,$03,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 309 : 2243
	db	$02,$0e,$02,$06,$01,$15,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 309 : 2278
	db	$04,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 310 : 2326
	db	$02,$03,$02,$04,$03,$06,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 310 : 2375
	db	$02,$07,$01,$15,$02,$07,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 310 : 2402
	db	$02,$0e,$02,$07,$01,$14,$02,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 311 : 2444
	db	$02,$03,$03,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 311 : 2489
	db	$01,$15,$02,$07,$04,$07,$02,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 311 : 2520
	db	$02,$07,$01,$15,$02,$04,$02,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 312 : 2568
	db	$03,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 312 : 2603
	db	$02,$06,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 312 : 2652
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 313 : 2669
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 313 : 2683
	db	$00,$03,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 313 : 2697
	db	$00,$04,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 313 : 2710
	db	$00,$04,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 313 : 2724
	db	$00,$04,$00,$03,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 313 : 2738
	db	$00,$0a,$02,$04,$02,$03,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 313 : 2752
	db	$02,$0e,$02,$07,$01,$15,$02,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 314 : 2776
	db	$02,$04,$03,$07,$02,$0d,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 314 : 2821
	db	$01,$15,$02,$07,$04,$07,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 314 : 2852
	db	$02,$07,$01,$14,$02,$04,$02,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 315 : 2901
	db	$03,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 315 : 2935
	db	$02,$07,$04,$07,$02,$0e,$02,$06	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 315 : 2984
	db	$01,$15,$02,$04,$02,$03,$03,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 316 : 3018
	db	$02,$0e,$02,$07,$01,$15,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 316 : 3053
	db	$04,$06,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 317 : 3102
	db	$02,$03,$02,$04,$03,$07,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 317 : 3150
	db	$02,$07,$01,$14,$02,$07,$04,$1c	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 317 : 3178
	db	$04,$1c,$04,$1b,$04,$1c,$04,$1c	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 318 : 3240
	db	$04,$1b,$04,$1c,$04,$1c,$04,$1c	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 319 : 3351
	db	$04,$1b,$04,$1c,$04,$1c,$00,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 320 : 3462
	db	$00,$0e,$00,$07,$00,$0e,$00,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 321 : 3558
	db	$04,$07,$00,$0e,$00,$07,$00,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 321 : 3600
	db	$00,$0d,$04,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 321 : 3642
	db	$01,$15,$02,$03,$02,$04,$03,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 322 : 3683
	db	$02,$0e,$02,$06,$01,$15,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 322 : 3718
	db	$04,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 323 : 3766
	db	$02,$03,$02,$04,$03,$06,$02,$0e	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 323 : 3815
	db	$02,$07,$01,$15,$02,$07,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 323 : 3842
	db	$02,$0e,$02,$07,$01,$14,$02,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 324 : 3884
	db	$02,$03,$03,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 324 : 3929
	db	$01,$15,$02,$07,$04,$07,$02,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 324 : 3960
	db	$02,$07,$01,$15,$02,$04,$02,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 325 : 4008
	db	$03,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 325 : 4043
	db	$02,$06,$04,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 325 : 4092
	db	$01,$15,$02,$03,$02,$04,$03,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 326 : 4126
	db	$02,$0e,$02,$07,$01,$14,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 326 : 4161
	db	$04,$07,$02,$0e,$02,$07,$01,$15	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 327 : 4209
	db	$02,$03,$02,$04,$03,$07,$02,$0d	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 327 : 4258
	db	$02,$07,$01,$15,$02,$07,$04,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 327 : 4285
	db	$02,$0e,$02,$07,$01,$14,$02,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 328 : 4327
	db	$02,$03,$03,$07,$02,$0e,$02,$07	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 328 : 4372
	db	$01,$15,$02,$07,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 328 : 4403
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 329 : 4438
	db	$00,$03,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 329 : 4452
	db	$00,$04,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 329 : 4465
	db	$00,$04,$00,$03,$00,$04,$00,$03	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 329 : 4479
	db	$00,$04,$00,$03,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 329 : 4493
	db	$00,$03,$00,$04,$00,$03,$00,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 329 : 4507
	db	$00,$03,$00,$0b,$02,$03,$02,$04	;Trk E; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 329 : 4521

song_000_04_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_04_lp)*2
	dw	song_000_04_lp


song_000_05:	;Trk F
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 332 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 336 : 443
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 340 : 886
	db	$fc,$6f,$fb,$08,$fd,$19,$fe,$00	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 344 : 1329
	db	$54,$15,$fc,$07,$53,$0a,$fc,$04	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 345 : 1440
	db	$53,$06,$51,$07,$fc,$07,$4b,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 345 : 1482
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 345 : 1509
	db	$53,$07,$fc,$07,$54,$0e,$53,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 345 : 1537
	db	$fc,$06,$51,$07,$fc,$07,$4b,$38	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 346 : 1572
	db	$fc,$0e,$54,$14,$fc,$07,$53,$0b	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 346 : 1648
	db	$fc,$03,$53,$07,$51,$07,$fc,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 347 : 1700
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 347 : 1724
	db	$fc,$06,$53,$07,$fc,$07,$4b,$0e	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 347 : 1752
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 348 : 1786
	db	$54,$37,$fc,$0e,$fc,$6f,$fc,$6f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 348 : 1814
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 351 : 2105
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 355 : 2548
	db	$fc,$6f,$fc,$6e,$54,$15,$fc,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 359 : 2991
	db	$53,$0a,$fc,$04,$53,$07,$51,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 361 : 3240
	db	$fc,$07,$4b,$07,$fc,$06,$4b,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 361 : 3268
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 361 : 3295
	db	$54,$0e,$53,$07,$fc,$07,$51,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 362 : 3323
	db	$fc,$07,$4b,$37,$fc,$0e,$54,$15	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 362 : 3358
	db	$fc,$07,$53,$0a,$fc,$03,$53,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 363 : 3455
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 363 : 3482
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 363 : 3510
	db	$fc,$07,$4b,$0d,$51,$07,$fc,$07	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 363 : 3538
	db	$53,$07,$fc,$07,$54,$38,$fc,$0d	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 364 : 3572
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 365 : 3655
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk F; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 369 : 4098

song_000_05_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_05_lp)*2
	dw	song_000_05_lp


song_000_06:	;Trk G
	db	$fc,$6f,$fd,$1f,$fe,$07,$34,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 375 : 0
	db	$fc,$06,$36,$0e,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 376 : 132
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 376 : 166
	db	$44,$07,$fc,$07,$3b,$0e,$34,$14	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 376 : 194
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 377 : 242
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 377 : 277
	db	$44,$07,$fc,$06,$3b,$0e,$34,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 377 : 305
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 378 : 353
	db	$fc,$07,$38,$07,$fc,$06,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 378 : 388
	db	$44,$07,$fc,$07,$3b,$0e,$34,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 378 : 415
	db	$fc,$07,$36,$0e,$fc,$07,$38,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 379 : 464
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 379 : 498
	db	$44,$07,$fc,$07,$3b,$0e,$44,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 379 : 526
	db	$fc,$07,$3b,$0d,$fc,$07,$39,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 380 : 575
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 380 : 609
	db	$39,$07,$fc,$07,$3b,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 380 : 637
	db	$44,$0d,$43,$07,$fc,$07,$39,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 381 : 665
	db	$fc,$07,$38,$1c,$39,$0e,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 381 : 699
	db	$fc,$07,$36,$06,$fc,$07,$44,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 381 : 755
	db	$fc,$07,$3b,$0e,$fc,$07,$39,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 382 : 796
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 382 : 831
	db	$39,$07,$fc,$07,$3b,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 382 : 858
	db	$38,$0e,$39,$07,$fc,$07,$3b,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 383 : 886
	db	$fc,$07,$44,$37,$36,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 383 : 921
	db	$fc,$6f,$fc,$6e,$34,$15,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 384 : 997
	db	$36,$0e,$fc,$07,$38,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 386 : 1246
	db	$38,$07,$fc,$07,$38,$07,$44,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 386 : 1281
	db	$fc,$07,$3b,$0e,$34,$15,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 386 : 1308
	db	$36,$0e,$fc,$07,$38,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 387 : 1357
	db	$38,$06,$fc,$07,$38,$07,$44,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 387 : 1392
	db	$fc,$07,$3b,$0e,$fc,$6f,$fc,$6f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 387 : 1419
	db	$fc,$6e,$fc,$46,$36,$0d,$34,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 390 : 1662
	db	$fc,$07,$33,$07,$fc,$07,$34,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 391 : 1862
	db	$fc,$07,$36,$0e,$fc,$07,$38,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 392 : 1904
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 392 : 1938
	db	$44,$07,$fc,$07,$3b,$0e,$34,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 392 : 1966
	db	$fc,$07,$36,$0d,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 393 : 2015
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 393 : 2049
	db	$44,$07,$fc,$07,$3b,$0e,$34,$14	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 393 : 2077
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 394 : 2125
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 394 : 2160
	db	$44,$07,$fc,$07,$3b,$0d,$34,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 394 : 2188
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 395 : 2236
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 395 : 2271
	db	$44,$07,$fc,$07,$3b,$0e,$44,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 395 : 2298
	db	$fc,$07,$3b,$0e,$fc,$07,$39,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 396 : 2347
	db	$fc,$06,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 396 : 2382
	db	$39,$07,$fc,$07,$3b,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 396 : 2409
	db	$44,$0e,$43,$07,$fc,$07,$39,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 397 : 2437
	db	$fc,$06,$38,$1c,$39,$0e,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 397 : 2472
	db	$fc,$07,$36,$07,$fc,$07,$44,$14	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 397 : 2527
	db	$fc,$07,$3b,$0e,$fc,$07,$39,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 398 : 2568
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 398 : 2603
	db	$39,$07,$fc,$07,$3b,$07,$fc,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 398 : 2631
	db	$38,$0e,$39,$07,$fc,$07,$3b,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 399 : 2658
	db	$fc,$07,$44,$37,$36,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 399 : 2693
	db	$fc,$6f,$fc,$6f,$34,$15,$fc,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 400 : 2769
	db	$36,$0e,$fc,$07,$38,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 402 : 3018
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 402 : 3053
	db	$fc,$07,$3b,$0e,$34,$14,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 402 : 3081
	db	$36,$0e,$fc,$07,$38,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 403 : 3129
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 403 : 3164
	db	$fc,$06,$3b,$0e,$fc,$6f,$fc,$6f	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 403 : 3192
	db	$fc,$6f,$fc,$45,$36,$0e,$34,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 406 : 3434
	db	$fc,$07,$33,$06,$fc,$07,$34,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 407 : 3635
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 408 : 3676
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 408 : 3711
	db	$44,$07,$fc,$07,$3b,$0e,$34,$15	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 408 : 3738
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 409 : 3787
	db	$fc,$06,$38,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 409 : 3822
	db	$44,$07,$fc,$07,$3b,$0e,$fd,$1e	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 409 : 3849
	db	$34,$15,$fc,$07,$36,$0d,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 410 : 3877
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 410 : 3925
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 410 : 3953
	db	$34,$14,$fc,$07,$36,$0e,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 411 : 3988
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 411 : 4036
	db	$38,$07,$44,$07,$fc,$07,$3b,$0d	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 411 : 4064
	db	$44,$15,$fc,$07,$3b,$0e,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 412 : 4098
	db	$39,$07,$fc,$07,$38,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 412 : 4147
	db	$38,$07,$39,$06,$fc,$07,$3b,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 412 : 4175
	db	$fc,$07,$fd,$1d,$44,$0e,$43,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 412 : 4202
	db	$fc,$07,$39,$07,$fc,$07,$38,$1b	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 413 : 4230
	db	$39,$0e,$38,$07,$fc,$07,$36,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 413 : 4278
	db	$fc,$07,$44,$15,$fc,$07,$3b,$0e	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 413 : 4313
	db	$fc,$06,$39,$07,$fc,$07,$38,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 414 : 4362
	db	$fc,$07,$38,$07,$39,$07,$fc,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 414 : 4389
	db	$3b,$07,$fc,$07,$38,$0e,$39,$07	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 414 : 4417
	db	$fc,$06,$3b,$07,$fc,$07,$44,$38	;Trk G; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 415 : 4452
	db	$36,$07,$fc,$07
song_000_06_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_06_lp)*2
	dw	song_000_06_lp


song_000_07:	;Trk H
	db	$fc,$6f,$fc,$07,$fd,$1f,$fe,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 418 : 0
	db	$34,$14,$fc,$07,$36,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 419 : 118
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 419 : 166
	db	$38,$07,$44,$07,$fc,$07,$3b,$0d	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 419 : 194
	db	$34,$15,$fc,$07,$36,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 420 : 228
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 420 : 277
	db	$38,$07,$44,$06,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 420 : 305
	db	$34,$15,$fc,$07,$36,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 421 : 339
	db	$38,$07,$fc,$07,$38,$06,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 421 : 388
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 421 : 415
	db	$34,$15,$fc,$07,$36,$0e,$fc,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 422 : 450
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 422 : 498
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 422 : 526
	db	$44,$15,$fc,$06,$3b,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 423 : 561
	db	$39,$07,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 423 : 609
	db	$38,$07,$39,$07,$fc,$07,$3b,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 423 : 637
	db	$fc,$07,$44,$0d,$43,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 424 : 665
	db	$39,$07,$fc,$07,$38,$1c,$39,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 424 : 699
	db	$38,$07,$fc,$06,$36,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 424 : 755
	db	$44,$15,$fc,$07,$3b,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 425 : 782
	db	$39,$07,$fc,$07,$38,$07,$fc,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 425 : 831
	db	$38,$07,$39,$07,$fc,$07,$3b,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 425 : 858
	db	$fc,$07,$38,$0e,$39,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 426 : 886
	db	$3b,$07,$fc,$07,$44,$37,$36,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 426 : 921
	db	$fc,$6f,$fc,$6e,$fc,$07,$34,$15	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 427 : 997
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 429 : 1246
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 429 : 1281
	db	$44,$07,$fc,$07,$3b,$0e,$34,$15	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 429 : 1308
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 430 : 1357
	db	$fc,$06,$38,$07,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 430 : 1392
	db	$44,$07,$fc,$07,$3b,$0e,$fc,$68	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 430 : 1419
	db	$fc,$6f,$fc,$6e,$fc,$4c,$36,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 432 : 1551
	db	$34,$07,$fc,$07,$33,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 434 : 1862
	db	$34,$15,$fc,$07,$36,$0e,$fc,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 435 : 1890
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 435 : 1938
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 435 : 1966
	db	$34,$15,$fc,$06,$36,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 436 : 2001
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 436 : 2049
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 436 : 2077
	db	$34,$14,$fc,$07,$36,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 437 : 2112
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 437 : 2160
	db	$38,$07,$44,$07,$fc,$06,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 437 : 2188
	db	$34,$15,$fc,$07,$36,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 438 : 2222
	db	$38,$07,$fc,$07,$38,$07,$fc,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 438 : 2271
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 438 : 2298
	db	$44,$15,$fc,$07,$3b,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 439 : 2333
	db	$39,$06,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 439 : 2382
	db	$38,$07,$39,$07,$fc,$07,$3b,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 439 : 2409
	db	$fc,$07,$44,$0e,$43,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 440 : 2437
	db	$39,$06,$fc,$07,$38,$1c,$39,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 440 : 2472
	db	$38,$07,$fc,$07,$36,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 440 : 2527
	db	$44,$14,$fc,$07,$3b,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 441 : 2555
	db	$39,$07,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 441 : 2603
	db	$38,$07,$39,$07,$fc,$07,$3b,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 441 : 2631
	db	$fc,$07,$38,$0e,$39,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 442 : 2658
	db	$3b,$07,$fc,$07,$44,$37,$36,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 442 : 2693
	db	$fc,$6f,$fc,$6f,$fc,$07,$34,$14	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 443 : 2769
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 445 : 3018
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 445 : 3053
	db	$44,$07,$fc,$07,$3b,$0d,$34,$15	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 445 : 3081
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 446 : 3129
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 446 : 3164
	db	$44,$06,$fc,$07,$3b,$0e,$fc,$68	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 446 : 3192
	db	$fc,$6f,$fc,$6f,$fc,$4c,$36,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 448 : 3323
	db	$34,$07,$fc,$06,$33,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 450 : 3635
	db	$34,$15,$fc,$07,$36,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 451 : 3662
	db	$38,$07,$fc,$07,$38,$07,$fc,$06	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 451 : 3711
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 451 : 3738
	db	$34,$15,$fc,$07,$36,$0e,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 452 : 3773
	db	$38,$06,$fc,$07,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 452 : 3822
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 452 : 3849
	db	$fd,$1e,$34,$15,$fc,$07,$36,$0d	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 453 : 3884
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 453 : 3925
	db	$fc,$07,$38,$07,$44,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 453 : 3953
	db	$3b,$0e,$34,$14,$fc,$07,$36,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 453 : 3981
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 454 : 4036
	db	$fc,$07,$38,$07,$44,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 454 : 4064
	db	$3b,$0d,$44,$15,$fc,$07,$3b,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 454 : 4092
	db	$fc,$07,$39,$07,$fc,$07,$38,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 455 : 4147
	db	$fc,$07,$38,$06,$39,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 455 : 4175
	db	$3b,$07,$fc,$07,$fd,$1d,$44,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 455 : 4202
	db	$43,$07,$fc,$07,$39,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 456 : 4230
	db	$38,$1b,$39,$0e,$38,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 456 : 4258
	db	$36,$07,$fc,$07,$44,$15,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 456 : 4313
	db	$3b,$0d,$fc,$07,$39,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 457 : 4355
	db	$38,$07,$fc,$07,$38,$07,$39,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 457 : 4389
	db	$fc,$07,$3b,$07,$fc,$07,$38,$0e	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 457 : 4417
	db	$39,$06,$fc,$07,$3b,$07,$fc,$07	;Trk H; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 458 : 4452
	db	$44,$38,$36,$07
song_000_07_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_07_lp)*2
	dw	song_000_07_lp


song_000_08:	;Trk I
	db	$fc,$6f,$fd,$1c,$fe,$08,$34,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 461 : 0
	db	$fc,$06,$36,$0e,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 462 : 132
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 462 : 166
	db	$44,$07,$fc,$07,$3b,$0e,$34,$14	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 462 : 194
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 463 : 242
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 463 : 277
	db	$44,$07,$fc,$06,$3b,$0e,$34,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 463 : 305
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 464 : 353
	db	$fc,$07,$38,$07,$fc,$06,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 464 : 388
	db	$44,$07,$fc,$07,$3b,$0e,$34,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 464 : 415
	db	$fc,$07,$36,$0e,$fc,$07,$38,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 465 : 464
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 465 : 498
	db	$44,$07,$fc,$07,$3b,$0e,$44,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 465 : 526
	db	$fc,$07,$3b,$0d,$fc,$07,$39,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 466 : 575
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 466 : 609
	db	$39,$07,$fc,$07,$3b,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 466 : 637
	db	$44,$0d,$43,$07,$fc,$07,$39,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 467 : 665
	db	$fc,$07,$38,$1c,$39,$0e,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 467 : 699
	db	$fc,$07,$36,$06,$fc,$07,$44,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 467 : 755
	db	$fc,$07,$3b,$0e,$fc,$07,$39,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 468 : 796
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 468 : 831
	db	$39,$07,$fc,$07,$3b,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 468 : 858
	db	$38,$0e,$39,$07,$fc,$07,$3b,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 469 : 886
	db	$fc,$07,$44,$37,$36,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 469 : 921
	db	$fc,$6f,$fc,$6e,$34,$15,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 470 : 997
	db	$36,$0e,$fc,$07,$38,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 472 : 1246
	db	$38,$07,$fc,$07,$38,$07,$44,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 472 : 1281
	db	$fc,$07,$3b,$0e,$34,$15,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 472 : 1308
	db	$36,$0e,$fc,$07,$38,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 473 : 1357
	db	$38,$06,$fc,$07,$38,$07,$44,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 473 : 1392
	db	$fc,$07,$3b,$0e,$fc,$6f,$fc,$6f	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 473 : 1419
	db	$fc,$6e,$fc,$46,$36,$0d,$34,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 476 : 1662
	db	$fc,$07,$33,$07,$fc,$07,$34,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 477 : 1862
	db	$fc,$07,$36,$0e,$fc,$07,$38,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 478 : 1904
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 478 : 1938
	db	$44,$07,$fc,$07,$3b,$0e,$34,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 478 : 1966
	db	$fc,$07,$36,$0d,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 479 : 2015
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 479 : 2049
	db	$44,$07,$fc,$07,$3b,$0e,$34,$14	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 479 : 2077
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 480 : 2125
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 480 : 2160
	db	$44,$07,$fc,$07,$3b,$0d,$34,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 480 : 2188
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 481 : 2236
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 481 : 2271
	db	$44,$07,$fc,$07,$3b,$0e,$44,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 481 : 2298
	db	$fc,$07,$3b,$0e,$fc,$07,$39,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 482 : 2347
	db	$fc,$06,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 482 : 2382
	db	$39,$07,$fc,$07,$3b,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 482 : 2409
	db	$44,$0e,$43,$07,$fc,$07,$39,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 483 : 2437
	db	$fc,$06,$38,$1c,$39,$0e,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 483 : 2472
	db	$fc,$07,$36,$07,$fc,$07,$44,$14	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 483 : 2527
	db	$fc,$07,$3b,$0e,$fc,$07,$39,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 484 : 2568
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 484 : 2603
	db	$39,$07,$fc,$07,$3b,$07,$fc,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 484 : 2631
	db	$38,$0e,$39,$07,$fc,$07,$3b,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 485 : 2658
	db	$fc,$07,$44,$37,$36,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 485 : 2693
	db	$fc,$6f,$fc,$6f,$34,$15,$fc,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 486 : 2769
	db	$36,$0e,$fc,$07,$38,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 488 : 3018
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 488 : 3053
	db	$fc,$07,$3b,$0e,$34,$14,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 488 : 3081
	db	$36,$0e,$fc,$07,$38,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 489 : 3129
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 489 : 3164
	db	$fc,$06,$3b,$0e,$fc,$6f,$fc,$6f	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 489 : 3192
	db	$fc,$6f,$fc,$45,$36,$0e,$34,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 492 : 3434
	db	$fc,$07,$33,$06,$fc,$07,$34,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 493 : 3635
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 494 : 3676
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 494 : 3711
	db	$44,$07,$fc,$07,$3b,$0e,$34,$15	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 494 : 3738
	db	$fc,$07,$36,$0e,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 495 : 3787
	db	$fc,$06,$38,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 495 : 3822
	db	$44,$07,$fc,$07,$3b,$0e,$fd,$1b	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 495 : 3849
	db	$34,$15,$fc,$07,$36,$0d,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 496 : 3877
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 496 : 3925
	db	$38,$07,$44,$07,$fc,$07,$3b,$0e	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 496 : 3953
	db	$34,$14,$fc,$07,$36,$0e,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 497 : 3988
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 497 : 4036
	db	$38,$07,$44,$07,$fc,$07,$3b,$0d	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 497 : 4064
	db	$44,$15,$fc,$07,$3b,$0e,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 498 : 4098
	db	$39,$07,$fc,$07,$38,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 498 : 4147
	db	$38,$07,$39,$06,$fc,$07,$3b,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 498 : 4175
	db	$fc,$07,$fd,$1a,$44,$0e,$43,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 498 : 4202
	db	$fc,$07,$39,$07,$fc,$07,$38,$1b	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 499 : 4230
	db	$39,$0e,$38,$07,$fc,$07,$36,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 499 : 4278
	db	$fc,$07,$44,$15,$fc,$07,$3b,$0e	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 499 : 4313
	db	$fc,$06,$39,$07,$fc,$07,$38,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 500 : 4362
	db	$fc,$07,$38,$07,$39,$07,$fc,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 500 : 4389
	db	$3b,$07,$fc,$07,$38,$0e,$39,$07	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 500 : 4417
	db	$fc,$06,$3b,$07,$fc,$07,$44,$38	;Trk I; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 501 : 4452
	db	$36,$07,$fc,$07
song_000_08_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_08_lp)*2
	dw	song_000_08_lp


song_000_09:	;Trk J
	db	$fc,$6f,$fd,$22,$fe,$0c,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 504 : 0
	db	$fc,$0b,$54,$03,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 505 : 114
	db	$fc,$0a,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 505 : 142
	db	$fc,$0a,$44,$04,$fc,$03,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 505 : 163
	db	$fc,$04,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 505 : 183
	db	$fc,$04,$44,$03,$fc,$04,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 505 : 197
	db	$fc,$04,$5b,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 505 : 211
	db	$fc,$0a,$54,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 506 : 225
	db	$fc,$0a,$54,$04,$fc,$03,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 506 : 253
	db	$fc,$0b,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 506 : 273
	db	$fc,$04,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 506 : 294
	db	$fc,$04,$44,$03,$fc,$03,$4b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 506 : 308
	db	$fc,$03,$5b,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 506 : 322
	db	$fc,$0a,$54,$04,$fc,$0a,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 507 : 336
	db	$fc,$0b,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 507 : 363
	db	$fc,$0b,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 507 : 384
	db	$fc,$03,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 507 : 405
	db	$fc,$03,$44,$04,$fc,$03,$4b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 507 : 419
	db	$fc,$03,$5b,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 507 : 433
	db	$fc,$0a,$54,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 508 : 447
	db	$fc,$0b,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 508 : 474
	db	$fc,$0a,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 508 : 495
	db	$fc,$03,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 508 : 516
	db	$fc,$03,$44,$04,$fc,$03,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 508 : 530
	db	$fc,$04,$5b,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 508 : 543
	db	$fc,$0b,$54,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 509 : 557
	db	$fc,$0a,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 509 : 585
	db	$fc,$0a,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 509 : 606
	db	$fc,$03,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 509 : 627
	db	$fc,$04,$44,$03,$fc,$04,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 509 : 640
	db	$fc,$04,$5b,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 509 : 654
	db	$fc,$0a,$54,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 510 : 668
	db	$fc,$0a,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 510 : 696
	db	$fc,$0a,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 510 : 717
	db	$fc,$04,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 510 : 737
	db	$fc,$04,$44,$03,$fc,$04,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 510 : 751
	db	$fc,$03,$5b,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 510 : 765
	db	$fc,$0a,$54,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 511 : 779
	db	$fc,$0a,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 511 : 807
	db	$fc,$0b,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 511 : 827
	db	$fc,$04,$54,$03,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 511 : 848
	db	$fc,$03,$44,$04,$fc,$03,$4b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 511 : 862
	db	$fc,$03,$5b,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 511 : 876
	db	$fc,$0a,$54,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 512 : 890
	db	$fc,$0b,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 512 : 917
	db	$fc,$0a,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 512 : 938
	db	$fc,$03,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 512 : 959
	db	$fc,$03,$44,$04,$fc,$03,$4b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 512 : 973
	db	$fc,$03,$5b,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 512 : 987
	db	$fc,$0b,$54,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 513 : 1000
	db	$fc,$0a,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 513 : 1028
	db	$fc,$0a,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 513 : 1049
	db	$fc,$03,$54,$04,$fc,$03,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 513 : 1070
	db	$fc,$04,$44,$03,$fc,$04,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 513 : 1083
	db	$fc,$04,$5b,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 513 : 1097
	db	$fc,$0b,$54,$03,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 514 : 1111
	db	$fc,$0a,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 514 : 1139
	db	$fc,$0a,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 514 : 1160
	db	$fc,$04,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 514 : 1180
	db	$fc,$04,$44,$03,$fc,$04,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 514 : 1194
	db	$fc,$04,$5b,$03,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 514 : 1208
	db	$fc,$0a,$54,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 515 : 1222
	db	$fc,$0a,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 515 : 1250
	db	$fc,$0b,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 515 : 1270
	db	$fc,$04,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 515 : 1291
	db	$fc,$03,$44,$04,$fc,$03,$4b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 515 : 1305
	db	$fc,$03,$5b,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 515 : 1319
	db	$fc,$0a,$54,$04,$fc,$0a,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 516 : 1333
	db	$fc,$0b,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 516 : 1360
	db	$fc,$0b,$44,$03,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 516 : 1381
	db	$fc,$03,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 516 : 1402
	db	$fc,$03,$44,$04,$fc,$03,$4b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 516 : 1416
	db	$fc,$03,$5b,$04,$fc,$03,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 516 : 1430
	db	$fc,$0b,$54,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 517 : 1443
	db	$fc,$0b,$54,$03,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 517 : 1471
	db	$fc,$0a,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 517 : 1492
	db	$fc,$03,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 517 : 1513
	db	$fc,$03,$44,$03,$fc,$04,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 517 : 1527
	db	$fc,$04,$5b,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 517 : 1540
	db	$fc,$0b,$54,$03,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 518 : 1554
	db	$fc,$0a,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 518 : 1582
	db	$fc,$0a,$44,$04,$fc,$03,$49,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 518 : 1603
	db	$fc,$0b,$48,$03,$fc,$0b,$46,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 518 : 1623
	db	$fc,$0b,$44,$03,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 518 : 1651
	db	$fc,$0a,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 519 : 1679
	db	$fc,$03,$44,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 519 : 1707
	db	$fc,$04,$44,$03,$fc,$04,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 519 : 1727
	db	$fc,$04,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 519 : 1741
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 519 : 1755
	db	$fc,$03,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 519 : 1769
	db	$fc,$0a,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 520 : 1790
	db	$fc,$04,$44,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 520 : 1817
	db	$fc,$04,$44,$03,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 520 : 1838
	db	$fc,$03,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 520 : 1852
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 520 : 1866
	db	$fc,$03,$44,$04,$fc,$0a,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 520 : 1880
	db	$fc,$0b,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 521 : 1900
	db	$fc,$04,$44,$03,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 521 : 1928
	db	$fc,$03,$44,$04,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 521 : 1949
	db	$fc,$03,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 521 : 1963
	db	$fc,$03,$4b,$03,$fc,$04,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 521 : 1977
	db	$fc,$04,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 521 : 1990
	db	$fc,$0b,$44,$03,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 522 : 2011
	db	$fc,$03,$44,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 522 : 2039
	db	$fc,$03,$44,$04,$fc,$03,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 522 : 2060
	db	$fc,$04,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 522 : 2073
	db	$fc,$04,$4b,$03,$fc,$04,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 522 : 2087
	db	$fc,$04,$44,$03,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 522 : 2101
	db	$fc,$0a,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 523 : 2122
	db	$fc,$03,$44,$04,$fc,$0a,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 523 : 2150
	db	$fc,$04,$44,$03,$fc,$04,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 523 : 2170
	db	$fc,$04,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 523 : 2184
	db	$fc,$04,$4b,$03,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 523 : 2198
	db	$fc,$03,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 523 : 2212
	db	$fc,$0a,$44,$04,$fc,$0a,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 524 : 2233
	db	$fc,$04,$44,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 524 : 2260
	db	$fc,$04,$44,$03,$fc,$04,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 524 : 2281
	db	$fc,$03,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 524 : 2295
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 524 : 2309
	db	$fc,$03,$44,$04,$fc,$0a,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 524 : 2323
	db	$fc,$0b,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 525 : 2343
	db	$fc,$04,$44,$03,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 525 : 2371
	db	$fc,$03,$44,$04,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 525 : 2392
	db	$fc,$03,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 525 : 2406
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 525 : 2420
	db	$fc,$04,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 525 : 2433
	db	$fc,$0b,$44,$03,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 526 : 2454
	db	$fc,$03,$44,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 526 : 2482
	db	$fc,$03,$44,$04,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 526 : 2503
	db	$fc,$03,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 526 : 2517
	db	$fc,$04,$4b,$03,$fc,$04,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 526 : 2530
	db	$fc,$04,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 526 : 2544
	db	$fc,$0a,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 527 : 2565
	db	$fc,$03,$44,$04,$fc,$0a,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 527 : 2593
	db	$fc,$04,$44,$03,$fc,$04,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 527 : 2613
	db	$fc,$04,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 527 : 2627
	db	$fc,$04,$4b,$03,$fc,$04,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 527 : 2641
	db	$fc,$03,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 527 : 2655
	db	$fc,$0a,$44,$04,$fc,$0a,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 528 : 2676
	db	$fc,$04,$44,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 528 : 2703
	db	$fc,$04,$44,$03,$fc,$04,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 528 : 2724
	db	$fc,$04,$44,$03,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 528 : 2738
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 528 : 2752
	db	$fc,$03,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 528 : 2766
	db	$fc,$0a,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 529 : 2787
	db	$fc,$04,$44,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 529 : 2814
	db	$fc,$03,$44,$04,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 529 : 2835
	db	$fc,$03,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 529 : 2849
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 529 : 2863
	db	$fc,$03,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 529 : 2877
	db	$fc,$0b,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 530 : 2897
	db	$fc,$03,$44,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 530 : 2925
	db	$fc,$03,$44,$04,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 530 : 2946
	db	$fc,$03,$44,$04,$fc,$03,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 530 : 2960
	db	$fc,$04,$4b,$03,$fc,$04,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 530 : 2973
	db	$fc,$04,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 530 : 2987
	db	$fc,$0a,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 531 : 3008
	db	$fc,$03,$44,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 531 : 3036
	db	$fc,$03,$44,$03,$fc,$04,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 531 : 3057
	db	$fc,$04,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 531 : 3070
	db	$fc,$04,$4b,$03,$fc,$04,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 531 : 3084
	db	$fc,$04,$44,$03,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 531 : 3098
	db	$fc,$0a,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 532 : 3119
	db	$fc,$03,$44,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 532 : 3147
	db	$fc,$04,$44,$03,$fc,$04,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 532 : 3167
	db	$fc,$04,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 532 : 3181
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 532 : 3195
	db	$fc,$03,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 532 : 3209
	db	$fc,$0a,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 533 : 3230
	db	$fc,$04,$44,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 533 : 3257
	db	$fc,$04,$44,$03,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 533 : 3278
	db	$fc,$03,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 533 : 3292
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 533 : 3306
	db	$fc,$03,$44,$04,$fc,$0a,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 533 : 3320
	db	$fc,$0b,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 534 : 3340
	db	$fc,$04,$44,$03,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 534 : 3368
	db	$fc,$03,$49,$04,$fc,$0a,$48,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 534 : 3389
	db	$fc,$0a,$46,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 534 : 3410
	db	$fc,$0b,$54,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 535 : 3437
	db	$fc,$0a,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 535 : 3465
	db	$fc,$0a,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 535 : 3486
	db	$fc,$03,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 535 : 3507
	db	$fc,$04,$44,$03,$fc,$04,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 535 : 3520
	db	$fc,$04,$5b,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 535 : 3534
	db	$fc,$0a,$54,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 536 : 3548
	db	$fc,$0a,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 536 : 3576
	db	$fc,$0a,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 536 : 3597
	db	$fc,$04,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 536 : 3617
	db	$fc,$04,$44,$03,$fc,$04,$4b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 536 : 3631
	db	$fc,$03,$5b,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 536 : 3645
	db	$fc,$0a,$54,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 537 : 3659
	db	$fc,$0a,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 537 : 3687
	db	$fc,$0b,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 537 : 3707
	db	$fc,$04,$54,$03,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 537 : 3728
	db	$fc,$03,$44,$04,$fc,$03,$4b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 537 : 3742
	db	$fc,$03,$5b,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 537 : 3756
	db	$fc,$0a,$54,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 538 : 3770
	db	$fc,$0b,$54,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 538 : 3797
	db	$fc,$0a,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 538 : 3818
	db	$fc,$03,$54,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 538 : 3839
	db	$fc,$03,$44,$04,$fc,$03,$4b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 538 : 3853
	db	$fc,$03,$5b,$03,$fc,$04,$fd,$21	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 538 : 3867
	db	$44,$03,$fc,$0b,$54,$03,$fc,$0b	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 539 : 3877
	db	$44,$03,$fc,$0a,$54,$04,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 539 : 3905
	db	$44,$04,$fc,$0a,$44,$04,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 539 : 3925
	db	$44,$04,$fc,$03,$54,$04,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 539 : 3946
	db	$44,$03,$fc,$04,$44,$03,$fc,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 539 : 3960
	db	$4b,$03,$fc,$04,$5b,$03,$fc,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 539 : 3974
	db	$44,$03,$fc,$0b,$54,$03,$fc,$0a	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 540 : 3988
	db	$44,$04,$fc,$0a,$54,$04,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 540 : 4015
	db	$44,$04,$fc,$0a,$44,$03,$fc,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 540 : 4036
	db	$44,$03,$fc,$04,$54,$03,$fc,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 540 : 4057
	db	$44,$03,$fc,$04,$44,$03,$fc,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 540 : 4071
	db	$4b,$03,$fc,$04,$5b,$03,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 540 : 4085
	db	$44,$04,$fc,$0a,$54,$04,$fc,$0a	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 541 : 4098
	db	$44,$04,$fc,$0a,$54,$03,$fc,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 541 : 4126
	db	$44,$03,$fc,$0b,$44,$03,$fc,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 541 : 4147
	db	$44,$03,$fc,$04,$54,$03,$fc,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 541 : 4168
	db	$44,$03,$fc,$03,$44,$04,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 541 : 4182
	db	$4b,$04,$fc,$03,$5b,$04,$fc,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 541 : 4195
	db	$fd,$20,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 542 : 4209
	db	$fc,$0a,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 542 : 4227
	db	$fc,$04,$44,$03,$fc,$0b,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 542 : 4254
	db	$fc,$03,$44,$04,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 542 : 4275
	db	$fc,$03,$44,$04,$fc,$03,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 542 : 4289
	db	$fc,$03,$4b,$04,$fc,$03,$5b,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 542 : 4303
	db	$fc,$03,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 542 : 4317
	db	$fc,$0b,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 543 : 4337
	db	$fc,$03,$44,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 543 : 4365
	db	$fc,$03,$44,$04,$fc,$03,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 543 : 4386
	db	$fc,$03,$44,$04,$fc,$03,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 543 : 4400
	db	$fc,$04,$4b,$03,$fc,$04,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 543 : 4413
	db	$fc,$04,$44,$03,$fc,$0b,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 543 : 4427
	db	$fc,$0a,$44,$04,$fc,$0a,$54,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 544 : 4448
	db	$fc,$03,$44,$04,$fc,$0a,$44,$04	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 544 : 4476
	db	$fc,$03,$44,$03,$fc,$04,$54,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 544 : 4497
	db	$fc,$04,$44,$03,$fc,$04,$44,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 544 : 4510
	db	$fc,$04,$4b,$03,$fc,$04,$5b,$03	;Trk J; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 544 : 4524
	db	$fc,$04
song_000_09_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_09_lp)*2
	dw	song_000_09_lp


song_000_10:	;Trk K
	db	$fc,$6f,$fc,$6f,$fc,$5a,$fd,$25	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 547 : 0
	db	$fe,$0a,$36,$06,$38,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 549 : 312
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 550 : 332
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 550 : 360
	db	$fc,$07,$38,$07,$fc,$06,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 550 : 388
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 550 : 415
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 551 : 443
	db	$36,$07,$fc,$07,$36,$07,$38,$06	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 551 : 471
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 551 : 498
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 551 : 526
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 552 : 554
	db	$36,$06,$fc,$07,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 552 : 582
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 552 : 609
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 552 : 637
	db	$34,$07,$fc,$06,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 553 : 665
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 553 : 692
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 553 : 720
	db	$44,$07,$fc,$07,$3b,$06,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 553 : 748
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 554 : 775
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 554 : 803
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 554 : 831
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 554 : 858
	db	$34,$53,$44,$07,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 555 : 886
	db	$fc,$07,$34,$07,$fc,$07,$34,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 555 : 990
	db	$fc,$07,$36,$07,$fc,$06,$36,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 556 : 1018
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 556 : 1045
	db	$38,$07,$44,$07,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 556 : 1073
	db	$fc,$07,$34,$07,$fc,$07,$34,$06	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 556 : 1101
	db	$fc,$07,$36,$07,$fc,$07,$36,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 557 : 1128
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 557 : 1156
	db	$38,$07,$44,$07,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 557 : 1184
	db	$fc,$06,$fc,$6f,$fc,$6f,$fc,$6f	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 557 : 1212
	db	$fc,$6f,$fc,$6e,$fc,$6f,$fc,$6f	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 561 : 1551
	db	$fc,$5a,$36,$07,$38,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 565 : 1994
	db	$34,$07,$fc,$06,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 566 : 2105
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 566 : 2132
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 566 : 2160
	db	$44,$07,$fc,$07,$3b,$06,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 566 : 2188
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 567 : 2215
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 567 : 2243
	db	$fc,$07,$38,$07,$fc,$07,$38,$06	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 567 : 2271
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 567 : 2298
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 568 : 2326
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 568 : 2354
	db	$fc,$06,$38,$07,$fc,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 568 : 2382
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 568 : 2409
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 569 : 2437
	db	$36,$07,$fc,$06,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 569 : 2465
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 569 : 2492
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 569 : 2520
	db	$34,$07,$fc,$07,$34,$06,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 570 : 2548
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 570 : 2575
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 570 : 2603
	db	$44,$07,$fc,$07,$3b,$07,$fc,$06	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 570 : 2631
	db	$34,$54,$44,$06,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 571 : 2658
	db	$fc,$07,$34,$07,$fc,$07,$34,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 571 : 2762
	db	$fc,$07,$36,$07,$fc,$07,$36,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 572 : 2790
	db	$38,$07,$fc,$07,$38,$06,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 572 : 2818
	db	$38,$07,$44,$07,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 572 : 2845
	db	$fc,$07,$34,$07,$fc,$07,$34,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 572 : 2873
	db	$fc,$07,$36,$07,$fc,$07,$36,$06	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 573 : 2901
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 573 : 2928
	db	$38,$07,$44,$07,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 573 : 2956
	db	$fc,$07,$fc,$6f,$fc,$6e,$fc,$6f	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 573 : 2984
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 577 : 3323
	db	$fc,$5a,$36,$07,$38,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 581 : 3766
	db	$fd,$24,$34,$07,$fc,$07,$34,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 582 : 3877
	db	$fc,$07,$36,$07,$fc,$06,$36,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 582 : 3898
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 582 : 3925
	db	$38,$07,$44,$07,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 582 : 3953
	db	$fc,$07,$34,$07,$fc,$07,$34,$06	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 582 : 3981
	db	$fc,$07,$36,$07,$fc,$07,$36,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 583 : 4008
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 583 : 4036
	db	$38,$07,$44,$07,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 583 : 4064
	db	$fc,$06,$34,$07,$fc,$07,$34,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 583 : 4092
	db	$fc,$07,$36,$07,$fc,$07,$36,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 584 : 4119
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 584 : 4147
	db	$38,$07,$44,$06,$fc,$07,$3b,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 584 : 4175
	db	$fc,$07,$fd,$23,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 584 : 4202
	db	$34,$07,$fc,$07,$36,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 585 : 4223
	db	$36,$07,$38,$07,$fc,$07,$38,$06	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 585 : 4251
	db	$fc,$07,$38,$07,$44,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 585 : 4278
	db	$3b,$07,$fc,$07,$34,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 585 : 4306
	db	$34,$07,$fc,$07,$36,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 586 : 4334
	db	$36,$06,$38,$07,$fc,$07,$38,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 586 : 4362
	db	$fc,$07,$38,$07,$44,$07,$fc,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 586 : 4389
	db	$3b,$07,$fc,$07,$34,$53,$44,$07	;Trk K; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 586 : 4417
	db	$fc,$07,$3b,$07,$fc,$07
song_000_10_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_10_lp)*2
	dw	song_000_10_lp


song_000_11:	;Trk L
	db	$fc,$6f,$fc,$6f,$fc,$60,$fd,$25	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 590 : 0
	db	$fe,$0a,$36,$07,$38,$07,$3b,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 592 : 318
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 593 : 339
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 593 : 367
	db	$fc,$07,$38,$06,$fc,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 593 : 395
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 593 : 422
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 594 : 450
	db	$36,$07,$fc,$07,$36,$06,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 594 : 478
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 594 : 505
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 594 : 533
	db	$34,$07,$fc,$07,$34,$07,$fc,$06	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 595 : 561
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 595 : 588
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 595 : 616
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 595 : 644
	db	$34,$06,$fc,$07,$34,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 596 : 672
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 596 : 699
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 596 : 727
	db	$44,$07,$fc,$06,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 596 : 755
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 597 : 782
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 597 : 810
	db	$fc,$07,$38,$07,$fc,$06,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 597 : 838
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 597 : 865
	db	$34,$53,$44,$07,$fc,$07,$3b,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 598 : 893
	db	$fc,$07,$34,$07,$fc,$07,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 599 : 997
	db	$fc,$07,$36,$06,$fc,$07,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 599 : 1025
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 599 : 1052
	db	$38,$07,$44,$07,$fc,$07,$3b,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 599 : 1080
	db	$fc,$07,$34,$07,$fc,$06,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 600 : 1108
	db	$fc,$07,$36,$07,$fc,$07,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 600 : 1135
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 600 : 1163
	db	$38,$07,$44,$07,$fc,$07,$3b,$06	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 600 : 1191
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 601 : 1218
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$61	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 605 : 1662
	db	$36,$07,$38,$07,$3b,$07,$34,$06	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 608 : 2091
	db	$fc,$07,$34,$07,$fc,$07,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 609 : 2118
	db	$fc,$07,$36,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 609 : 2146
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 609 : 2174
	db	$fc,$06,$3b,$07,$fc,$07,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 609 : 2202
	db	$fc,$07,$34,$07,$fc,$07,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 610 : 2229
	db	$fc,$07,$36,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 610 : 2257
	db	$38,$07,$fc,$06,$38,$07,$44,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 610 : 2285
	db	$fc,$07,$3b,$07,$fc,$07,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 610 : 2312
	db	$fc,$07,$34,$07,$fc,$07,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 611 : 2340
	db	$fc,$07,$36,$07,$38,$06,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 611 : 2368
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 611 : 2395
	db	$fc,$07,$3b,$07,$fc,$07,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 611 : 2423
	db	$fc,$07,$34,$07,$fc,$07,$36,$06	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 612 : 2451
	db	$fc,$07,$36,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 612 : 2478
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 612 : 2506
	db	$fc,$07,$3b,$07,$fc,$07,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 612 : 2534
	db	$fc,$06,$34,$07,$fc,$07,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 613 : 2562
	db	$fc,$07,$36,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 613 : 2589
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 613 : 2617
	db	$fc,$07,$3b,$06,$fc,$07,$34,$53	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 613 : 2645
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 614 : 2748
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 615 : 2776
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 615 : 2804
	db	$fc,$06,$38,$07,$fc,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 615 : 2832
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 615 : 2859
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 616 : 2887
	db	$36,$07,$fc,$06,$36,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 616 : 2915
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 616 : 2942
	db	$44,$07,$fc,$07,$3b,$07,$fc,$6f	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 616 : 2970
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 618 : 3102
	db	$fc,$6e,$fc,$6f,$fc,$61,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 622 : 3545
	db	$38,$07,$3b,$07,$fd,$24,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 624 : 3870
	db	$fc,$07,$34,$07,$fc,$07,$36,$06	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 625 : 3891
	db	$fc,$07,$36,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 625 : 3918
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 625 : 3946
	db	$fc,$07,$3b,$07,$fc,$07,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 625 : 3974
	db	$fc,$06,$34,$07,$fc,$07,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 626 : 4002
	db	$fc,$07,$36,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 626 : 4029
	db	$38,$07,$fc,$07,$38,$07,$44,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 626 : 4057
	db	$fc,$07,$3b,$06,$fc,$07,$34,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 626 : 4085
	db	$fc,$07,$34,$07,$fc,$07,$36,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 627 : 4112
	db	$fc,$07,$36,$07,$38,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 627 : 4140
	db	$38,$07,$fc,$07,$38,$06,$44,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 627 : 4168
	db	$fc,$07,$3b,$07,$fc,$07,$fd,$23	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 627 : 4195
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 628 : 4216
	db	$36,$07,$fc,$07,$36,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 628 : 4244
	db	$fc,$06,$38,$07,$fc,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 628 : 4272
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 628 : 4299
	db	$34,$07,$fc,$07,$34,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 629 : 4327
	db	$36,$07,$fc,$06,$36,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 629 : 4355
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 629 : 4382
	db	$44,$07,$fc,$07,$3b,$07,$fc,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 629 : 4410
	db	$34,$53,$44,$07,$fc,$07,$3b,$07	;Trk L; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 630 : 4438

song_000_11_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_11_lp)*2
	dw	song_000_11_lp


song_000_12:	;Trk M
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 633 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 637 : 443
	db	$fc,$6f,$fb,$06,$fd,$0d,$fe,$00	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 641 : 886
	db	$3b,$1c,$39,$14,$3b,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 642 : 997
	db	$3b,$07,$fc,$07,$3b,$07,$41,$0e	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 642 : 1059
	db	$43,$07,$fc,$07,$3b,$1b,$39,$15	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 642 : 1094
	db	$3b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 643 : 1156
	db	$3b,$07,$41,$0e,$43,$07,$fc,$06	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 643 : 1184
	db	$3b,$1c,$39,$15,$3b,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 644 : 1218
	db	$3b,$07,$fc,$07,$3b,$07,$41,$0d	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 644 : 1281
	db	$43,$07,$fc,$07,$3b,$1c,$39,$15	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 644 : 1315
	db	$3b,$07,$fc,$07,$3b,$06,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 645 : 1378
	db	$3b,$07,$41,$0e,$43,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 645 : 1405
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 646 : 1440
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 650 : 1883
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 654 : 2326
	db	$3b,$1c,$39,$15,$3b,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 658 : 2769
	db	$3b,$06,$fc,$07,$3b,$07,$41,$0e	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 658 : 2832
	db	$43,$07,$fc,$07,$3b,$1c,$39,$14	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 658 : 2866
	db	$3b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 659 : 2928
	db	$3b,$07,$41,$0e,$43,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 659 : 2956
	db	$3b,$1b,$39,$15,$3b,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 660 : 2991
	db	$3b,$07,$fc,$07,$3b,$07,$41,$0e	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 660 : 3053
	db	$43,$07,$fc,$07,$3b,$1b,$39,$15	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 660 : 3088
	db	$3b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 661 : 3150
	db	$3b,$07,$41,$0d,$43,$07,$fc,$07	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 661 : 3178
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 662 : 3212
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 666 : 3655
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk M; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 670 : 4098

song_000_12_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_12_lp)*2
	dw	song_000_12_lp


song_000_13:	;Trk N
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 676 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 680 : 443
	db	$fc,$6f,$fb,$06,$fd,$0d,$fe,$00	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 684 : 886
	db	$44,$1c,$36,$14,$38,$07,$fc,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 685 : 997
	db	$38,$07,$fc,$07,$38,$07,$44,$0e	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 685 : 1059
	db	$3b,$07,$fc,$07,$44,$1b,$36,$15	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 685 : 1094
	db	$38,$07,$fc,$07,$38,$07,$fc,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 686 : 1156
	db	$38,$07,$44,$0e,$3b,$07,$fc,$06	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 686 : 1184
	db	$44,$1c,$36,$15,$38,$07,$fc,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 687 : 1218
	db	$38,$07,$fc,$07,$38,$07,$44,$0d	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 687 : 1281
	db	$3b,$07,$fc,$07,$44,$1c,$36,$15	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 687 : 1315
	db	$38,$07,$fc,$07,$38,$06,$fc,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 688 : 1378
	db	$38,$07,$44,$0e,$3b,$07,$fc,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 688 : 1405
	db	$fc,$6f,$fc,$6f,$fc,$6e,$ee
	db	bank(song_000_13_bnk002)*2
	dw	song_000_13_bnk002

	.bank	2
song_000_13_bnk002:
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 692 : 1772
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 696 : 2215
	db	$fc,$6f,$44,$1c,$36,$15,$38,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 700 : 2658
	db	$fc,$07,$38,$06,$fc,$07,$38,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 701 : 2825
	db	$44,$0e,$3b,$07,$fc,$07,$44,$1c	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 701 : 2852
	db	$36,$14,$38,$07,$fc,$07,$38,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 702 : 2908
	db	$fc,$07,$38,$07,$44,$0e,$3b,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 702 : 2949
	db	$fc,$07,$44,$1b,$36,$15,$38,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 702 : 2984
	db	$fc,$07,$38,$07,$fc,$07,$38,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 703 : 3046
	db	$44,$0e,$3b,$07,$fc,$07,$44,$1b	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 703 : 3074
	db	$36,$15,$38,$07,$fc,$07,$38,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 704 : 3129
	db	$fc,$07,$38,$07,$44,$0d,$3b,$07	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 704 : 3171
	db	$fc,$07,$fc,$6f,$fc,$6f,$fc,$6f	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 704 : 3205
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 708 : 3545
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk N; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 712 : 3988
	db	$fc,$6f
song_000_13_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_13_lp)*2
	dw	song_000_13_lp


song_000_14:	;Trk O
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 719 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 723 : 443
	db	$fc,$6f,$fb,$05,$fd,$18,$3b,$1c	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 727 : 886
	db	$39,$14,$3b,$07,$fc,$07,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 728 : 1025
	db	$fc,$07,$3b,$07,$41,$0e,$43,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 728 : 1066
	db	$fc,$07,$3b,$1b,$39,$15,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 728 : 1101
	db	$fc,$07,$3b,$07,$fc,$07,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 729 : 1163
	db	$41,$0e,$43,$07,$fc,$06,$3b,$1c	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 729 : 1191
	db	$39,$15,$3b,$07,$fc,$07,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 730 : 1246
	db	$fc,$07,$3b,$07,$41,$0d,$43,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 730 : 1288
	db	$fc,$07,$3b,$1c,$39,$15,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 730 : 1322
	db	$fc,$07,$3b,$06,$fc,$07,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 731 : 1385
	db	$41,$0e,$43,$07,$fc,$07,$fc,$6f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 731 : 1412
	db	$fc,$6f,$fc,$6e,$fc,$6f,$fc,$6f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 733 : 1551
	db	$fc,$6f,$fc,$6e,$fc,$6f,$fc,$6f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 737 : 1994
	db	$fc,$6f,$fc,$6e,$fc,$6f,$3b,$1c	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 741 : 2437
	db	$39,$15,$3b,$07,$fc,$07,$3b,$06	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 744 : 2797
	db	$fc,$07,$3b,$07,$41,$0e,$43,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 744 : 2838
	db	$fc,$07,$3b,$1c,$39,$14,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 744 : 2873
	db	$fc,$07,$3b,$07,$fc,$07,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 745 : 2935
	db	$41,$0e,$43,$07,$fc,$07,$3b,$1b	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 745 : 2963
	db	$39,$15,$3b,$07,$fc,$07,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 746 : 3018
	db	$fc,$07,$3b,$07,$41,$0e,$43,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 746 : 3060
	db	$fc,$07,$3b,$1b,$39,$15,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 746 : 3095
	db	$fc,$07,$3b,$07,$fc,$07,$3b,$07	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 747 : 3157
	db	$41,$0d,$43,$07,$fc,$07,$fc,$6f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 747 : 3185
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 749 : 3323
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk O; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 753 : 3766
	db	$fc,$6f,$fc,$6f,$fc,$6f
song_000_14_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_14_lp)*2
	dw	song_000_14_lp


song_000_15:	;Trk P
	db	$fc,$53,$fb,$00,$ef,$07,$fd,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 762 : 0
	db	$fe,$00,$2b,$1c,$34,$1b,$29,$15	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 762 : 83
	db	$2b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 763 : 159
	db	$2b,$07,$31,$0e,$33,$0e,$34,$1b	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 763 : 187
	db	$29,$15,$2b,$07,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 764 : 249
	db	$fc,$07,$2b,$07,$31,$0d,$33,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 764 : 291
	db	$34,$1c,$29,$15,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 765 : 332
	db	$3b,$07,$fc,$06,$2b,$07,$31,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 765 : 395
	db	$33,$0e,$34,$1c,$29,$15,$2b,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 765 : 429
	db	$fc,$07,$3b,$07,$fc,$07,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 766 : 498
	db	$31,$0e,$33,$0e,$34,$1c,$29,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 766 : 526
	db	$2b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 767 : 602
	db	$2b,$07,$31,$0e,$33,$0e,$34,$1b	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 767 : 630
	db	$29,$15,$2b,$07,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 768 : 692
	db	$fc,$07,$2b,$07,$31,$0e,$33,$0d	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 768 : 734
	db	$34,$1c,$29,$15,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 769 : 775
	db	$3b,$07,$fc,$07,$2b,$06,$31,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 769 : 838
	db	$33,$0e,$34,$6f,$34,$1c,$29,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 769 : 872
	db	$2b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 771 : 1045
	db	$2b,$07,$31,$0e,$33,$0e,$34,$1b	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 771 : 1073
	db	$29,$15,$2b,$07,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 772 : 1135
	db	$fc,$07,$2b,$07,$31,$0e,$33,$0d	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 772 : 1177
	db	$34,$1c,$29,$15,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 773 : 1218
	db	$3b,$07,$fc,$07,$2b,$07,$31,$0d	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 773 : 1281
	db	$33,$0e,$34,$1c,$29,$15,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 773 : 1315
	db	$fc,$07,$3b,$06,$fc,$07,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 774 : 1385
	db	$31,$0e,$33,$0e,$34,$1c,$29,$14	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 774 : 1412
	db	$2b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 775 : 1488
	db	$2b,$07,$31,$0e,$33,$0e,$34,$1b	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 775 : 1516
	db	$29,$15,$2b,$07,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 776 : 1578
	db	$fc,$07,$2b,$07,$31,$0e,$33,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 776 : 1620
	db	$34,$1b,$29,$15,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 777 : 1662
	db	$3b,$07,$fc,$07,$2b,$07,$31,$0d	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 777 : 1724
	db	$33,$0e,$34,$1c,$29,$15,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 777 : 1758
	db	$fc,$07,$3b,$07,$fc,$06,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 778 : 1828
	db	$31,$0e,$33,$0e,$34,$1c,$29,$15	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 778 : 1855
	db	$2b,$06,$fc,$07,$3b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 779 : 1932
	db	$2b,$07,$31,$0e,$33,$0e,$34,$1c	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 779 : 1959
	db	$29,$14,$2b,$07,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 780 : 2022
	db	$fc,$07,$2b,$07,$31,$0e,$33,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 780 : 2063
	db	$34,$1b,$29,$15,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 781 : 2105
	db	$3b,$07,$fc,$07,$2b,$07,$31,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 781 : 2167
	db	$33,$0d,$34,$1c,$29,$15,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 781 : 2202
	db	$fc,$07,$3b,$07,$fc,$07,$2b,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 782 : 2271
	db	$31,$0e,$33,$0e,$34,$1c,$29,$15	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 782 : 2298
	db	$2b,$07,$fc,$06,$3b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 783 : 2375
	db	$2b,$07,$31,$0e,$33,$0e,$34,$1c	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 783 : 2402
	db	$29,$14,$2b,$07,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 784 : 2465
	db	$fc,$07,$2b,$07,$31,$0e,$33,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 784 : 2506
	db	$34,$1b,$29,$15,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 785 : 2548
	db	$3b,$07,$fc,$07,$2b,$07,$31,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 785 : 2610
	db	$33,$0d,$34,$6f,$34,$1c,$29,$15	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 785 : 2645
	db	$2b,$07,$fc,$07,$3b,$06,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 787 : 2818
	db	$2b,$07,$31,$0e,$33,$0e,$34,$1c	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 787 : 2845
	db	$29,$14,$2b,$07,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 788 : 2908
	db	$fc,$07,$2b,$07,$31,$0e,$33,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 788 : 2949
	db	$34,$1b,$29,$15,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 789 : 2991
	db	$3b,$07,$fc,$07,$2b,$07,$31,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 789 : 3053
	db	$33,$0e,$34,$1b,$29,$15,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 789 : 3088
	db	$fc,$07,$3b,$07,$fc,$07,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 790 : 3157
	db	$31,$0d,$33,$0e,$34,$1c,$29,$15	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 790 : 3185
	db	$2b,$07,$fc,$07,$3b,$07,$fc,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 791 : 3261
	db	$2b,$07,$31,$0e,$33,$0e,$34,$1c	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 791 : 3288
	db	$29,$15,$2b,$06,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 792 : 3351
	db	$fc,$07,$2b,$07,$31,$0e,$33,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 792 : 3392
	db	$34,$1c,$29,$14,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 793 : 3434
	db	$3b,$07,$fc,$07,$2b,$07,$31,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 793 : 3496
	db	$33,$0e,$34,$1b,$29,$15,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 793 : 3531
	db	$fc,$07,$3b,$07,$fc,$07,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 794 : 3600
	db	$31,$0e,$33,$0d,$34,$1c,$29,$15	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 794 : 3628
	db	$2b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 795 : 3704
	db	$2b,$06,$31,$0e,$33,$0e,$fd,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 795 : 3732
	db	$34,$1c,$29,$15,$2b,$07,$fc,$06	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 796 : 3766
	db	$3b,$07,$fc,$07,$2b,$07,$31,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 796 : 3828
	db	$33,$0e,$34,$1c,$29,$14,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 796 : 3863
	db	$fc,$07,$3b,$07,$fc,$07,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 797 : 3932
	db	$31,$0e,$33,$0e,$34,$1b,$29,$15	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 797 : 3960
	db	$2b,$07,$fc,$07,$3b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 798 : 4036
	db	$2b,$07,$31,$0e,$33,$0d,$fd,$05	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 798 : 4064
	db	$34,$1c,$29,$15,$2b,$07,$fc,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 799 : 4098
	db	$3b,$07,$fc,$07,$2b,$07,$31,$0d	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 799 : 4161
	db	$33,$0e,$34,$1c,$29,$15,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 799 : 4195
	db	$fc,$07,$3b,$06,$fc,$07,$2b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 800 : 4265
	db	$31,$0e,$33,$0e,$fd,$04,$34,$1c	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 800 : 4292
	db	$29,$14,$2b,$07,$fc,$07,$3b,$07	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 801 : 4348
	db	$fc,$07,$2b,$07,$31,$0e,$33,$0e	;Trk P; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 801 : 4389
	db	$34,$6f
song_000_15_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_15_lp)*2
	dw	song_000_15_lp


song_000_16:	;Trk Q
	db	$fc,$6f,$fb,$01,$ef,$07,$fd,$0c	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 805 : 0
	db	$fe,$01,$48,$15,$fc,$06,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 806 : 111
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 806 : 152
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 806 : 180
	db	$53,$0e,$48,$14,$fc,$07,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 806 : 208
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 807 : 263
	db	$fc,$07,$4b,$07,$51,$07,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 807 : 291
	db	$53,$0e,$48,$15,$fc,$07,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 807 : 318
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 808 : 374
	db	$fc,$06,$4b,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 808 : 402
	db	$53,$0e,$48,$15,$fc,$07,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 808 : 429
	db	$fc,$07,$4b,$06,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 809 : 485
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 809 : 512
	db	$53,$0e,$4b,$15,$fc,$07,$53,$0d	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 809 : 540
	db	$fc,$07,$51,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 810 : 595
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 810 : 623
	db	$53,$07,$fc,$07,$4b,$14,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 810 : 651
	db	$51,$07,$fc,$07,$4b,$38,$fc,$0d	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 811 : 692
	db	$4b,$15,$fc,$07,$53,$0e,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 812 : 775
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 812 : 824
	db	$4b,$06,$51,$07,$fc,$07,$53,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 812 : 852
	db	$fc,$07,$4b,$0e,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 812 : 879
	db	$53,$07,$fc,$07,$48,$1b,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 813 : 914
	db	$48,$07,$fc,$15,$fc,$6f,$fc,$6e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 813 : 969
	db	$48,$15,$fc,$07,$49,$0e,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 816 : 1218
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 816 : 1267
	db	$4b,$07,$51,$06,$fc,$07,$53,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 816 : 1295
	db	$48,$15,$fc,$07,$49,$0e,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 817 : 1329
	db	$4b,$07,$fc,$07,$4b,$06,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 817 : 1378
	db	$4b,$07,$51,$07,$fc,$07,$53,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 817 : 1405
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$46	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 818 : 1440
	db	$49,$0d,$48,$07,$fc,$07,$46,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 821 : 1842
	db	$fc,$07,$48,$15,$fc,$07,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 821 : 1876
	db	$fc,$07,$4b,$06,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 822 : 1925
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 822 : 1952
	db	$53,$0e,$48,$15,$fc,$07,$49,$0d	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 822 : 1980
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 823 : 2035
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 823 : 2063
	db	$53,$0e,$48,$14,$fc,$07,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 823 : 2091
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 824 : 2146
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 824 : 2174
	db	$53,$0d,$48,$15,$fc,$07,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 824 : 2202
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 825 : 2257
	db	$fc,$07,$4b,$06,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 825 : 2285
	db	$53,$0e,$4b,$15,$fc,$07,$53,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 825 : 2312
	db	$fc,$07,$51,$07,$fc,$06,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 826 : 2368
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 826 : 2395
	db	$53,$07,$fc,$07,$4b,$15,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 826 : 2423
	db	$51,$07,$fc,$06,$4b,$38,$fc,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 827 : 2465
	db	$4b,$14,$fc,$07,$53,$0e,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 828 : 2548
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 828 : 2596
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 828 : 2624
	db	$fc,$06,$4b,$0e,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 828 : 2652
	db	$53,$07,$fc,$07,$48,$1c,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 829 : 2686
	db	$48,$06,$fc,$15,$fc,$6f,$fc,$6f	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 829 : 2742
	db	$48,$15,$fc,$06,$49,$0e,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 832 : 2991
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 832 : 3039
	db	$4b,$07,$51,$07,$fc,$07,$53,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 832 : 3067
	db	$48,$14,$fc,$07,$49,$0e,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 833 : 3102
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 833 : 3150
	db	$4b,$07,$51,$07,$fc,$06,$53,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 833 : 3178
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$45	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 834 : 3212
	db	$49,$0e,$48,$07,$fc,$07,$46,$06	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 837 : 3614
	db	$fc,$07,$48,$15,$fc,$07,$49,$0e	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 837 : 3648
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 838 : 3697
	db	$fc,$07,$4b,$06,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 838 : 3725
	db	$53,$0e,$fd,$0b,$48,$15,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 838 : 3752
	db	$49,$0e,$fc,$07,$4b,$07,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 839 : 3794
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 839 : 3828
	db	$fc,$07,$53,$0e,$48,$15,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 839 : 3856
	db	$49,$0d,$fc,$07,$4b,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 840 : 3905
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 840 : 3939
	db	$fc,$07,$53,$0e,$48,$14,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 840 : 3967
	db	$49,$0e,$fc,$07,$4b,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 841 : 4015
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 841 : 4050
	db	$fc,$07,$53,$0d,$fd,$0a,$4b,$15	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 841 : 4078
	db	$fc,$07,$53,$0e,$fc,$07,$51,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 842 : 4119
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 842 : 4154
	db	$51,$06,$fc,$07,$53,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 842 : 4182
	db	$4b,$15,$fc,$07,$51,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 843 : 4209
	db	$4b,$37,$fc,$0e,$fd,$09,$4b,$15	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 843 : 4251
	db	$fc,$07,$53,$0e,$fc,$06,$51,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 844 : 4341
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 844 : 4375
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 844 : 4403
	db	$4b,$0e,$51,$07,$fc,$06,$53,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 845 : 4431
	db	$fc,$07,$48,$1c,$49,$0e,$48,$07	;Trk Q; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 845 : 4465
	db	$fc,$15
song_000_16_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_16_lp)*2
	dw	song_000_16_lp


song_000_17:	;Trk R
	db	$fc,$6f,$fc,$07,$fb,$01,$ef,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 848 : 0
	db	$fd,$0c,$fe,$02,$48,$14,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 849 : 118
	db	$49,$0e,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 849 : 145
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 849 : 180
	db	$fc,$07,$53,$0d,$48,$15,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 849 : 208
	db	$49,$0e,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 850 : 256
	db	$4b,$07,$fc,$07,$4b,$07,$51,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 850 : 291
	db	$fc,$07,$53,$0e,$48,$15,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 850 : 318
	db	$49,$0e,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 851 : 367
	db	$4b,$06,$fc,$07,$4b,$07,$51,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 851 : 402
	db	$fc,$07,$53,$0e,$48,$15,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 851 : 429
	db	$49,$0e,$fc,$06,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 852 : 478
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 852 : 512
	db	$fc,$07,$53,$0e,$4b,$15,$fc,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 852 : 540
	db	$53,$0e,$fc,$07,$51,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 853 : 588
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 853 : 623
	db	$fc,$07,$53,$07,$fc,$07,$4b,$14	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 853 : 651
	db	$fc,$07,$51,$07,$fc,$07,$4b,$37	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 854 : 692
	db	$fc,$07,$fc,$07,$4b,$15,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 854 : 768
	db	$53,$0e,$fc,$07,$51,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 855 : 810
	db	$4b,$07,$fc,$06,$4b,$07,$51,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 855 : 845
	db	$fc,$07,$53,$07,$fc,$07,$4b,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 855 : 872
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 856 : 907
	db	$48,$1b,$49,$0e,$48,$07,$fc,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 856 : 935
	db	$fc,$6f,$fc,$6e,$fc,$07,$48,$15	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 857 : 997
	db	$fc,$07,$49,$0e,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 859 : 1246
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 859 : 1281
	db	$51,$07,$fc,$07,$53,$0e,$48,$15	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 859 : 1308
	db	$fc,$07,$49,$0e,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 860 : 1357
	db	$fc,$06,$4b,$07,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 860 : 1392
	db	$51,$07,$fc,$07,$53,$0e,$fc,$68	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 860 : 1419
	db	$fc,$6f,$fc,$6e,$fc,$4c,$49,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 862 : 1551
	db	$48,$07,$fc,$07,$46,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 864 : 1862
	db	$48,$15,$fc,$07,$49,$0e,$fc,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 865 : 1890
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 865 : 1938
	db	$4b,$07,$51,$07,$fc,$07,$53,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 865 : 1966
	db	$48,$15,$fc,$06,$49,$0e,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 866 : 2001
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 866 : 2049
	db	$4b,$07,$51,$07,$fc,$07,$53,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 866 : 2077
	db	$48,$14,$fc,$07,$49,$0e,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 867 : 2112
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 867 : 2160
	db	$4b,$07,$51,$07,$fc,$06,$53,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 867 : 2188
	db	$48,$15,$fc,$07,$49,$0e,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 868 : 2222
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 868 : 2271
	db	$4b,$07,$51,$07,$fc,$07,$53,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 868 : 2298
	db	$4b,$15,$fc,$07,$53,$0e,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 869 : 2333
	db	$51,$06,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 869 : 2382
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 869 : 2409
	db	$fc,$07,$4b,$15,$fc,$07,$51,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 870 : 2437
	db	$fc,$07,$4b,$38,$fc,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 870 : 2478
	db	$4b,$14,$fc,$07,$53,$0e,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 871 : 2555
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 871 : 2603
	db	$4b,$07,$51,$07,$fc,$07,$53,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 871 : 2631
	db	$fc,$07,$4b,$0e,$51,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 872 : 2658
	db	$53,$07,$fc,$07,$48,$1c,$49,$0d	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 872 : 2693
	db	$48,$07,$fc,$0e,$fc,$6f,$fc,$6f	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 872 : 2748
	db	$fc,$07,$48,$14,$fc,$07,$49,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 875 : 2991
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 875 : 3039
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 875 : 3067
	db	$53,$0d,$48,$15,$fc,$07,$49,$0e	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 875 : 3095
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 876 : 3150
	db	$fc,$07,$4b,$07,$51,$06,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 876 : 3178
	db	$53,$0e,$fc,$68,$fc,$6f,$fc,$6f	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 876 : 3205
	db	$fc,$4c,$49,$0e,$48,$07,$fc,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 880 : 3545
	db	$46,$07,$fc,$07,$48,$15,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 880 : 3648
	db	$49,$0e,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 881 : 3690
	db	$4b,$07,$fc,$06,$4b,$07,$51,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 881 : 3725
	db	$fc,$07,$53,$0e,$fd,$0b,$48,$15	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 881 : 3752
	db	$fc,$07,$49,$0e,$fc,$07,$4b,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 882 : 3794
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 882 : 3828
	db	$51,$07,$fc,$07,$53,$0e,$48,$15	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 882 : 3856
	db	$fc,$07,$49,$0d,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 883 : 3905
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 883 : 3939
	db	$51,$07,$fc,$07,$53,$0e,$48,$14	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 883 : 3967
	db	$fc,$07,$49,$0e,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 884 : 4015
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 884 : 4050
	db	$51,$07,$fc,$07,$53,$0d,$fd,$0a	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 884 : 4078
	db	$4b,$15,$fc,$07,$53,$0e,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 885 : 4105
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 885 : 4154
	db	$4b,$06,$51,$07,$fc,$07,$53,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 885 : 4182
	db	$fc,$07,$4b,$15,$fc,$07,$51,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 886 : 4209
	db	$fc,$07,$4b,$37,$fc,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 886 : 4251
	db	$fd,$09,$4b,$15,$fc,$07,$53,$0d	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 887 : 4327
	db	$fc,$07,$51,$07,$fc,$07,$4b,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 887 : 4368
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 887 : 4396
	db	$53,$07,$fc,$07,$4b,$0e,$51,$06	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 887 : 4424
	db	$fc,$07,$53,$07,$fc,$07,$48,$1c	;Trk R; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 888 : 4458
	db	$49,$0e,$48,$07,$fc,$0e
song_000_17_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_17_lp)*2
	dw	song_000_17_lp


song_000_18:	;Trk S
	db	$fc,$6f,$fb,$02,$ef,$07,$fd,$03	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 891 : 0
	db	$fe,$03,$48,$15,$fc,$06,$49,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 892 : 111
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 892 : 152
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 892 : 180
	db	$53,$0e,$48,$14,$fc,$07,$49,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 892 : 208
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 893 : 263
	db	$fc,$07,$4b,$07,$51,$07,$fc,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 893 : 291
	db	$53,$0e,$48,$15,$fc,$07,$49,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 893 : 318
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 894 : 374
	db	$fc,$06,$4b,$07,$51,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 894 : 402
	db	$53,$0e,$48,$15,$fc,$07,$49,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 894 : 429
	db	$fc,$07,$4b,$06,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 895 : 485
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 895 : 512
	db	$53,$0e,$4b,$15,$fc,$07,$53,$0d	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 895 : 540
	db	$fc,$07,$51,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 896 : 595
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 896 : 623
	db	$53,$07,$fc,$07,$4b,$14,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 896 : 651
	db	$51,$07,$fc,$07,$4b,$38,$fc,$0d	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 897 : 692
	db	$4b,$15,$fc,$07,$53,$0e,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 898 : 775
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 898 : 824
	db	$4b,$06,$51,$07,$fc,$07,$53,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 898 : 852
	db	$fc,$07,$4b,$0e,$51,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 898 : 879
	db	$53,$07,$fc,$07,$48,$1b,$49,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 899 : 914
	db	$48,$07,$fc,$15,$fc,$6f,$fc,$6e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 899 : 969
	db	$48,$15,$fc,$07,$49,$0e,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 902 : 1218
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 902 : 1267
	db	$4b,$07,$51,$06,$fc,$07,$53,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 902 : 1295
	db	$48,$15,$fc,$07,$49,$0e,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 903 : 1329
	db	$4b,$07,$fc,$07,$4b,$06,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 903 : 1378
	db	$4b,$07,$51,$07,$ee
	db	bank(song_000_18_bnk003)*2
	dw	song_000_18_bnk003

	.bank	3
	.org	$e000
song_000_18_bnk003:
	db	$fc,$07,$53,$0e,$fc,$6f,$fc,$6f	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 903 : 1419
	db	$fc,$6e,$fc,$46,$49,$0d,$48,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 906 : 1662
	db	$fc,$07,$46,$07,$fc,$07,$48,$15	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 907 : 1862
	db	$fc,$07,$49,$0e,$fc,$07,$4b,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 908 : 1904
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 908 : 1938
	db	$51,$07,$fc,$07,$53,$0e,$48,$15	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 908 : 1966
	db	$fc,$07,$49,$0d,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 909 : 2015
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 909 : 2049
	db	$51,$07,$fc,$07,$53,$0e,$48,$14	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 909 : 2077
	db	$fc,$07,$49,$0e,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 910 : 2125
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 910 : 2160
	db	$51,$07,$fc,$07,$53,$0d,$48,$15	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 910 : 2188
	db	$fc,$07,$49,$0e,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 911 : 2236
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 911 : 2271
	db	$51,$07,$fc,$07,$53,$0e,$4b,$15	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 911 : 2298
	db	$fc,$07,$53,$0e,$fc,$07,$51,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 912 : 2347
	db	$fc,$06,$4b,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 912 : 2382
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 912 : 2409
	db	$4b,$15,$fc,$07,$51,$07,$fc,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 913 : 2437
	db	$4b,$38,$fc,$0e,$4b,$14,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 913 : 2478
	db	$53,$0e,$fc,$07,$51,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 914 : 2575
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 914 : 2610
	db	$fc,$07,$53,$07,$fc,$06,$4b,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 914 : 2638
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 915 : 2672
	db	$48,$1c,$49,$0e,$48,$06,$fc,$15	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 915 : 2700
	db	$fc,$6f,$fc,$6f,$48,$15,$fc,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 916 : 2769
	db	$49,$0e,$fc,$07,$4b,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 918 : 3018
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 918 : 3053
	db	$fc,$07,$53,$0e,$48,$14,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 918 : 3081
	db	$49,$0e,$fc,$07,$4b,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 919 : 3129
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 919 : 3164
	db	$fc,$06,$53,$0e,$fc,$6f,$fc,$6f	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 919 : 3192
	db	$fc,$6f,$fc,$45,$49,$0e,$48,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 922 : 3434
	db	$fc,$07,$46,$06,$fc,$07,$48,$15	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 923 : 3635
	db	$fc,$07,$49,$0e,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 924 : 3676
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$06	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 924 : 3711
	db	$51,$07,$fc,$07,$53,$0e,$fd,$02	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 924 : 3738
	db	$48,$15,$fc,$07,$49,$0e,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 925 : 3766
	db	$4b,$07,$fc,$06,$4b,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 925 : 3815
	db	$4b,$07,$51,$07,$fc,$07,$53,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 925 : 3842
	db	$48,$15,$fc,$07,$49,$0d,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 926 : 3877
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 926 : 3925
	db	$4b,$07,$51,$07,$fc,$07,$53,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 926 : 3953
	db	$48,$14,$fc,$07,$49,$0e,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 927 : 3988
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 927 : 4036
	db	$4b,$07,$51,$07,$fc,$07,$53,$0d	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 927 : 4064
	db	$fd,$01,$4b,$15,$fc,$07,$53,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 928 : 4098
	db	$fc,$07,$51,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 928 : 4140
	db	$fc,$07,$4b,$07,$51,$06,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 928 : 4168
	db	$53,$07,$fc,$07,$4b,$15,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 928 : 4195
	db	$51,$07,$fc,$07,$4b,$37,$fc,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 929 : 4237
	db	$fd,$00,$4b,$15,$fc,$07,$53,$0e	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 930 : 4320
	db	$fc,$06,$51,$07,$fc,$07,$4b,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 930 : 4362
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 930 : 4389
	db	$53,$07,$fc,$07,$4b,$0e,$51,$07	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 930 : 4417
	db	$fc,$06,$53,$07,$fc,$07,$48,$1c	;Trk S; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 931 : 4452
	db	$49,$0e,$48,$07,$fc,$15
song_000_18_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_18_lp)*2
	dw	song_000_18_lp


song_000_19:	;Trk T
	db	$fc,$6f,$fc,$07,$fb,$03,$ef,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 934 : 0
	db	$fd,$13,$fe,$04,$54,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 935 : 118
	db	$64,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 935 : 132
	db	$64,$04,$fc,$0a,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 935 : 152
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 935 : 180
	db	$54,$03,$fc,$04,$5b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 935 : 201
	db	$6b,$03,$fc,$04,$fc,$06,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 935 : 215
	db	$fc,$0a,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 936 : 232
	db	$fc,$03,$64,$04,$fc,$0a,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 936 : 260
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 936 : 280
	db	$fc,$0b,$54,$03,$fc,$03,$5b,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 936 : 301
	db	$fc,$03,$6b,$04,$fc,$03,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 936 : 322
	db	$54,$04,$fc,$0a,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 937 : 339
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 937 : 367
	db	$54,$03,$fc,$0b,$54,$03,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 937 : 388
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 937 : 408
	db	$5b,$04,$fc,$03,$6b,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 937 : 429
	db	$fc,$07,$54,$03,$fc,$0b,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 938 : 443
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 938 : 467
	db	$fc,$0a,$54,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 938 : 488
	db	$fc,$03,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 938 : 516
	db	$fc,$03,$5b,$03,$fc,$04,$6b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 938 : 537
	db	$fc,$04,$fc,$07,$54,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 938 : 550
	db	$64,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 939 : 575
	db	$64,$04,$fc,$0a,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 939 : 595
	db	$54,$04,$fc,$03,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 939 : 623
	db	$54,$03,$fc,$04,$5b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 939 : 644
	db	$6b,$03,$fc,$04,$fc,$07,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 939 : 658
	db	$fc,$0a,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 940 : 675
	db	$fc,$03,$64,$04,$fc,$0a,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 940 : 703
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 940 : 723
	db	$fc,$0b,$54,$03,$fc,$04,$5b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 940 : 744
	db	$fc,$03,$6b,$04,$fc,$03,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 940 : 765
	db	$54,$04,$fc,$0a,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 941 : 782
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 941 : 810
	db	$54,$03,$fc,$0b,$54,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 941 : 831
	db	$64,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 941 : 852
	db	$5b,$04,$fc,$03,$6b,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 941 : 872
	db	$fc,$07,$54,$04,$fc,$0a,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 942 : 886
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 942 : 910
	db	$fc,$0b,$54,$03,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 942 : 931
	db	$fc,$03,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 942 : 959
	db	$fc,$03,$5b,$04,$fc,$03,$6b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 942 : 980
	db	$fc,$04,$fc,$07,$54,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 942 : 993
	db	$64,$03,$fc,$0b,$54,$03,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 943 : 1018
	db	$64,$04,$fc,$0a,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 943 : 1038
	db	$54,$04,$fc,$03,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 943 : 1066
	db	$54,$03,$fc,$04,$5b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 943 : 1087
	db	$6b,$03,$fc,$04,$fc,$07,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 943 : 1101
	db	$fc,$0a,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 944 : 1118
	db	$fc,$03,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 944 : 1146
	db	$fc,$0a,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 944 : 1167
	db	$fc,$0b,$54,$03,$fc,$04,$5b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 944 : 1187
	db	$fc,$04,$6b,$03,$fc,$03,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 944 : 1208
	db	$54,$04,$fc,$0a,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 945 : 1225
	db	$54,$04,$fc,$03,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 945 : 1253
	db	$54,$03,$fc,$0b,$54,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 945 : 1274
	db	$64,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 945 : 1295
	db	$5b,$04,$fc,$03,$6b,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 945 : 1315
	db	$fc,$07,$54,$04,$fc,$0a,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 946 : 1329
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 946 : 1353
	db	$fc,$0b,$54,$03,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 946 : 1374
	db	$fc,$03,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 946 : 1402
	db	$fc,$03,$5b,$04,$fc,$03,$6b,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 946 : 1423
	db	$fc,$03,$fc,$07,$54,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 946 : 1437
	db	$64,$03,$fc,$0b,$54,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 947 : 1461
	db	$64,$03,$fc,$0a,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 947 : 1482
	db	$54,$04,$fc,$03,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 947 : 1509
	db	$54,$03,$fc,$04,$5b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 947 : 1530
	db	$6b,$03,$fc,$04,$fc,$07,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 947 : 1544
	db	$fc,$0b,$64,$03,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 948 : 1561
	db	$fc,$03,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 948 : 1589
	db	$fc,$0a,$54,$03,$fc,$04,$69,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 948 : 1610
	db	$fc,$0b,$68,$03,$fc,$0b,$66,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 948 : 1630
	db	$fc,$04,$fc,$06,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 948 : 1658
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 949 : 1682
	db	$64,$04,$fc,$0a,$54,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 949 : 1703
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 949 : 1731
	db	$54,$03,$fc,$03,$5b,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 949 : 1752
	db	$6b,$04,$fc,$03,$fc,$07,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 949 : 1765
	db	$fc,$0a,$64,$04,$fc,$0a,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 950 : 1783
	db	$fc,$04,$64,$03,$fc,$0b,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 950 : 1810
	db	$fc,$0b,$54,$03,$fc,$03,$64,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 950 : 1831
	db	$fc,$0a,$54,$04,$fc,$03,$5b,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 950 : 1852
	db	$fc,$03,$6b,$04,$fc,$03,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 950 : 1873
	db	$54,$03,$fc,$0b,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 951 : 1890
	db	$54,$03,$fc,$04,$64,$03,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 951 : 1918
	db	$54,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 951 : 1938
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 951 : 1959
	db	$5b,$03,$fc,$04,$6b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 951 : 1980
	db	$fc,$07,$54,$03,$fc,$0b,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 952 : 1994
	db	$fc,$0a,$54,$04,$fc,$03,$64,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 952 : 2018
	db	$fc,$0a,$54,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 952 : 2039
	db	$fc,$03,$64,$03,$fc,$0b,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 952 : 2067
	db	$fc,$04,$5b,$03,$fc,$04,$6b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 952 : 2087
	db	$fc,$04,$fc,$07,$54,$03,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 952 : 2101
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 953 : 2125
	db	$64,$04,$fc,$0a,$54,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 953 : 2146
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 953 : 2174
	db	$54,$03,$fc,$04,$5b,$03,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 953 : 2195
	db	$6b,$04,$fc,$03,$fc,$07,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 953 : 2208
	db	$fc,$0a,$64,$04,$fc,$0a,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 954 : 2226
	db	$fc,$04,$64,$03,$fc,$0b,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 954 : 2253
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 954 : 2274
	db	$fc,$0a,$54,$04,$fc,$03,$5b,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 954 : 2295
	db	$fc,$03,$6b,$04,$fc,$03,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 954 : 2316
	db	$54,$04,$fc,$0a,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 955 : 2333
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 955 : 2361
	db	$54,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 955 : 2382
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 955 : 2402
	db	$5b,$04,$fc,$03,$6b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 955 : 2423
	db	$fc,$07,$54,$03,$fc,$0b,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 956 : 2437
	db	$fc,$0b,$54,$03,$fc,$03,$64,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 956 : 2461
	db	$fc,$0a,$54,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 956 : 2482
	db	$fc,$03,$64,$04,$fc,$0a,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 956 : 2510
	db	$fc,$04,$5b,$03,$fc,$04,$6b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 956 : 2530
	db	$fc,$04,$fc,$07,$54,$03,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 956 : 2544
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 957 : 2568
	db	$64,$04,$fc,$0a,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 957 : 2589
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 957 : 2617
	db	$54,$03,$fc,$04,$5b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 957 : 2638
	db	$6b,$03,$fc,$03,$fc,$07,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 957 : 2652
	db	$fc,$0a,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 958 : 2669
	db	$fc,$03,$64,$03,$fc,$0b,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 958 : 2697
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 958 : 2717
	db	$fc,$0a,$54,$04,$fc,$03,$5b,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 958 : 2738
	db	$fc,$03,$6b,$04,$fc,$03,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 958 : 2759
	db	$54,$04,$fc,$0a,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 959 : 2776
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 959 : 2804
	db	$54,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 959 : 2825
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 959 : 2845
	db	$5b,$04,$fc,$03,$6b,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 959 : 2866
	db	$fc,$07,$54,$03,$fc,$0b,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 960 : 2880
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 960 : 2904
	db	$fc,$0a,$54,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 960 : 2925
	db	$fc,$03,$64,$04,$fc,$0a,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 960 : 2953
	db	$fc,$04,$5b,$03,$fc,$04,$6b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 960 : 2973
	db	$fc,$04,$fc,$07,$54,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 960 : 2987
	db	$64,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 961 : 3012
	db	$64,$04,$fc,$0a,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 961 : 3032
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 961 : 3060
	db	$54,$03,$fc,$04,$5b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 961 : 3081
	db	$6b,$03,$fc,$04,$fc,$06,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 961 : 3095
	db	$fc,$0a,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 962 : 3112
	db	$fc,$03,$64,$04,$fc,$0a,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 962 : 3140
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 962 : 3160
	db	$fc,$0b,$54,$03,$fc,$03,$5b,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 962 : 3181
	db	$fc,$03,$6b,$04,$fc,$03,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 962 : 3202
	db	$54,$04,$fc,$0a,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 963 : 3219
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 963 : 3247
	db	$54,$03,$fc,$0b,$54,$03,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 963 : 3268
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 963 : 3288
	db	$5b,$04,$fc,$03,$6b,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 963 : 3309
	db	$fc,$07,$54,$03,$fc,$0b,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 964 : 3323
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 964 : 3347
	db	$fc,$0a,$54,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 964 : 3368
	db	$fc,$03,$69,$04,$fc,$0a,$68,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 964 : 3396
	db	$fc,$0a,$66,$03,$fc,$04,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 964 : 3417
	db	$54,$03,$fc,$0b,$64,$03,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 965 : 3441
	db	$54,$04,$fc,$03,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 965 : 3468
	db	$54,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 965 : 3489
	db	$64,$03,$fc,$0b,$54,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 965 : 3510
	db	$5b,$03,$fc,$04,$6b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 965 : 3531
	db	$fc,$07,$54,$03,$fc,$0a,$64,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 966 : 3545
	db	$fc,$0a,$54,$04,$fc,$03,$64,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 966 : 3569
	db	$fc,$0a,$54,$03,$fc,$0b,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 966 : 3590
	db	$fc,$04,$64,$03,$fc,$0b,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 966 : 3617
	db	$fc,$04,$5b,$03,$fc,$03,$6b,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 966 : 3638
	db	$fc,$03,$fc,$07,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 966 : 3652
	db	$64,$04,$fc,$0a,$54,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 967 : 3676
	db	$64,$03,$fc,$0b,$54,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 967 : 3697
	db	$54,$03,$fc,$04,$64,$03,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 967 : 3725
	db	$54,$04,$fc,$03,$5b,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 967 : 3745
	db	$6b,$04,$fc,$03,$fc,$07,$fd,$12	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 967 : 3759
	db	$54,$04,$fc,$0a,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 968 : 3773
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 968 : 3801
	db	$54,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 968 : 3822
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 968 : 3842
	db	$5b,$04,$fc,$03,$6b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 968 : 3863
	db	$fc,$07,$54,$03,$fc,$0b,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 969 : 3877
	db	$fc,$0b,$54,$03,$fc,$03,$64,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 969 : 3901
	db	$fc,$0a,$54,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 969 : 3922
	db	$fc,$03,$64,$04,$fc,$0a,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 969 : 3950
	db	$fc,$04,$5b,$03,$fc,$04,$6b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 969 : 3970
	db	$fc,$04,$fc,$07,$54,$03,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 969 : 3984
	db	$64,$04,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 970 : 4008
	db	$64,$04,$fc,$0a,$54,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 970 : 4029
	db	$54,$03,$fc,$04,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 970 : 4057
	db	$54,$03,$fc,$04,$5b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 970 : 4078
	db	$6b,$03,$fc,$03,$fc,$07,$fd,$11	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 970 : 4092
	db	$54,$04,$fc,$0a,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 971 : 4105
	db	$54,$04,$fc,$03,$64,$03,$fc,$0b	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 971 : 4133
	db	$54,$03,$fc,$0b,$54,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 971 : 4154
	db	$64,$03,$fc,$0a,$54,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 971 : 4175
	db	$5b,$04,$fc,$03,$6b,$04,$fc,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 971 : 4195
	db	$fc,$07,$54,$04,$fc,$0a,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 972 : 4209
	db	$fc,$0b,$54,$03,$fc,$04,$64,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 972 : 4233
	db	$fc,$0b,$54,$03,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 972 : 4254
	db	$fc,$03,$64,$04,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 972 : 4282
	db	$fc,$03,$5b,$04,$fc,$03,$6b,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 972 : 4303
	db	$fc,$03,$fc,$07,$fd,$10,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 972 : 4317
	db	$fc,$0b,$64,$03,$fc,$0b,$54,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 973 : 4330
	db	$fc,$04,$64,$03,$fc,$0a,$54,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 973 : 4358
	db	$fc,$0a,$54,$04,$fc,$03,$64,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 973 : 4379
	db	$fc,$0a,$54,$03,$fc,$04,$5b,$03	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 973 : 4400
	db	$fc,$04,$6b,$03,$fc,$04,$fc,$07	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 973 : 4420
	db	$54,$03,$fc,$0b,$64,$03,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 974 : 4438
	db	$54,$04,$fc,$03,$64,$04,$fc,$0a	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 974 : 4465
	db	$54,$04,$fc,$0a,$54,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 974 : 4486
	db	$64,$03,$fc,$0b,$54,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 974 : 4507
	db	$5b,$03,$fc,$04,$6b,$03,$fc,$04	;Trk T; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 974 : 4528

song_000_19_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_19_lp)*2
	dw	song_000_19_lp


song_000_20:	;Trk U
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fb,$04	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 977 : 0
	db	$ef,$07,$fd,$17,$fe,$05,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 980 : 332
	db	$fc,$07,$48,$07,$fc,$07,$49,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 980 : 339
	db	$fc,$07,$49,$07,$4b,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 980 : 367
	db	$4b,$07,$fc,$06,$4b,$07,$51,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 980 : 395
	db	$fc,$07,$53,$07,$fc,$07,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 980 : 422
	db	$fc,$07,$48,$07,$fc,$07,$49,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 981 : 450
	db	$fc,$07,$49,$07,$4b,$06,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 981 : 478
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 981 : 505
	db	$fc,$07,$53,$07,$fc,$07,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 981 : 533
	db	$fc,$07,$48,$07,$fc,$07,$49,$06	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 982 : 561
	db	$fc,$07,$49,$07,$4b,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 982 : 588
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 982 : 616
	db	$fc,$07,$53,$07,$fc,$07,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 982 : 644
	db	$fc,$06,$48,$07,$fc,$07,$49,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 983 : 672
	db	$fc,$07,$49,$07,$4b,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 983 : 699
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 983 : 727
	db	$fc,$07,$53,$06,$fc,$07,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 983 : 755
	db	$fc,$07,$48,$07,$fc,$07,$49,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 984 : 782
	db	$fc,$07,$49,$07,$4b,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 984 : 810
	db	$4b,$07,$fc,$07,$4b,$06,$51,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 984 : 838
	db	$fc,$07,$53,$07,$fc,$07,$48,$53	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 984 : 865
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 985 : 969
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 986 : 997
	db	$49,$07,$fc,$06,$49,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 986 : 1025
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 986 : 1052
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 986 : 1080
	db	$48,$07,$fc,$07,$48,$06,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 987 : 1108
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 987 : 1135
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 987 : 1163
	db	$51,$07,$fc,$07,$53,$07,$fc,$06	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 987 : 1191
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 988 : 1218
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 992 : 1662
	db	$48,$07,$fc,$06,$48,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 996 : 2105
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 996 : 2132
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 996 : 2160
	db	$51,$07,$fc,$07,$53,$06,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 996 : 2188
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 997 : 2215
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 997 : 2243
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$06	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 997 : 2271
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 997 : 2298
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 998 : 2326
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 998 : 2354
	db	$fc,$06,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 998 : 2382
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 998 : 2409
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 999 : 2437
	db	$49,$07,$fc,$06,$49,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 999 : 2465
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 999 : 2492
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 999 : 2520
	db	$48,$07,$fc,$07,$48,$06,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1000 : 2548
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1000 : 2575
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1000 : 2603
	db	$51,$07,$fc,$07,$53,$07,$fc,$06	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1000 : 2631
	db	$48,$54,$51,$06,$fc,$07,$53,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1001 : 2658
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1001 : 2762
	db	$fc,$07,$49,$07,$fc,$07,$49,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1002 : 2790
	db	$4b,$07,$fc,$07,$4b,$06,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1002 : 2818
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1002 : 2845
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1002 : 2873
	db	$fc,$07,$49,$07,$fc,$07,$49,$06	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1003 : 2901
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1003 : 2928
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1003 : 2956
	db	$fc,$07,$fc,$6f,$fc,$6e,$fc,$6f	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1003 : 2984
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1007 : 3323
	db	$fc,$6f,$fd,$16,$48,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1011 : 3766
	db	$48,$07,$fc,$07,$49,$07,$fc,$06	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1012 : 3891
	db	$49,$07,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1012 : 3918
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1012 : 3946
	db	$53,$07,$fc,$07,$48,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1012 : 3974
	db	$48,$06,$fc,$07,$49,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1013 : 4002
	db	$49,$07,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1013 : 4029
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1013 : 4057
	db	$53,$07,$fc,$06,$fd,$15,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1013 : 4085
	db	$fc,$07,$48,$07,$fc,$07,$49,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1014 : 4105
	db	$fc,$07,$49,$07,$4b,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1014 : 4133
	db	$4b,$07,$fc,$07,$4b,$07,$51,$06	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1014 : 4161
	db	$fc,$07,$53,$07,$fc,$07,$48,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1014 : 4188
	db	$fc,$07,$48,$07,$fc,$07,$49,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1015 : 4216
	db	$fc,$07,$49,$07,$4b,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1015 : 4244
	db	$4b,$06,$fc,$07,$4b,$07,$51,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1015 : 4272
	db	$fc,$07,$53,$07,$fc,$07,$fd,$14	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1015 : 4299
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1016 : 4320
	db	$49,$07,$fc,$07,$49,$06,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1016 : 4348
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1016 : 4375
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1016 : 4403
	db	$48,$53,$51,$07,$fc,$07,$53,$07	;Trk U; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1017 : 4431
	db	$fc,$07
song_000_20_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_20_lp)*2
	dw	song_000_20_lp


song_000_21:	;Trk V
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1020 : 0
	db	$fb,$04,$ef,$07,$fd,$17,$fe,$06	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1023 : 339
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1023 : 339
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1023 : 367
	db	$fc,$07,$4b,$06,$fc,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1023 : 395
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1023 : 422
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1024 : 450
	db	$49,$07,$fc,$07,$49,$06,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1024 : 478
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1024 : 505
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1024 : 533
	db	$48,$07,$fc,$07,$48,$07,$fc,$06	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1025 : 561
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1025 : 588
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1025 : 616
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1025 : 644
	db	$48,$06,$fc,$07,$48,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1026 : 672
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1026 : 699
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1026 : 727
	db	$51,$07,$fc,$06,$53,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1026 : 755
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1027 : 782
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1027 : 810
	db	$fc,$07,$4b,$07,$fc,$06,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1027 : 838
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1027 : 865
	db	$48,$53,$51,$07,$fc,$07,$53,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1028 : 893
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1029 : 997
	db	$fc,$07,$49,$06,$fc,$07,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1029 : 1025
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1029 : 1052
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1029 : 1080
	db	$fc,$07,$48,$07,$fc,$06,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1030 : 1108
	db	$fc,$07,$49,$07,$fc,$07,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1030 : 1135
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1030 : 1163
	db	$4b,$07,$51,$07,$fc,$07,$53,$06	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1030 : 1191
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1031 : 1218
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1035 : 1662
	db	$fc,$07,$48,$06,$fc,$07,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1039 : 2105
	db	$fc,$07,$49,$07,$fc,$07,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1039 : 2132
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1039 : 2160
	db	$4b,$07,$51,$07,$fc,$06,$53,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1039 : 2188
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1040 : 2215
	db	$fc,$07,$49,$07,$fc,$07,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1040 : 2243
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$06	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1040 : 2271
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1040 : 2298
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1041 : 2326
	db	$fc,$07,$49,$07,$fc,$07,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1041 : 2354
	db	$4b,$06,$fc,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1041 : 2382
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1041 : 2409
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1042 : 2437
	db	$fc,$07,$49,$06,$fc,$07,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1042 : 2465
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1042 : 2492
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1042 : 2520
	db	$fc,$07,$48,$07,$fc,$06,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1043 : 2548
	db	$fc,$07,$49,$07,$fc,$07,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1043 : 2575
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1043 : 2603
	db	$4b,$07,$51,$07,$fc,$07,$53,$06	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1043 : 2631
	db	$fc,$07,$48,$53,$51,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1044 : 2658
	db	$53,$07,$fc,$07,$48,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1044 : 2762
	db	$48,$07,$fc,$07,$49,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1045 : 2790
	db	$49,$07,$4b,$07,$fc,$06,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1045 : 2818
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1045 : 2845
	db	$53,$07,$fc,$07,$48,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1045 : 2873
	db	$48,$07,$fc,$07,$49,$07,$fc,$06	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1046 : 2901
	db	$49,$07,$4b,$07,$fc,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1046 : 2928
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1046 : 2956
	db	$53,$07,$fc,$6f,$fc,$6e,$fc,$6f	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1046 : 2984
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1050 : 3323
	db	$fc,$6f,$fc,$07,$fd,$16,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1054 : 3766
	db	$fc,$07,$48,$07,$fc,$07,$49,$06	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1055 : 3891
	db	$fc,$07,$49,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1055 : 3918
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1055 : 3946
	db	$fc,$07,$53,$07,$fc,$07,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1055 : 3974
	db	$fc,$06,$48,$07,$fc,$07,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1056 : 4002
	db	$fc,$07,$49,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1056 : 4029
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1056 : 4057
	db	$fc,$07,$53,$06,$fc,$07,$fd,$15	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1056 : 4085
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1057 : 4105
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1057 : 4133
	db	$fc,$07,$4b,$07,$fc,$07,$4b,$06	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1057 : 4161
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1057 : 4188
	db	$48,$07,$fc,$07,$48,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1058 : 4216
	db	$49,$07,$fc,$07,$49,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1058 : 4244
	db	$fc,$06,$4b,$07,$fc,$07,$4b,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1058 : 4272
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1058 : 4299
	db	$fd,$14,$48,$07,$fc,$07,$48,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1059 : 4327
	db	$fc,$07,$49,$07,$fc,$06,$49,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1059 : 4348
	db	$4b,$07,$fc,$07,$4b,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1059 : 4375
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1059 : 4403
	db	$fc,$07,$48,$53,$51,$07,$fc,$07	;Trk V; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1060 : 4431
	db	$53,$07
song_000_21_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_21_lp)*2
	dw	song_000_21_lp


song_000_22:	;Trk W
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1063 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1067 : 443
	db	$fc,$6f,$fb,$05,$ef,$07,$fd,$08	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1071 : 886
	db	$fe,$07,$54,$1c,$46,$14,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1072 : 997
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1072 : 1052
	db	$54,$0e,$4b,$07,$fc,$07,$54,$1b	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1072 : 1080
	db	$46,$15,$48,$07,$fc,$07,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1073 : 1135
	db	$fc,$07,$48,$07,$54,$0e,$4b,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1073 : 1177
	db	$fc,$06,$54,$1c,$46,$15,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1073 : 1212
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1074 : 1274
	db	$54,$0d,$4b,$07,$fc,$07,$54,$1c	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1074 : 1302
	db	$46,$15,$48,$07,$fc,$07,$48,$06	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1075 : 1357
	db	$fc,$07,$48,$07,$54,$0e,$4b,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1075 : 1398
	db	$fc,$07,$fc,$6f,$fc,$6f,$fc,$6e	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1075 : 1433
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1079 : 1772
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1083 : 2215
	db	$fc,$6f,$54,$1c,$46,$15,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1087 : 2658
	db	$fc,$07,$48,$06,$fc,$07,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1088 : 2825
	db	$54,$0e,$4b,$07,$fc,$07,$54,$1c	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1088 : 2852
	db	$46,$14,$48,$07,$fc,$07,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1089 : 2908
	db	$fc,$07,$48,$07,$54,$0e,$4b,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1089 : 2949
	db	$fc,$07,$54,$1b,$46,$15,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1089 : 2984
	db	$fc,$07,$48,$07,$fc,$07,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1090 : 3046
	db	$54,$0e,$4b,$07,$fc,$07,$54,$1b	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1090 : 3074
	db	$46,$15,$48,$07,$fc,$07,$48,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1091 : 3129
	db	$fc,$07,$48,$07,$54,$0d,$4b,$07	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1091 : 3171
	db	$fc,$07,$fc,$6f,$fc,$6f,$fc,$6f	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1091 : 3205
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1095 : 3545
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk W; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1099 : 3988
	db	$fc,$6f
song_000_22_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_22_lp)*2
	dw	song_000_22_lp


song_000_23:	;Trk X
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1106 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1110 : 443
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1114 : 886
	db	$fc,$6f,$fc,$07,$fb,$08,$fd,$0e	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1118 : 1329
	db	$fe,$81,$54,$15,$fc,$07,$53,$0a	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1119 : 1447
	db	$fc,$03,$53,$07,$51,$07,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1119 : 1485
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1119 : 1509
	db	$fc,$07,$53,$07,$fc,$07,$54,$0e	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1119 : 1537
	db	$53,$06,$fc,$07,$51,$07,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1120 : 1572
	db	$4b,$38,$fc,$07,$fc,$06,$54,$15	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1120 : 1599
	db	$fc,$07,$53,$0b,$fc,$03,$53,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1121 : 1689
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1121 : 1717
	db	$4b,$07,$51,$06,$fc,$07,$53,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1121 : 1745
	db	$fc,$07,$4b,$0e,$51,$07,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1122 : 1772
	db	$53,$07,$fc,$07,$54,$37,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1122 : 1807
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1123 : 1883
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1127 : 2326
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1131 : 2769
	db	$fc,$07,$54,$15,$fc,$07,$53,$0a	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1135 : 3212
	db	$fc,$04,$53,$07,$51,$07,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1135 : 3257
	db	$4b,$06,$fc,$07,$4b,$07,$51,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1135 : 3282
	db	$fc,$07,$53,$07,$fc,$07,$54,$0e	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1135 : 3309
	db	$53,$07,$fc,$07,$51,$07,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1136 : 3344
	db	$4b,$37,$fc,$07,$fc,$07,$54,$15	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1136 : 3372
	db	$fc,$06,$53,$0b,$fc,$03,$53,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1137 : 3462
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1137 : 3489
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1137 : 3517
	db	$fc,$07,$4b,$0d,$51,$07,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1138 : 3545
	db	$53,$07,$fc,$07,$54,$37,$fc,$07	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1138 : 3579
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1139 : 3655
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk X; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1143 : 4098

song_000_23_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_23_lp)*2
	dw	song_000_23_lp


song_000_24:	;Trk Y
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1149 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1153 : 443
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1157 : 886
	db	$fc,$6f,$fb,$08,$fd,$0e,$fe,$81	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1161 : 1329
	db	$64,$15,$fc,$07,$63,$0a,$fc,$04	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1162 : 1440
	db	$63,$06,$61,$07,$fc,$07,$5b,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1162 : 1482
	db	$fc,$07,$5b,$07,$61,$07,$fc,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1162 : 1509
	db	$63,$07,$fc,$07,$64,$0e,$63,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1162 : 1537
	db	$fc,$06,$61,$07,$fc,$07,$5b,$38	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1163 : 1572
	db	$fc,$0e,$64,$14,$fc,$07,$63,$0b	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1163 : 1648
	db	$fc,$03,$63,$07,$61,$07,$fc,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1164 : 1700
	db	$5b,$07,$fc,$07,$5b,$07,$61,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1164 : 1724
	db	$fc,$06,$63,$07,$fc,$07,$5b,$0e	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1164 : 1752
	db	$61,$07,$fc,$07,$63,$07,$fc,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1165 : 1786
	db	$64,$37,$fc,$0e,$fc,$6f,$fc,$6f	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1165 : 1814
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1168 : 2105
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1172 : 2548
	db	$fc,$6f,$fc,$6e,$64,$15,$fc,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1176 : 2991
	db	$63,$0a,$fc,$04,$63,$07,$61,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1178 : 3240
	db	$fc,$07,$5b,$07,$fc,$06,$5b,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1178 : 3268
	db	$61,$07,$fc,$07,$63,$07,$fc,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1178 : 3295
	db	$64,$0e,$63,$07,$fc,$07,$61,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1179 : 3323
	db	$fc,$07,$5b,$37,$fc,$0e,$64,$15	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1179 : 3358
	db	$fc,$07,$63,$0a,$fc,$03,$63,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1180 : 3455
	db	$61,$07,$fc,$07,$5b,$07,$fc,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1180 : 3482
	db	$5b,$07,$61,$07,$fc,$07,$63,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1180 : 3510
	db	$fc,$07,$5b,$0d,$61,$07,$fc,$07	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1180 : 3538
	db	$63,$07,$fc,$07,$64,$38,$fc,$0d	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1181 : 3572
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1182 : 3655
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk Y; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1186 : 4098

song_000_24_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_24_lp)*2
	dw	song_000_24_lp


song_000_25:	;Trk Z

song_000_25_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_25_lp)*2
	dw	song_000_25_lp


song_000_26:	;Trk a
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1192 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1196 : 443
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1200 : 886
	db	$fc,$6f,$fb,$07,$fd,$0f,$fe,$02	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1204 : 1329
	db	$64,$15,$fc,$07,$63,$0a,$fc,$04	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1205 : 1440
	db	$63,$06,$61,$07,$fc,$07,$5b,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1205 : 1482
	db	$fc,$07,$5b,$07,$61,$07,$fc,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1205 : 1509
	db	$63,$07,$fc,$07,$64,$0e,$63,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1205 : 1537
	db	$fc,$06,$61,$07,$fc,$07,$5b,$38	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1206 : 1572
	db	$fc,$0e,$64,$14,$fc,$07,$63,$0b	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1206 : 1648
	db	$fc,$03,$63,$07,$61,$07,$fc,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1207 : 1700
	db	$5b,$07,$fc,$07,$5b,$07,$61,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1207 : 1724
	db	$fc,$06,$63,$07,$fc,$07,$5b,$0e	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1207 : 1752
	db	$61,$07,$fc,$07,$63,$07,$fc,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1208 : 1786
	db	$64,$37,$fc,$0e,$fc,$6f,$fc,$6f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1208 : 1814
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1211 : 2105
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1215 : 2548
	db	$fc,$6f,$fc,$6e,$64,$15,$fc,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1219 : 2991
	db	$63,$0a,$fc,$04,$63,$07,$61,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1221 : 3240
	db	$fc,$07,$5b,$07,$fc,$06,$5b,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1221 : 3268
	db	$61,$07,$fc,$07,$63,$07,$fc,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1221 : 3295
	db	$64,$0e,$63,$07,$fc,$07,$61,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1222 : 3323
	db	$fc,$07,$5b,$37,$fc,$0e,$64,$15	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1222 : 3358
	db	$fc,$07,$63,$0a,$fc,$03,$63,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1223 : 3455
	db	$61,$07,$fc,$07,$5b,$07,$fc,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1223 : 3482
	db	$5b,$07,$61,$07,$fc,$07,$63,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1223 : 3510
	db	$fc,$07,$5b,$0d,$61,$07,$fc,$07	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1223 : 3538
	db	$63,$07,$fc,$07,$64,$38,$fc,$0d	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1224 : 3572
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1225 : 3655
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk a; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1229 : 4098

song_000_26_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_26_lp)*2
	dw	song_000_26_lp


song_000_27:	;Trk b
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1235 : 0
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1239 : 443
	db	$fc,$6f,$fc,$6f,$fc,$6e,$fc,$6f	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1243 : 886
	db	$fc,$6f,$fb,$07,$fd,$0f,$fe,$02	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1247 : 1329
	db	$54,$15,$fc,$07,$53,$0a,$fc,$04	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1248 : 1440
	db	$53,$06,$51,$07,$fc,$07,$4b,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1248 : 1482
	db	$fc,$07,$4b,$07,$51,$07,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1248 : 1509
	db	$53,$07,$fc,$07,$54,$0e,$53,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1248 : 1537
	db	$fc,$06,$51,$07,$fc,$07,$4b,$38	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1249 : 1572
	db	$fc,$0e,$54,$14,$fc,$07,$53,$0b	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1249 : 1648
	db	$fc,$03,$53,$07,$51,$07,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1250 : 1700
	db	$4b,$07,$fc,$07,$4b,$07,$51,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1250 : 1724
	db	$fc,$06,$53,$07,$fc,$07,$4b,$0e	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1250 : 1752
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1251 : 1786
	db	$54,$37,$fc,$0e,$fc,$6f,$fc,$6f	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1251 : 1814
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1254 : 2105
	db	$fc,$6e,$fc,$6f,$fc,$6f,$fc,$6f	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1258 : 2548
	db	$fc,$6f,$fc,$6e,$54,$15,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1262 : 2991
	db	$53,$0a,$fc,$04,$53,$07,$51,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1264 : 3240
	db	$fc,$07,$4b,$07,$fc,$06,$4b,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1264 : 3268
	db	$51,$07,$fc,$07,$53,$07,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1264 : 3295
	db	$54,$0e,$53,$07,$fc,$07,$51,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1265 : 3323
	db	$fc,$07,$4b,$37,$fc,$0e,$54,$15	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1265 : 3358
	db	$fc,$07,$53,$0a,$fc,$03,$53,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1266 : 3455
	db	$51,$07,$fc,$07,$4b,$07,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1266 : 3482
	db	$4b,$07,$51,$07,$fc,$07,$53,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1266 : 3510
	db	$fc,$07,$4b,$0d,$51,$07,$fc,$07	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1266 : 3538
	db	$53,$07,$fc,$07,$54,$38,$fc,$0d	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1267 : 3572
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6e	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1268 : 3655
	db	$fc,$6f,$fc,$6f,$fc,$6f,$fc,$6f	;Trk b; C:\Users\stgig\Downloads\newppmck\songs\mrpgbattle.mml: 1272 : 4098

song_000_27_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_27_lp)*2
	dw	song_000_27_lp

