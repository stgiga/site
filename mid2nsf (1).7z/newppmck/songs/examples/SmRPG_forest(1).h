; Title: SmRPG_forest(1)
; Composer: Sequenced By BuBu (brunozip@hotmail.com)
; Maker: 
; Programer: mid2mml for ppmck Ver1.0�� & stgig

	.bank	0
	.if TOTAL_SONGS > 1
song_addr_table:
	dw	song_000_track_table
	.if (ALLOW_BANK_SWITCH)
song_bank_table:
	dw	song_000_bank_table
	.endif ; ALLOW_BANK_SWITCH
	.endif ; TOTAL_SONGS > 1
song_000_track_table:
	dw	song_000_00
	dw	song_000_01
	dw	song_000_02
	dw	song_000_03
	dw	song_000_04
	dw	song_000_06
	dw	song_000_07
	dw	song_000_08
	dw	song_000_09
	dw	song_000_10
	dw	song_000_11
	dw	song_000_15
	dw	song_000_16
	dw	song_000_17
	dw	song_000_18
	dw	song_000_19
	dw	song_000_20
	dw	song_000_21
	dw	song_000_22
	.if (ALLOW_BANK_SWITCH)
song_000_bank_table:
	db	bank(song_000_00)*2
	db	bank(song_000_01)*2
	db	bank(song_000_02)*2
	db	bank(song_000_03)*2
	db	bank(song_000_04)*2
	db	bank(song_000_06)*2
	db	bank(song_000_07)*2
	db	bank(song_000_08)*2
	db	bank(song_000_09)*2
	db	bank(song_000_10)*2
	db	bank(song_000_11)*2
	db	bank(song_000_15)*2
	db	bank(song_000_16)*2
	db	bank(song_000_17)*2
	db	bank(song_000_18)*2
	db	bank(song_000_19)*2
	db	bank(song_000_20)*2
	db	bank(song_000_21)*2
	db	bank(song_000_22)*2
	.endif

song_000_00:	;Trk A
	db	$ee
	db	bank(song_000_00_bnk001)*2
	dw	song_000_00_bnk001

	.bank	1
	.org	$a000
song_000_00_bnk001:
	db	$fd,$08,$fe,$00,$fb,$04,$31,$4d	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 61
	db	$fc,$01,$2b,$27,$2a,$27,$28,$4d	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 78
	db	$fc,$01,$2a,$13,$2b,$13,$31,$14	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 80
	db	$33,$13,$34,$4e,$31,$4e,$36,$3a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 81
	db	$34,$14,$fd,$09,$33,$13,$fc,$14	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 84
	db	$fd,$0a,$33,$13,$fd,$0b,$2b,$14	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 85
	db	$fd,$08,$21,$9b,$2b,$4e,$2a,$27	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 86
	db	$31,$27,$fd,$09,$19,$09,$fc,$0b	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 89
	db	$21,$09,$fc,$0a,$21,$0a,$fc,$09	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 90
	db	$19,$0b,$fc,$09,$19,$0a,$fc,$09	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 90
	db	$21,$09,$fc,$0b,$21,$0a,$fc,$09	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 91
	db	$19,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 91
	db	$23,$09,$fc,$0b,$23,$09,$fc,$0a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 92
	db	$1b,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 92
	db	$23,$0c,$fc,$07,$23,$0c,$fc,$08	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 93
	db	$1b,$09,$fc,$0a,$fd,$0a,$21,$4e	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 93
	db	$1b,$27,$19,$26,$fc,$01,$18,$4d	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 95
	db	$fc,$01,$16,$26,$fc,$01,$14,$26	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 96
	db	$fc,$01,$0b,$9b,$08,$9c,$fc,$4e	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 97
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 103
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fd,$08	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 107
	db	$21,$74,$fc,$01,$1b,$26,$19,$4e	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 110
	db	$18,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 113
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 117
	db	$fc,$27,$23,$26,$fc,$01,$31,$4d	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 121
	db	$fc,$01,$2b,$27,$2a,$27,$28,$4d	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 122
	db	$2a,$14,$2b,$13,$31,$14,$33,$13	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 125
	db	$34,$4e,$31,$4e,$36,$3a,$34,$14	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 126
	db	$fd,$09,$33,$13,$fc,$14,$fd,$0a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 129
	db	$33,$13,$fd,$0b,$2b,$14,$fd,$08	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 129
	db	$21,$9b,$2b,$4d,$fc,$01,$2a,$26	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 130
	db	$fc,$01,$31,$27,$fd,$09,$19,$09	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 133
	db	$fc,$0a,$21,$0a,$fc,$0a,$21,$0a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 134
	db	$fc,$09,$19,$0b,$fc,$09,$19,$0a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 134
	db	$fc,$09,$21,$09,$fc,$0b,$21,$09	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 135
	db	$fc,$0a,$19,$09,$fc,$0b,$1b,$09	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 135
	db	$fc,$0a,$23,$09,$fc,$0b,$23,$09	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 136
	db	$fc,$0a,$1b,$09,$fc,$0a,$1b,$0a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 136
	db	$fc,$0a,$23,$0b,$fc,$08,$23,$0c	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 137
	db	$fc,$08,$1b,$09,$fc,$0a,$fd,$0a	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 137
	db	$21,$4e,$1b,$26,$fc,$01,$19,$26	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 138
	db	$fc,$01,$18,$4d,$fc,$01,$16,$26	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 139
	db	$fc,$01,$14,$26,$fc,$01,$0b,$9b	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 141
	db	$08,$9b,$fc,$01,$fc,$4e,$fc,$4e	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 144
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 148
	db	$fc,$4e,$fc,$4e,$fd,$08,$21,$74	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 152
	db	$1b,$27,$19,$4e,$18,$4d,$fc,$01	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 155
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 158
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$27	;Trk A; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 162
	db	$23,$26,$fc,$01,$fc,$09
song_000_00_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_00_lp)*2
	dw	song_000_00_lp


song_000_01:	;Trk B
	db	$fd,$0c,$fe,$01,$fb,$00,$fc,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 62
	db	$21,$09,$23,$06,$fc,$04,$24,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 168
	db	$fc,$04,$26,$05,$fc,$05,$28,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 168
	db	$fc,$0e,$31,$05,$fc,$05,$fc,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 168
	db	$2b,$05,$fc,$0e,$28,$05,$fc,$0b	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 169
	db	$2a,$03,$2a,$14,$fc,$0a,$fc,$09	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 169
	db	$2b,$0c,$fc,$08,$28,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 170
	db	$2a,$04,$fc,$05,$2b,$0c,$fc,$08	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 170
	db	$2a,$05,$fc,$05,$26,$04,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 170
	db	$23,$05,$fc,$0f,$24,$05,$fc,$0e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 171
	db	$23,$13,$fc,$0a,$fc,$0a,$21,$09	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 171
	db	$fc,$01,$23,$05,$fc,$05,$24,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 172
	db	$fc,$05,$26,$05,$fc,$05,$24,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 172
	db	$fc,$09,$23,$05,$fc,$05,$24,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 172
	db	$fc,$05,$26,$13,$24,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 173
	db	$23,$05,$fc,$05,$21,$13,$fc,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 173
	db	$fc,$0a,$26,$0b,$fc,$08,$24,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 174
	db	$fc,$05,$23,$05,$fc,$05,$21,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 174
	db	$fc,$09,$23,$05,$fc,$05,$24,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 174
	db	$fc,$05,$26,$0b,$fc,$08,$24,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 175
	db	$fc,$05,$26,$05,$fc,$05,$28,$12	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 175
	db	$fc,$0b,$fc,$4e,$fc,$4d,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 175
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 179
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 183
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 187
	db	$fc,$31,$31,$05,$fc,$05,$2b,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 191
	db	$fc,$04,$29,$05,$fc,$05,$fc,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 191
	db	$26,$05,$fc,$0e,$29,$05,$fc,$0f	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 192
	db	$31,$06,$fc,$0d,$36,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 192
	db	$fc,$0a,$34,$05,$fc,$0e,$31,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 193
	db	$fc,$0e,$33,$08,$fc,$15,$fc,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 193
	db	$34,$04,$fc,$0f,$31,$04,$fc,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 194
	db	$33,$04,$fc,$05,$34,$06,$fc,$0e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 194
	db	$33,$06,$fc,$04,$2b,$05,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 194
	db	$28,$06,$fc,$0e,$29,$06,$fc,$0d	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 195
	db	$28,$19,$fc,$04,$fc,$0a,$26,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 195
	db	$fc,$04,$28,$06,$fc,$04,$29,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 196
	db	$fc,$03,$2b,$06,$fc,$04,$29,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 196
	db	$fc,$10,$28,$06,$fc,$03,$29,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 196
	db	$fc,$04,$2b,$06,$fc,$0d,$29,$07	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 197
	db	$fc,$03,$28,$06,$fc,$04,$26,$08	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 197
	db	$fc,$15,$fc,$0a,$2b,$05,$fc,$0e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 197
	db	$29,$06,$fc,$04,$28,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 198
	db	$26,$06,$fc,$0d,$28,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 198
	db	$29,$06,$fc,$04,$2b,$06,$fc,$0d	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 199
	db	$29,$06,$fc,$04,$2b,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 199
	db	$31,$09,$fc,$0a,$31,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 199
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 200
	db	$fc,$0a,$26,$08,$fc,$02,$28,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 204
	db	$fc,$04,$29,$05,$fc,$05,$2b,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 204
	db	$fc,$04,$31,$07,$fc,$0c,$36,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 204
	db	$fc,$04,$fc,$13,$39,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 204
	db	$38,$06,$fc,$04,$36,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 205
	db	$34,$05,$fc,$0e,$31,$08,$fc,$02	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 205
	db	$fc,$13,$36,$05,$fc,$05,$34,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 206
	db	$fc,$04,$32,$05,$fc,$04,$31,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 206
	db	$fc,$0e,$2b,$05,$fc,$05,$fc,$09	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 206
	db	$29,$13,$fc,$01,$28,$13,$29,$13	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 207
	db	$fc,$01,$2b,$11,$fc,$46,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 207
	db	$fc,$4e,$fc,$4e,$fc,$0a,$21,$09	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 210
	db	$23,$06,$fc,$04,$24,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 212
	db	$26,$05,$fc,$05,$28,$05,$fc,$0e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 212
	db	$31,$05,$fc,$05,$fc,$09,$2b,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 212
	db	$fc,$0e,$28,$05,$fc,$0b,$2a,$03	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 213
	db	$2a,$14,$fc,$0a,$fc,$09,$2b,$0c	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 213
	db	$fc,$08,$28,$05,$fc,$04,$2a,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 214
	db	$fc,$05,$2b,$0c,$fc,$08,$2a,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 214
	db	$fc,$04,$26,$05,$fc,$05,$23,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 214
	db	$fc,$0f,$24,$04,$fc,$0f,$23,$13	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 215
	db	$fc,$0a,$fc,$0a,$21,$09,$fc,$01	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 215
	db	$23,$05,$fc,$04,$24,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 216
	db	$26,$05,$fc,$05,$24,$0a,$fc,$09	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 216
	db	$23,$05,$fc,$05,$24,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 216
	db	$26,$13,$24,$05,$fc,$05,$23,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 217
	db	$fc,$05,$21,$13,$fc,$0a,$fc,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 217
	db	$26,$0b,$fc,$08,$24,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 218
	db	$23,$05,$fc,$05,$21,$0a,$fc,$09	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 218
	db	$23,$05,$fc,$05,$24,$05,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 218
	db	$26,$0c,$fc,$08,$24,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 219
	db	$26,$05,$fc,$04,$28,$13,$fc,$0b	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 219
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 220
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 224
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 228
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$31	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 232
	db	$31,$05,$fc,$05,$2b,$05,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 235
	db	$29,$05,$fc,$05,$fc,$0a,$26,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 235
	db	$fc,$0e,$29,$05,$fc,$0f,$31,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 236
	db	$fc,$0d,$36,$06,$fc,$04,$fc,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 236
	db	$34,$04,$fc,$0f,$31,$05,$fc,$0e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 237
	db	$33,$08,$fc,$16,$fc,$09,$34,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 237
	db	$fc,$0f,$31,$04,$fc,$06,$33,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 238
	db	$fc,$05,$34,$06,$fc,$0e,$33,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 238
	db	$fc,$03,$2b,$06,$fc,$04,$28,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 238
	db	$fc,$0e,$29,$06,$fc,$0d,$28,$19	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 239
	db	$fc,$04,$fc,$0a,$26,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 239
	db	$28,$06,$fc,$04,$29,$06,$fc,$03	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 240
	db	$2b,$06,$fc,$04,$29,$04,$fc,$0f	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 240
	db	$28,$07,$fc,$03,$29,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 240
	db	$2b,$06,$fc,$0d,$29,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 241
	db	$28,$06,$fc,$04,$26,$08,$fc,$15	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 241
	db	$fc,$0a,$2b,$05,$fc,$0e,$29,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 242
	db	$fc,$04,$28,$06,$fc,$04,$26,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 242
	db	$fc,$0d,$28,$06,$fc,$04,$29,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 242
	db	$fc,$04,$2b,$06,$fc,$0d,$29,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 243
	db	$fc,$04,$2b,$06,$fc,$03,$31,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 243
	db	$fc,$0a,$31,$06,$fc,$04,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 243
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$0a	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 245
	db	$26,$08,$fc,$01,$28,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 248
	db	$29,$04,$fc,$06,$2b,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 248
	db	$31,$07,$fc,$0c,$36,$06,$fc,$04	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 248
	db	$fc,$13,$39,$05,$fc,$05,$38,$06	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 249
	db	$fc,$04,$36,$05,$fc,$05,$34,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 249
	db	$fc,$0e,$31,$08,$fc,$02,$fc,$13	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 249
	db	$36,$05,$fc,$05,$34,$05,$fc,$05	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 250
	db	$32,$05,$fc,$04,$31,$06,$fc,$0e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 250
	db	$2b,$05,$fc,$05,$fc,$09,$29,$13	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 250
	db	$fc,$01,$28,$13,$29,$13,$fc,$01	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 251
	db	$2b,$11,$fc,$46,$fc,$4e,$fc,$4e	;Trk B; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 251
	db	$fc,$4e,$fc,$09
song_000_01_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_01_lp)*2
	dw	song_000_01_lp


song_000_02:	;Trk C
	db	$fe,$8f,$fb,$05,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 60
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 260
	db	$fc,$4e,$fc,$4e,$41,$08,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 264
	db	$43,$05,$fc,$01,$fc,$04,$44,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 266
	db	$fc,$01,$fc,$04,$46,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 266
	db	$fc,$05,$48,$04,$fc,$01,$fc,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 266
	db	$48,$04,$fc,$01,$fc,$05,$51,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 266
	db	$fc,$01,$fc,$04,$51,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 266
	db	$fc,$06,$4b,$04,$fc,$01,$fc,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 266
	db	$4b,$04,$fc,$01,$fc,$05,$48,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 267
	db	$fc,$01,$fc,$05,$48,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 267
	db	$fc,$05,$4a,$1c,$fc,$02,$fc,$09	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 267
	db	$4b,$09,$fc,$01,$4b,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 268
	db	$fc,$06,$48,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 268
	db	$4a,$03,$fc,$01,$fc,$05,$4b,$08	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 268
	db	$fc,$01,$fc,$01,$4b,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 268
	db	$fc,$06,$4a,$04,$fc,$01,$fc,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 268
	db	$46,$04,$fc,$01,$fc,$05,$43,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 268
	db	$fc,$01,$fc,$0f,$44,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 269
	db	$fc,$0e,$43,$1b,$fc,$02,$fc,$0a	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 269
	db	$41,$08,$fc,$01,$fc,$01,$43,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 270
	db	$fc,$01,$fc,$05,$44,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 270
	db	$fc,$05,$46,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 270
	db	$44,$07,$fc,$01,$fc,$02,$44,$03	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 270
	db	$fc,$01,$fc,$05,$43,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 270
	db	$fc,$05,$44,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 270
	db	$46,$11,$fc,$02,$44,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 271
	db	$fc,$05,$43,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 271
	db	$41,$1c,$fc,$02,$fc,$09,$46,$07	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 271
	db	$fc,$01,$fc,$01,$46,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 272
	db	$fc,$05,$44,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 272
	db	$43,$04,$fc,$01,$fc,$05,$41,$07	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 272
	db	$fc,$01,$fc,$01,$41,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 272
	db	$fc,$05,$43,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 272
	db	$44,$04,$fc,$01,$fc,$05,$46,$08	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 272
	db	$fc,$01,$46,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 273
	db	$44,$04,$fc,$01,$fc,$05,$46,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 273
	db	$fc,$01,$fc,$04,$48,$24,$fc,$03	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 273
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 274
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 278
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 282
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 286
	db	$36,$07,$fc,$01,$fc,$02,$38,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 290
	db	$fc,$01,$fc,$04,$39,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 290
	db	$fc,$05,$3b,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 290
	db	$41,$06,$fc,$01,$fc,$02,$41,$03	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 290
	db	$fc,$01,$fc,$06,$46,$08,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 290
	db	$fc,$01,$46,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 290
	db	$49,$11,$fc,$02,$48,$05,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 291
	db	$fc,$04,$46,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 291
	db	$44,$04,$fc,$01,$fc,$04,$44,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 291
	db	$fc,$01,$fc,$07,$41,$07,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 291
	db	$fc,$02,$41,$02,$fc,$01,$fc,$06	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 291
	db	$46,$11,$fc,$02,$fc,$01,$44,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 292
	db	$fc,$01,$fc,$02,$44,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 292
	db	$fc,$01,$42,$04,$fc,$01,$fc,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 292
	db	$41,$09,$fc,$01,$41,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 292
	db	$fc,$07,$3b,$08,$fc,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 292
	db	$3b,$02,$fc,$01,$fc,$06,$39,$11	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 292
	db	$fc,$02,$fc,$01,$38,$11,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 293
	db	$39,$11,$fc,$02,$fc,$01,$3b,$0f	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 293
	db	$fc,$02,$fc,$02,$41,$49,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 293
	db	$36,$22,$fc,$03,$fc,$02,$38,$22	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 295
	db	$fc,$03,$fc,$02,$39,$36,$fc,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 295
	db	$38,$11,$fc,$02,$fc,$01,$36,$11	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 296
	db	$fc,$02,$35,$12,$fc,$02,$36,$11	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 297
	db	$fc,$02,$38,$12,$fc,$02,$36,$db	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 297
	db	$fc,$0f,$fc,$4d,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 298
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 304
	db	$fc,$4e,$fc,$4e,$41,$08,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 308
	db	$43,$05,$fc,$01,$fc,$04,$44,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 310
	db	$fc,$01,$fc,$04,$46,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 310
	db	$fc,$04,$48,$05,$fc,$01,$fc,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 310
	db	$48,$03,$fc,$01,$fc,$06,$51,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 310
	db	$fc,$01,$fc,$05,$51,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 310
	db	$fc,$05,$4b,$05,$fc,$01,$fc,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 310
	db	$4b,$03,$fc,$01,$fc,$06,$48,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 311
	db	$fc,$01,$fc,$05,$48,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 311
	db	$fc,$05,$4a,$1c,$fc,$02,$fc,$09	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 311
	db	$4b,$08,$fc,$01,$fc,$01,$4b,$03	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 312
	db	$fc,$01,$fc,$06,$48,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 312
	db	$fc,$04,$4a,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 312
	db	$4b,$08,$fc,$01,$fc,$01,$4b,$03	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 312
	db	$fc,$01,$fc,$06,$4a,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 312
	db	$fc,$05,$46,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 312
	db	$43,$04,$fc,$01,$fc,$0f,$44,$03	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 313
	db	$fc,$01,$fc,$0f,$43,$1b,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 313
	db	$fc,$0a,$41,$08,$fc,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 313
	db	$43,$04,$fc,$01,$fc,$04,$44,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 314
	db	$fc,$01,$fc,$05,$46,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 314
	db	$fc,$05,$44,$07,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 314
	db	$44,$03,$fc,$01,$fc,$05,$43,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 314
	db	$fc,$01,$fc,$05,$44,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 314
	db	$fc,$05,$46,$11,$fc,$02,$44,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 314
	db	$fc,$01,$fc,$05,$43,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 315
	db	$fc,$05,$41,$1b,$fc,$02,$fc,$0a	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 315
	db	$46,$07,$fc,$01,$fc,$01,$46,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 316
	db	$fc,$01,$fc,$05,$44,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 316
	db	$fc,$05,$43,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 316
	db	$41,$06,$fc,$01,$fc,$02,$41,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 316
	db	$fc,$01,$fc,$05,$43,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 316
	db	$fc,$05,$44,$04,$fc,$01,$fc,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 316
	db	$46,$09,$fc,$01,$46,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 317
	db	$fc,$06,$44,$04,$fc,$01,$fc,$05	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 317
	db	$46,$03,$fc,$01,$fc,$05,$48,$24	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 317
	db	$fc,$03,$fc,$4e,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 317
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 321
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 325
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 329
	db	$fc,$4e,$36,$07,$fc,$01,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 333
	db	$38,$05,$fc,$01,$fc,$04,$39,$03	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 334
	db	$fc,$01,$fc,$06,$3b,$04,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 334
	db	$fc,$05,$41,$06,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 334
	db	$41,$02,$fc,$01,$fc,$07,$46,$08	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 334
	db	$fc,$01,$fc,$01,$46,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 334
	db	$fc,$07,$49,$10,$fc,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 334
	db	$48,$04,$fc,$01,$fc,$05,$46,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 335
	db	$fc,$01,$fc,$04,$44,$05,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 335
	db	$fc,$04,$44,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 335
	db	$41,$07,$fc,$01,$fc,$02,$41,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 335
	db	$fc,$01,$fc,$06,$46,$11,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 335
	db	$fc,$01,$44,$04,$fc,$01,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 336
	db	$44,$01,$fc,$01,$fc,$01,$42,$04	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 336
	db	$fc,$01,$fc,$04,$41,$08,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 336
	db	$fc,$01,$41,$02,$fc,$01,$fc,$07	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 336
	db	$3b,$08,$fc,$01,$3b,$03,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 336
	db	$fc,$06,$39,$11,$fc,$02,$fc,$01	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 336
	db	$38,$11,$fc,$02,$39,$11,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 337
	db	$fc,$01,$3b,$0f,$fc,$02,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 337
	db	$41,$49,$fc,$05,$36,$22,$fc,$03	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 338
	db	$fc,$02,$38,$22,$fc,$03,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 339
	db	$39,$35,$fc,$04,$fc,$01,$38,$11	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 340
	db	$fc,$02,$fc,$01,$36,$11,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 340
	db	$35,$11,$fc,$02,$36,$12,$fc,$02	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 341
	db	$38,$11,$fc,$02,$36,$dc,$fc,$0f	;Trk C; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 341
	db	$fc,$4d,$fc,$09
song_000_02_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_02_lp)*2
	dw	song_000_02_lp


song_000_03:	;Trk D
	db	$fe,$8f
song_000_03_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_03_lp)*2
	dw	song_000_03_lp


song_000_04:	;Trk E

song_000_04_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_04_lp)*2
	dw	song_000_04_lp


song_000_06:	;Trk G
	db	$fd,$1c,$fe,$00,$fe,$40,$fb,$00	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 64
	db	$41,$09,$fc,$01,$43,$05,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 348
	db	$44,$06,$fc,$04,$46,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 348
	db	$48,$05,$fc,$0e,$51,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 348
	db	$4b,$05,$fc,$0e,$48,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 349
	db	$fd,$1a,$4a,$03,$fd,$1c,$4a,$13	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 349
	db	$fc,$11,$4b,$0b,$fc,$08,$48,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 349
	db	$fc,$05,$4a,$05,$fc,$05,$4b,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 350
	db	$fc,$08,$4a,$05,$fc,$05,$46,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 350
	db	$fc,$05,$43,$04,$fc,$0f,$44,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 350
	db	$fc,$0e,$fd,$1a,$43,$03,$fd,$1c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 351
	db	$43,$13,$fc,$11,$41,$09,$fc,$01	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 351
	db	$43,$05,$fc,$05,$44,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 352
	db	$46,$04,$fc,$05,$44,$0b,$fc,$09	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 352
	db	$43,$05,$fc,$04,$44,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 352
	db	$46,$11,$fc,$03,$fd,$1b,$44,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 353
	db	$fd,$1c,$44,$05,$fc,$01,$43,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 353
	db	$fc,$05,$41,$14,$fc,$13,$46,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 353
	db	$fc,$08,$44,$05,$fc,$05,$43,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 354
	db	$fc,$05,$41,$0a,$fc,$09,$43,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 354
	db	$fc,$05,$44,$05,$fc,$05,$46,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 354
	db	$fc,$08,$fd,$1b,$44,$03,$fd,$1c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 355
	db	$44,$05,$fc,$02,$46,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 355
	db	$48,$13,$fc,$14,$fd,$1b,$38,$09	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 355
	db	$3b,$05,$fc,$05,$41,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 356
	db	$43,$05,$fc,$05,$44,$04,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 356
	db	$48,$05,$fc,$0f,$48,$04,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 356
	db	$44,$05,$fc,$0e,$fd,$1a,$46,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 357
	db	$fd,$1b,$46,$14,$fc,$0f,$48,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 357
	db	$fc,$09,$44,$05,$fc,$05,$46,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 358
	db	$fc,$05,$48,$0b,$fc,$09,$48,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 358
	db	$fc,$04,$46,$05,$fc,$05,$43,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 358
	db	$fc,$09,$41,$08,$fc,$0b,$fd,$1a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 359
	db	$3b,$03,$fd,$1b,$3b,$14,$fc,$10	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 359
	db	$39,$07,$fc,$03,$3b,$04,$fc,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 360
	db	$41,$04,$fc,$05,$43,$07,$fc,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 360
	db	$41,$09,$fc,$0a,$3b,$07,$fc,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 360
	db	$41,$07,$fc,$03,$43,$13,$fd,$1a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 360
	db	$41,$03,$fd,$1b,$41,$07,$3b,$07	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 361
	db	$fc,$03,$39,$11,$fc,$16,$3b,$09	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 361
	db	$fc,$0a,$39,$04,$fc,$06,$38,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 362
	db	$fc,$06,$36,$0a,$fc,$09,$38,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 362
	db	$fc,$06,$39,$04,$fc,$06,$3b,$09	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 362
	db	$fc,$0a,$fd,$1a,$3b,$03,$fd,$1b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 363
	db	$3b,$05,$fc,$02,$41,$04,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 363
	db	$43,$1f,$fc,$08,$fc,$4e,$fc,$4e	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 363
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 366
	db	$fc,$4e,$fc,$27,$fd,$1c,$51,$09	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 370
	db	$fc,$01,$4b,$07,$fc,$03,$49,$08	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 371
	db	$fc,$01,$48,$0a,$46,$07,$fc,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 371
	db	$48,$06,$fc,$04,$49,$04,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 372
	db	$4b,$06,$fc,$04,$51,$07,$fc,$0c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 372
	db	$56,$07,$fc,$0d,$54,$08,$fc,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 372
	db	$51,$07,$fc,$0d,$fd,$1a,$53,$02	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 373
	db	$fc,$01,$fd,$1c,$53,$18,$fc,$0c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 373
	db	$54,$06,$fc,$0d,$51,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 374
	db	$53,$06,$fc,$04,$54,$07,$fc,$0c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 374
	db	$53,$06,$fc,$04,$4b,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 374
	db	$48,$07,$fc,$0c,$49,$06,$fc,$0e	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 375
	db	$fd,$1a,$48,$03,$fd,$1c,$48,$18	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 375
	db	$fc,$0b,$46,$07,$fc,$03,$48,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 375
	db	$fc,$04,$49,$06,$fc,$04,$4b,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 376
	db	$fc,$03,$49,$08,$fc,$0c,$48,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 376
	db	$fc,$04,$49,$06,$fc,$03,$4b,$13	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 376
	db	$fc,$01,$fd,$1a,$49,$02,$fc,$01	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 377
	db	$fd,$1c,$49,$06,$48,$07,$fc,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 377
	db	$46,$16,$fc,$01,$fd,$1a,$46,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 377
	db	$fc,$0a,$fd,$1c,$4b,$08,$fc,$0c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 377
	db	$49,$06,$fc,$03,$48,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 378
	db	$46,$07,$fc,$0d,$48,$06,$fc,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 378
	db	$49,$06,$fc,$04,$4b,$09,$fc,$0a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 378
	db	$fd,$1a,$49,$03,$fd,$1c,$49,$07	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 379
	db	$4b,$06,$fc,$04,$51,$1b,$fc,$0c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 379
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 380
	db	$46,$08,$fc,$02,$48,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 384
	db	$49,$04,$fc,$05,$4b,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 384
	db	$51,$07,$fc,$0d,$56,$09,$fc,$0a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 384
	db	$59,$12,$fc,$01,$58,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 385
	db	$56,$06,$fc,$04,$54,$05,$fc,$0e	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 385
	db	$51,$08,$fc,$0c,$56,$11,$fc,$02	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 385
	db	$54,$06,$fc,$04,$52,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 386
	db	$51,$09,$fc,$0a,$4b,$09,$fc,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 386
	db	$49,$13,$48,$13,$fc,$01,$49,$12	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 387
	db	$fc,$01,$4b,$12,$fc,$02,$4a,$26	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 387
	db	$51,$c4,$fc,$26,$48,$09,$fc,$01	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 388
	db	$46,$08,$fc,$01,$44,$09,$fc,$01	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 391
	db	$fd,$1a,$44,$04,$fc,$06,$fd,$1c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 391
	db	$41,$09,$fc,$01,$43,$05,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 392
	db	$44,$06,$fc,$04,$46,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 392
	db	$48,$05,$fc,$0e,$51,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 392
	db	$4b,$05,$fc,$0e,$48,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 393
	db	$fd,$1a,$4a,$03,$fd,$1c,$4a,$13	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 393
	db	$fc,$11,$4b,$0b,$fc,$08,$48,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 393
	db	$fc,$05,$4a,$05,$fc,$04,$4b,$0c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 394
	db	$fc,$08,$4a,$05,$fc,$05,$46,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 394
	db	$fc,$04,$43,$05,$fc,$0f,$44,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 394
	db	$fc,$0e,$fd,$1a,$43,$03,$fd,$1c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 395
	db	$43,$13,$fc,$11,$41,$09,$fc,$01	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 395
	db	$43,$05,$fc,$05,$44,$05,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 396
	db	$46,$05,$fc,$05,$44,$0a,$fc,$0a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 396
	db	$43,$04,$fc,$05,$44,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 396
	db	$46,$11,$fc,$03,$fd,$1b,$44,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 397
	db	$fd,$1c,$44,$04,$fc,$02,$43,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 397
	db	$fc,$05,$41,$13,$fc,$14,$46,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 397
	db	$fc,$08,$44,$05,$fc,$05,$43,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 398
	db	$fc,$05,$41,$0a,$fc,$09,$43,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 398
	db	$fc,$05,$44,$05,$fc,$05,$46,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 398
	db	$fc,$08,$fd,$1b,$44,$03,$fd,$1c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 399
	db	$44,$05,$fc,$02,$46,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 399
	db	$48,$13,$fc,$14,$fd,$1a,$38,$09	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 399
	db	$3b,$05,$fc,$05,$41,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 400
	db	$43,$05,$fc,$04,$44,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 400
	db	$48,$05,$fc,$0e,$48,$05,$fc,$0f	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 400
	db	$44,$05,$fc,$0e,$46,$03,$46,$14	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 401
	db	$fc,$10,$48,$0b,$fc,$09,$44,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 401
	db	$fc,$04,$46,$05,$fc,$05,$48,$0b	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 402
	db	$fc,$09,$48,$05,$fc,$04,$46,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 402
	db	$fc,$05,$43,$04,$fc,$10,$41,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 402
	db	$fc,$0f,$3b,$03,$3b,$14,$fc,$10	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 403
	db	$39,$07,$fc,$03,$3b,$04,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 404
	db	$41,$05,$fc,$05,$43,$04,$fc,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 404
	db	$41,$09,$fc,$0a,$3b,$05,$fc,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 404
	db	$41,$04,$fc,$06,$43,$13,$41,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 404
	db	$41,$05,$fc,$02,$3b,$04,$fc,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 405
	db	$39,$11,$fc,$16,$3b,$09,$fc,$0a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 405
	db	$39,$04,$fc,$06,$38,$04,$fc,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 406
	db	$36,$0a,$fc,$09,$38,$04,$fc,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 406
	db	$39,$04,$fc,$05,$3b,$0a,$fc,$0a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 406
	db	$3b,$03,$3b,$05,$fc,$02,$41,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 407
	db	$fc,$05,$43,$14,$fc,$13,$fc,$4e	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 407
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 409
	db	$fc,$4e,$fc,$4e,$fc,$27,$fd,$1c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 413
	db	$51,$09,$fc,$01,$4b,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 415
	db	$49,$07,$fc,$02,$48,$09,$fc,$01	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 415
	db	$46,$07,$fc,$03,$48,$06,$fc,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 416
	db	$49,$05,$fc,$05,$4b,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 416
	db	$51,$07,$fc,$0c,$56,$06,$fc,$0e	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 416
	db	$54,$08,$fc,$0b,$51,$07,$fc,$0d	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 417
	db	$fd,$1a,$53,$02,$fc,$01,$fd,$1c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 417
	db	$53,$17,$fc,$0d,$54,$06,$fc,$0d	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 417
	db	$51,$06,$fc,$04,$53,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 418
	db	$54,$07,$fc,$0c,$53,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 418
	db	$4b,$06,$fc,$03,$48,$08,$fc,$0c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 418
	db	$49,$06,$fc,$0d,$fd,$1a,$48,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 419
	db	$fd,$1c,$48,$19,$fc,$0b,$46,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 419
	db	$fc,$04,$48,$06,$fc,$04,$49,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 420
	db	$fc,$04,$4b,$06,$fc,$03,$49,$08	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 420
	db	$fc,$0c,$48,$06,$fc,$03,$49,$07	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 420
	db	$fc,$03,$4b,$12,$fc,$02,$fd,$1a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 420
	db	$49,$02,$fc,$01,$fd,$1c,$49,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 421
	db	$48,$06,$fc,$04,$46,$16,$fc,$01	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 421
	db	$fd,$1a,$46,$06,$fc,$0a,$fd,$1c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 421
	db	$4b,$08,$fc,$0b,$49,$07,$fc,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 422
	db	$48,$06,$fc,$04,$46,$07,$fc,$0c	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 422
	db	$48,$06,$fc,$04,$49,$06,$fc,$04	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 422
	db	$4b,$09,$fc,$0a,$fd,$1a,$49,$03	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 423
	db	$fd,$1c,$49,$06,$fc,$01,$4b,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 423
	db	$fc,$04,$51,$1b,$fc,$0c,$fc,$4e	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 423
	db	$fc,$4d,$fc,$4e,$fc,$4e,$46,$08	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 425
	db	$fc,$02,$48,$05,$fc,$04,$49,$05	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 428
	db	$fc,$05,$4b,$06,$fc,$04,$51,$07	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 428
	db	$fc,$0c,$56,$0a,$fc,$0a,$59,$12	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 428
	db	$fc,$01,$58,$06,$fc,$04,$56,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 429
	db	$fc,$04,$54,$05,$fc,$0e,$51,$08	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 429
	db	$fc,$0c,$56,$11,$fc,$02,$54,$06	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 429
	db	$fc,$04,$52,$05,$fc,$05,$51,$09	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 430
	db	$fc,$0a,$4b,$09,$fc,$0b,$49,$12	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 430
	db	$fc,$01,$48,$13,$49,$13,$fc,$01	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 431
	db	$4b,$12,$fc,$01,$4a,$27,$51,$c4	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 431
	db	$fc,$26,$48,$08,$fc,$02,$46,$08	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 435
	db	$fc,$01,$44,$08,$fc,$02,$fd,$1a	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 435
	db	$44,$04,$fc,$06,$fd,$1c,$41,$09	;Trk G; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 435

song_000_06_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_06_lp)*2
	dw	song_000_06_lp


song_000_07:	;Trk H
	db	$fd,$1c,$fe,$00,$fe,$40,$fb,$00	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 65
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 438
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 442
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 446
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 450
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 454
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 458
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 462
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 466
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 470
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 474
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$44	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 478
	db	$43,$09,$fc,$01,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 481
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 484
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 488
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 492
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 496
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 500
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 504
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 508
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 512
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 516
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 520
	db	$fc,$4e,$fc,$44,$43,$09,$fc,$01	;Trk H; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 524
	db	$fc,$09
song_000_07_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_07_lp)*2
	dw	song_000_07_lp


song_000_08:	;Trk I
	db	$fd,$14,$fe,$0d,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 66
	db	$28,$0a,$fc,$0a,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 528
	db	$28,$0a,$fc,$0a,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 528
	db	$28,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 529
	db	$31,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 529
	db	$2b,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 530
	db	$2b,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 530
	db	$31,$09,$fc,$0a,$1b,$0a,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 531
	db	$26,$09,$fc,$0a,$19,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 531
	db	$24,$09,$fc,$0a,$19,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 532
	db	$24,$09,$fc,$0a,$19,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 532
	db	$24,$09,$fc,$0a,$19,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 533
	db	$24,$09,$fc,$0a,$1b,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 533
	db	$26,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 534
	db	$26,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 534
	db	$26,$09,$fc,$0b,$18,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 535
	db	$23,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 535
	db	$28,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 536
	db	$28,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 536
	db	$fd,$15,$28,$09,$fc,$0a,$26,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 537
	db	$fc,$0a,$31,$09,$fc,$0a,$24,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 537
	db	$fc,$0a,$2b,$09,$fc,$0a,$24,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 538
	db	$fc,$0b,$2b,$09,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 538
	db	$fc,$0b,$31,$09,$fc,$0a,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 539
	db	$fc,$0b,$26,$09,$fc,$0a,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 539
	db	$fc,$0b,$24,$09,$fc,$0a,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 540
	db	$fc,$0a,$24,$0a,$fc,$0a,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 540
	db	$fc,$0a,$24,$09,$fc,$0b,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 541
	db	$fc,$0a,$24,$09,$fc,$0b,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 541
	db	$fc,$0a,$26,$09,$fc,$0b,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 542
	db	$fc,$0a,$26,$09,$fc,$0b,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 542
	db	$fc,$0a,$26,$09,$fc,$0a,$18,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 543
	db	$fc,$0a,$23,$09,$fc,$0a,$fc,$27	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 543
	db	$fd,$14,$21,$09,$fc,$01,$fd,$13	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 544
	db	$21,$0a,$fc,$13,$fc,$27,$fd,$15	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 544
	db	$21,$09,$fc,$01,$fd,$13,$21,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 545
	db	$fc,$13,$fc,$27,$fd,$15,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 545
	db	$fc,$01,$fd,$13,$1b,$08,$fc,$15	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 546
	db	$fc,$27,$fd,$15,$1b,$09,$fc,$1e	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 547
	db	$fc,$27,$21,$09,$fc,$1e,$fc,$27	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 548
	db	$21,$09,$fc,$1d,$21,$0a,$fc,$1d	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 549
	db	$21,$09,$fc,$1e,$21,$09,$fc,$1e	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 550
	db	$21,$09,$fc,$1e,$26,$0e,$fc,$06	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 551
	db	$31,$08,$fc,$0b,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 552
	db	$31,$0a,$fc,$0a,$26,$0b,$fc,$08	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 552
	db	$31,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 553
	db	$26,$09,$fc,$0b,$19,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 553
	db	$24,$09,$fc,$0b,$19,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 554
	db	$24,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 554
	db	$26,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 555
	db	$2b,$09,$fc,$0a,$22,$0a,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 555
	db	$29,$09,$fc,$0a,$22,$0a,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 556
	db	$29,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 556
	db	$29,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 557
	db	$29,$09,$fc,$0a,$24,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 557
	db	$2b,$09,$fc,$0a,$24,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 558
	db	$2b,$09,$fc,$0a,$24,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 558
	db	$2b,$0a,$fc,$0a,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 559
	db	$28,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 559
	db	$31,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 560
	db	$31,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 560
	db	$31,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 561
	db	$2b,$09,$fc,$0a,$22,$0a,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 561
	db	$29,$09,$fc,$0a,$22,$0a,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 562
	db	$29,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 562
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 563
	db	$28,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 563
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 564
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 564
	db	$31,$0a,$fc,$0a,$24,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 565
	db	$2b,$0a,$fc,$0a,$22,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 565
	db	$29,$09,$fc,$0b,$22,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 566
	db	$29,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 566
	db	$28,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 567
	db	$28,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 567
	db	$31,$09,$fc,$0a,$26,$0a,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 568
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 568
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 569
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 569
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 570
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 570
	db	$31,$0a,$fc,$0a,$28,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 571
	db	$33,$0a,$fc,$0a,$fd,$14,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 571
	db	$fc,$0a,$28,$09,$fc,$0b,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 572
	db	$fc,$0a,$28,$09,$fc,$0b,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 572
	db	$fc,$0a,$28,$09,$fc,$0b,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 573
	db	$fc,$0a,$31,$09,$fc,$0b,$24,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 573
	db	$fc,$0a,$2b,$09,$fc,$0a,$24,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 574
	db	$fc,$0a,$2b,$09,$fc,$0a,$26,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 574
	db	$fc,$0a,$31,$09,$fc,$0a,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 575
	db	$fc,$0b,$26,$09,$fc,$0a,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 575
	db	$fc,$0b,$24,$09,$fc,$0a,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 576
	db	$fc,$0b,$24,$09,$fc,$0a,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 576
	db	$fc,$0b,$24,$09,$fc,$0a,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 577
	db	$fc,$0a,$24,$0a,$fc,$0a,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 577
	db	$fc,$0a,$26,$09,$fc,$0b,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 578
	db	$fc,$0a,$26,$09,$fc,$0b,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 578
	db	$fc,$0a,$26,$09,$fc,$0b,$18,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 579
	db	$fc,$0a,$23,$09,$fc,$0b,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 579
	db	$fc,$0a,$28,$09,$fc,$0a,$21,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 580
	db	$fc,$0a,$28,$09,$fc,$0a,$21,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 580
	db	$fc,$0a,$fd,$15,$28,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 581
	db	$26,$09,$fc,$0b,$31,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 581
	db	$24,$09,$fc,$0b,$2b,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 582
	db	$24,$09,$fc,$0b,$2b,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 582
	db	$26,$09,$fc,$0b,$31,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 583
	db	$1b,$09,$fc,$0a,$26,$0a,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 583
	db	$19,$09,$fc,$0a,$24,$0a,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 584
	db	$19,$09,$fc,$0a,$24,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 584
	db	$19,$09,$fc,$0a,$24,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 585
	db	$19,$09,$fc,$0a,$24,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 585
	db	$1b,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 586
	db	$1b,$09,$fc,$0a,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 586
	db	$1b,$0a,$fc,$0a,$26,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 587
	db	$18,$09,$fc,$0b,$23,$09,$fc,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 587
	db	$fc,$27,$fd,$14,$21,$09,$fc,$01	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 588
	db	$fd,$13,$21,$0a,$fc,$13,$fc,$27	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 588
	db	$fd,$15,$21,$09,$fc,$01,$fd,$13	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 589
	db	$21,$09,$fc,$14,$fc,$27,$fd,$15	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 589
	db	$1b,$09,$fc,$01,$fd,$13,$1b,$08	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 590
	db	$fc,$15,$fc,$27,$fd,$15,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 590
	db	$fc,$1e,$fc,$27,$21,$09,$fc,$1d	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 591
	db	$fc,$27,$21,$0a,$fc,$1d,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 593
	db	$fc,$1e,$21,$09,$fc,$1e,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 594
	db	$fc,$1e,$21,$09,$fc,$1e,$26,$0e	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 595
	db	$fc,$05,$31,$09,$fc,$0b,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 596
	db	$fc,$0a,$31,$09,$fc,$0b,$26,$0b	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 596
	db	$fc,$08,$31,$09,$fc,$0b,$1b,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 597
	db	$fc,$0a,$26,$09,$fc,$0b,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 597
	db	$fc,$0a,$24,$09,$fc,$0b,$19,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 598
	db	$fc,$0a,$24,$09,$fc,$0a,$1b,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 598
	db	$fc,$0a,$26,$09,$fc,$0a,$24,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 599
	db	$fc,$0a,$2b,$09,$fc,$0a,$22,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 599
	db	$fc,$0b,$29,$09,$fc,$0a,$22,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 600
	db	$fc,$0b,$29,$09,$fc,$0a,$22,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 600
	db	$fc,$0b,$29,$09,$fc,$0a,$22,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 601
	db	$fc,$0b,$29,$09,$fc,$0a,$24,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 601
	db	$fc,$0a,$2b,$0a,$fc,$0a,$24,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 602
	db	$fc,$0a,$2b,$0a,$fc,$0a,$24,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 602
	db	$fc,$0a,$2b,$09,$fc,$0b,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 603
	db	$fc,$0a,$28,$09,$fc,$0b,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 603
	db	$fc,$0a,$31,$09,$fc,$0b,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 604
	db	$fc,$0a,$31,$09,$fc,$0b,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 604
	db	$fc,$0a,$31,$09,$fc,$0a,$24,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 605
	db	$fc,$0a,$2b,$09,$fc,$0a,$22,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 605
	db	$fc,$0b,$29,$09,$fc,$0a,$22,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 606
	db	$fc,$0b,$29,$09,$fc,$0a,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 606
	db	$fc,$0b,$28,$09,$fc,$0a,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 607
	db	$fc,$0b,$28,$09,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 607
	db	$fc,$0a,$31,$0a,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 608
	db	$fc,$0a,$31,$0a,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 608
	db	$fc,$0a,$31,$09,$fc,$0b,$24,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 609
	db	$fc,$0a,$2b,$09,$fc,$0b,$22,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 609
	db	$fc,$0a,$29,$09,$fc,$0b,$22,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 610
	db	$fc,$0a,$29,$09,$fc,$0b,$21,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 610
	db	$fc,$0a,$28,$09,$fc,$0a,$21,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 611
	db	$fc,$0a,$28,$09,$fc,$0a,$26,$0a	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 611
	db	$fc,$0a,$31,$09,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 612
	db	$fc,$0b,$31,$09,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 612
	db	$fc,$0b,$31,$09,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 613
	db	$fc,$0b,$31,$09,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 613
	db	$fc,$0b,$31,$09,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 614
	db	$fc,$0a,$31,$0a,$fc,$0a,$26,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 614
	db	$fc,$0a,$31,$09,$fc,$0b,$28,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 615
	db	$fc,$0a,$33,$09,$fc,$0b,$fc,$09	;Trk I; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 615

song_000_08_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_08_lp)*2
	dw	song_000_08_lp


song_000_09:	;Trk J
	db	$fd,$12,$fe,$04,$41,$09,$fc,$01	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 67
	db	$43,$05,$fc,$04,$44,$06,$fc,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 618
	db	$46,$06,$fc,$04,$48,$05,$fc,$22	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 618
	db	$4b,$05,$fc,$0e,$48,$05,$fc,$0f	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 619
	db	$4a,$13,$fc,$14,$4b,$0b,$fc,$08	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 619
	db	$48,$05,$fc,$05,$4a,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 620
	db	$4b,$0b,$fc,$08,$4a,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 620
	db	$46,$05,$fc,$05,$43,$04,$fc,$0f	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 620
	db	$44,$05,$fc,$0e,$43,$13,$fc,$14	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 621
	db	$41,$09,$fc,$01,$43,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 622
	db	$44,$05,$fc,$05,$46,$04,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 622
	db	$44,$0b,$fc,$09,$43,$05,$fc,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 622
	db	$44,$05,$fc,$05,$46,$13,$fc,$01	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 622
	db	$44,$05,$fc,$04,$43,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 623
	db	$41,$14,$fc,$13,$46,$0b,$fc,$08	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 623
	db	$44,$05,$fc,$05,$43,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 624
	db	$41,$0a,$fc,$09,$43,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 624
	db	$44,$05,$fc,$05,$46,$0b,$fc,$08	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 624
	db	$44,$05,$fc,$05,$46,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 625
	db	$48,$13,$fc,$14,$41,$09,$43,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 625
	db	$fc,$04,$44,$06,$fc,$04,$46,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 626
	db	$fc,$05,$48,$05,$fc,$22,$4b,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 626
	db	$fc,$0e,$48,$05,$fc,$0e,$4a,$14	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 627
	db	$fc,$13,$4b,$0c,$fc,$08,$48,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 627
	db	$fc,$05,$4a,$04,$fc,$05,$4b,$0c	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 628
	db	$fc,$08,$4a,$05,$fc,$04,$46,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 628
	db	$fc,$05,$43,$05,$fc,$0f,$44,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 628
	db	$fc,$0e,$43,$13,$fc,$14,$41,$09	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 629
	db	$fc,$01,$43,$05,$fc,$05,$44,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 630
	db	$fc,$05,$46,$05,$fc,$05,$44,$0a	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 630
	db	$fc,$09,$43,$05,$fc,$05,$44,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 630
	db	$fc,$05,$46,$13,$44,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 630
	db	$43,$05,$fc,$05,$41,$13,$fc,$14	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 631
	db	$46,$0b,$fc,$08,$44,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 632
	db	$43,$05,$fc,$05,$41,$0a,$fc,$09	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 632
	db	$43,$05,$fc,$05,$44,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 632
	db	$46,$0b,$fc,$08,$44,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 633
	db	$46,$05,$fc,$04,$48,$13,$fc,$14	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 633
	db	$43,$07,$fc,$03,$44,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 634
	db	$48,$07,$fc,$03,$51,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 634
	db	$43,$07,$fc,$03,$44,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 634
	db	$48,$06,$fc,$04,$51,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 634
	db	$43,$07,$fc,$03,$44,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 635
	db	$48,$06,$fc,$03,$51,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 635
	db	$43,$07,$fc,$03,$44,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 635
	db	$48,$06,$fc,$03,$51,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 635
	db	$41,$07,$fc,$03,$42,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 636
	db	$46,$06,$fc,$03,$4b,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 636
	db	$41,$07,$fc,$03,$42,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 636
	db	$46,$07,$fc,$03,$4b,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 636
	db	$41,$07,$fc,$03,$42,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 637
	db	$46,$07,$fc,$03,$4b,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 637
	db	$41,$07,$fc,$03,$42,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 637
	db	$46,$07,$fc,$03,$4b,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 637
	db	$45,$06,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 638
	db	$4b,$07,$fc,$03,$51,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 638
	db	$45,$06,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 638
	db	$4b,$07,$fc,$03,$51,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 638
	db	$45,$06,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 639
	db	$4b,$07,$fc,$03,$51,$06,$fc,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 639
	db	$45,$06,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 639
	db	$4b,$07,$fc,$03,$51,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 639
	db	$45,$07,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 640
	db	$4b,$07,$fc,$03,$51,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 640
	db	$45,$07,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 640
	db	$4b,$07,$fc,$03,$51,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 640
	db	$45,$07,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 641
	db	$4b,$06,$fc,$03,$51,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 641
	db	$45,$07,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 641
	db	$4b,$06,$fc,$03,$51,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 641
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 642
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 646
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 650
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 654
	db	$46,$06,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 658
	db	$4a,$07,$fc,$03,$4b,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 658
	db	$51,$07,$fc,$0d,$56,$07,$fc,$0c	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 658
	db	$46,$07,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 659
	db	$4a,$07,$fc,$03,$4b,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 659
	db	$51,$07,$fc,$0d,$56,$06,$fc,$0d	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 659
	db	$46,$07,$fc,$03,$48,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 660
	db	$4a,$06,$fc,$03,$4b,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 660
	db	$51,$07,$fc,$0d,$56,$06,$fc,$0d	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 660
	db	$46,$07,$fc,$03,$48,$06,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 661
	db	$4a,$07,$fc,$03,$4b,$07,$fc,$03	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 661
	db	$43,$07,$fc,$0c,$48,$07,$fc,$0d	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 661
	db	$41,$09,$fc,$01,$43,$05,$fc,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 662
	db	$44,$06,$fc,$04,$46,$06,$fc,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 662
	db	$48,$05,$fc,$22,$4b,$05,$fc,$0e	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 662
	db	$48,$05,$fc,$0c,$fd,$11,$4a,$02	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 663
	db	$fc,$01,$fd,$12,$4a,$13,$fc,$14	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 663
	db	$4b,$0b,$fc,$08,$48,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 664
	db	$4a,$05,$fc,$04,$4b,$0c,$fc,$08	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 664
	db	$4a,$05,$fc,$05,$46,$05,$fc,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 664
	db	$43,$05,$fc,$0f,$44,$05,$fc,$0e	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 665
	db	$43,$13,$fc,$14,$41,$09,$fc,$01	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 665
	db	$43,$05,$fc,$05,$44,$05,$fc,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 666
	db	$46,$05,$fc,$05,$44,$0a,$fc,$0a	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 666
	db	$43,$04,$fc,$05,$44,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 666
	db	$46,$13,$fc,$01,$44,$04,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 667
	db	$43,$05,$fc,$05,$41,$13,$fc,$14	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 667
	db	$46,$0b,$fc,$08,$44,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 668
	db	$43,$05,$fc,$05,$41,$0a,$fc,$09	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 668
	db	$43,$05,$fc,$05,$44,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 668
	db	$46,$0b,$fc,$08,$44,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 669
	db	$46,$05,$fc,$05,$48,$13,$fc,$14	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 669
	db	$41,$09,$43,$06,$fc,$04,$44,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 670
	db	$fc,$04,$46,$05,$fc,$04,$48,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 670
	db	$fc,$21,$4b,$06,$fc,$0e,$48,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 670
	db	$fc,$0b,$fd,$11,$4a,$03,$fd,$12	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 671
	db	$4a,$14,$fc,$13,$4b,$0c,$fc,$08	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 671
	db	$48,$05,$fc,$04,$4a,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 672
	db	$4b,$0c,$fc,$08,$4a,$04,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 672
	db	$46,$05,$fc,$05,$43,$05,$fc,$0f	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 672
	db	$44,$04,$fc,$0f,$43,$13,$fc,$14	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 673
	db	$41,$09,$fc,$01,$43,$05,$fc,$04	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 674
	db	$44,$05,$fc,$05,$46,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 674
	db	$44,$0a,$fc,$09,$43,$05,$fc,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 674
	db	$44,$05,$fc,$05,$46,$13,$44,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 674
	db	$fc,$05,$43,$05,$fc,$05,$41,$13	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 675
	db	$fc,$14,$46,$0b,$fc,$08,$44,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 675
	db	$fc,$05,$43,$05,$fc,$05,$41,$0a	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 676
	db	$fc,$09,$43,$05,$fc,$05,$44,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 676
	db	$fc,$04,$46,$0c,$fc,$08,$44,$05	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 676
	db	$fc,$05,$46,$04,$fc,$05,$48,$13	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 677
	db	$fc,$14,$43,$07,$fc,$03,$44,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 677
	db	$fc,$03,$48,$06,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 678
	db	$fc,$03,$43,$07,$fc,$03,$44,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 678
	db	$fc,$03,$48,$06,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 678
	db	$fc,$03,$43,$07,$fc,$03,$44,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 678
	db	$fc,$03,$48,$06,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 679
	db	$fc,$03,$43,$07,$fc,$03,$44,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 679
	db	$fc,$03,$48,$07,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 679
	db	$fc,$03,$41,$07,$fc,$03,$42,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 679
	db	$fc,$03,$46,$07,$fc,$03,$4b,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 680
	db	$fc,$03,$41,$07,$fc,$03,$42,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 680
	db	$fc,$03,$46,$07,$fc,$03,$4b,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 680
	db	$fc,$03,$41,$06,$fc,$04,$42,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 680
	db	$fc,$03,$46,$07,$fc,$03,$4b,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 681
	db	$fc,$03,$41,$06,$fc,$03,$42,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 681
	db	$fc,$03,$46,$07,$fc,$03,$4b,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 681
	db	$fc,$03,$45,$06,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 681
	db	$fc,$03,$4b,$07,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 682
	db	$fc,$03,$45,$06,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 682
	db	$fc,$03,$4b,$07,$fc,$03,$51,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 682
	db	$fc,$03,$45,$07,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 682
	db	$fc,$03,$4b,$07,$fc,$03,$51,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 683
	db	$fc,$03,$45,$07,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 683
	db	$fc,$03,$4b,$07,$fc,$03,$51,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 683
	db	$fc,$03,$45,$07,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 683
	db	$fc,$03,$4b,$06,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 684
	db	$fc,$03,$45,$07,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 684
	db	$fc,$03,$4b,$06,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 684
	db	$fc,$03,$45,$07,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 684
	db	$fc,$03,$4b,$06,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 685
	db	$fc,$03,$45,$07,$fc,$03,$48,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 685
	db	$fc,$04,$4b,$06,$fc,$03,$51,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 685
	db	$fc,$03,$fc,$4e,$fc,$4e,$fc,$4d	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 685
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 689
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 693
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 697
	db	$fc,$4d,$46,$07,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 701
	db	$fc,$03,$4a,$07,$fc,$03,$4b,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 702
	db	$fc,$03,$51,$07,$fc,$0d,$56,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 702
	db	$fc,$0d,$46,$07,$fc,$03,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 702
	db	$fc,$03,$4a,$06,$fc,$03,$4b,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 703
	db	$fc,$03,$51,$07,$fc,$0d,$56,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 703
	db	$fc,$0d,$46,$07,$fc,$03,$48,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 703
	db	$fc,$04,$4a,$06,$fc,$03,$4b,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 704
	db	$fc,$03,$51,$07,$fc,$0c,$56,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 704
	db	$fc,$0d,$46,$07,$fc,$03,$48,$06	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 704
	db	$fc,$03,$4a,$07,$fc,$03,$4b,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 705
	db	$fc,$03,$43,$07,$fc,$0c,$48,$07	;Trk J; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 705
	db	$fc,$0d,$fc,$09
song_000_09_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_09_lp)*2
	dw	song_000_09_lp


song_000_10:	;Trk K
	db	$fd,$1d,$fe,$08,$21,$08,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 68
	db	$28,$08,$fc,$0c,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 708
	db	$28,$08,$fc,$0c,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 708
	db	$28,$0a,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 709
	db	$31,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 709
	db	$2b,$0a,$fc,$0a,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 710
	db	$2b,$09,$fc,$0b,$26,$08,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 710
	db	$31,$08,$fc,$0b,$1b,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 711
	db	$26,$08,$fc,$0b,$19,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 711
	db	$24,$0a,$fc,$09,$19,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 712
	db	$24,$08,$fc,$0b,$19,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 712
	db	$24,$08,$fc,$0b,$19,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 713
	db	$24,$08,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 713
	db	$26,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 714
	db	$26,$08,$fc,$0c,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 714
	db	$26,$09,$fc,$0b,$18,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 715
	db	$23,$08,$fc,$0c,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 715
	db	$28,$09,$fc,$0b,$21,$08,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 716
	db	$28,$08,$fc,$0c,$21,$0a,$fc,$09	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 716
	db	$28,$09,$fc,$0a,$26,$0b,$fc,$09	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 717
	db	$31,$09,$fc,$0a,$24,$0b,$fc,$09	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 717
	db	$2b,$08,$fc,$0b,$24,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 718
	db	$2b,$08,$fc,$0b,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 718
	db	$31,$09,$fc,$0a,$1b,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 719
	db	$26,$08,$fc,$0b,$19,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 719
	db	$24,$09,$fc,$0a,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 720
	db	$24,$0a,$fc,$0a,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 720
	db	$24,$0a,$fc,$0a,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 721
	db	$24,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 721
	db	$26,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 722
	db	$26,$08,$fc,$0c,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 722
	db	$26,$09,$fc,$0a,$18,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 723
	db	$23,$09,$fc,$0a,$21,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 723
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 724
	db	$21,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 724
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 725
	db	$21,$09,$fc,$0a,$1b,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 725
	db	$26,$09,$fc,$0a,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 726
	db	$1b,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 726
	db	$26,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 727
	db	$1b,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 727
	db	$28,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 728
	db	$21,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 728
	db	$28,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 729
	db	$21,$09,$fc,$0a,$21,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 729
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 730
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 730
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 731
	db	$28,$09,$fc,$0a,$16,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 731
	db	$21,$09,$fc,$0a,$16,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 732
	db	$21,$0a,$fc,$0a,$16,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 732
	db	$21,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 733
	db	$26,$09,$fc,$0b,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 733
	db	$24,$09,$fc,$0b,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 734
	db	$24,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 734
	db	$26,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 735
	db	$2b,$09,$fc,$0a,$22,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 735
	db	$29,$09,$fc,$0a,$22,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 736
	db	$29,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 736
	db	$29,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 737
	db	$29,$09,$fc,$0a,$24,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 737
	db	$2b,$09,$fc,$0a,$24,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 738
	db	$2b,$09,$fc,$0a,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 738
	db	$2b,$0a,$fc,$0a,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 739
	db	$28,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 739
	db	$31,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 740
	db	$31,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 740
	db	$31,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 741
	db	$2b,$09,$fc,$0a,$22,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 741
	db	$29,$09,$fc,$0a,$22,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 742
	db	$29,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 742
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 743
	db	$28,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 743
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 744
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 744
	db	$31,$0a,$fc,$0a,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 745
	db	$2b,$0a,$fc,$0a,$22,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 745
	db	$29,$09,$fc,$0b,$22,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 746
	db	$29,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 746
	db	$28,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 747
	db	$28,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 747
	db	$31,$09,$fc,$0a,$26,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 748
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 748
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 749
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 749
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 750
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 750
	db	$31,$0a,$fc,$0a,$28,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 751
	db	$33,$0a,$fc,$0a,$21,$08,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 751
	db	$28,$08,$fc,$0c,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 752
	db	$28,$08,$fc,$0c,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 752
	db	$28,$0a,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 753
	db	$31,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 753
	db	$2b,$0a,$fc,$09,$24,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 754
	db	$2b,$08,$fc,$0b,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 754
	db	$31,$08,$fc,$0b,$1b,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 755
	db	$26,$08,$fc,$0b,$19,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 755
	db	$24,$09,$fc,$0a,$19,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 756
	db	$24,$08,$fc,$0b,$19,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 756
	db	$24,$08,$fc,$0b,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 757
	db	$24,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 757
	db	$26,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 758
	db	$26,$08,$fc,$0c,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 758
	db	$26,$09,$fc,$0b,$18,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 759
	db	$23,$08,$fc,$0c,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 759
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 760
	db	$28,$08,$fc,$0b,$21,$0b,$fc,$09	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 760
	db	$28,$09,$fc,$0a,$26,$0b,$fc,$09	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 761
	db	$31,$09,$fc,$0a,$24,$0b,$fc,$09	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 761
	db	$2b,$08,$fc,$0b,$24,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 762
	db	$2b,$08,$fc,$0b,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 762
	db	$31,$09,$fc,$0a,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 763
	db	$26,$09,$fc,$0b,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 763
	db	$24,$0a,$fc,$0a,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 764
	db	$24,$09,$fc,$0b,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 764
	db	$24,$0a,$fc,$0a,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 765
	db	$24,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 765
	db	$26,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 766
	db	$26,$08,$fc,$0b,$1b,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 766
	db	$26,$09,$fc,$0a,$18,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 767
	db	$23,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 767
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 768
	db	$21,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 768
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 769
	db	$21,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 769
	db	$26,$0a,$fc,$0a,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 770
	db	$1b,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 770
	db	$26,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 771
	db	$1b,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 771
	db	$28,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 772
	db	$21,$09,$fc,$0a,$21,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 772
	db	$28,$09,$fc,$0a,$21,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 773
	db	$21,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 773
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 774
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 774
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 775
	db	$28,$09,$fc,$0a,$16,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 775
	db	$21,$0a,$fc,$0a,$16,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 776
	db	$21,$09,$fc,$0b,$16,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 776
	db	$21,$09,$fc,$0b,$1b,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 777
	db	$26,$09,$fc,$0b,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 777
	db	$24,$09,$fc,$0b,$19,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 778
	db	$24,$09,$fc,$0a,$1b,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 778
	db	$26,$09,$fc,$0a,$24,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 779
	db	$2b,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 779
	db	$29,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 780
	db	$29,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 780
	db	$29,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 781
	db	$29,$09,$fc,$0a,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 781
	db	$2b,$0a,$fc,$0a,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 782
	db	$2b,$0a,$fc,$0a,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 782
	db	$2b,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 783
	db	$28,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 783
	db	$31,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 784
	db	$31,$09,$fc,$0b,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 784
	db	$31,$09,$fc,$0a,$24,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 785
	db	$2b,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 785
	db	$29,$09,$fc,$0a,$22,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 786
	db	$29,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 786
	db	$28,$09,$fc,$0a,$21,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 787
	db	$28,$09,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 787
	db	$31,$0a,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 788
	db	$31,$0a,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 788
	db	$31,$09,$fc,$0b,$24,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 789
	db	$2b,$09,$fc,$0b,$22,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 789
	db	$29,$09,$fc,$0b,$22,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 790
	db	$29,$09,$fc,$0b,$21,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 790
	db	$28,$09,$fc,$0a,$21,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 791
	db	$28,$09,$fc,$0a,$26,$0a,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 791
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 792
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 792
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 793
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0b	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 793
	db	$31,$09,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 794
	db	$31,$0a,$fc,$0a,$26,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 794
	db	$31,$09,$fc,$0b,$28,$09,$fc,$0a	;Trk K; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 795
	db	$33,$09,$ee
	db	bank(song_000_10_bnk002)*2
	dw	song_000_10_bnk002

	.bank	2
	.org	$c000
song_000_10_bnk002:
	db	$fc,$0b,$fc,$09
song_000_10_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_10_lp)*2
	dw	song_000_10_lp


song_000_11:	;Trk L
	db	$fd,$16,$fe,$04,$44,$74,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 69
	db	$46,$25,$fc,$02,$44,$4d,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 799
	db	$46,$13,$48,$13,$46,$13,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 801
	db	$46,$13,$49,$9c,$4b,$61,$fd,$18	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 801
	db	$54,$14,$fd,$16,$48,$26,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 805
	db	$48,$74,$4a,$27,$44,$4e,$46,$26	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 806
	db	$fc,$01,$46,$27,$fd,$17,$34,$09	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 809
	db	$fc,$0b,$39,$0a,$fc,$09,$39,$09	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 810
	db	$fc,$0a,$34,$0a,$fc,$0a,$34,$08	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 810
	db	$fc,$0b,$39,$0a,$fc,$0a,$39,$09	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 811
	db	$fc,$0a,$34,$0b,$fc,$09,$36,$0a	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 811
	db	$fc,$09,$3b,$08,$fc,$0c,$3b,$09	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 812
	db	$fc,$0a,$36,$09,$fc,$0b,$36,$09	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 812
	db	$fc,$0a,$3b,$0c,$fc,$07,$3b,$0a	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 813
	db	$fc,$0a,$36,$09,$fc,$0a,$fd,$19	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 813
	db	$38,$4e,$38,$27,$36,$26,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 814
	db	$32,$4d,$fc,$01,$32,$26,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 816
	db	$31,$26,$fc,$01,$32,$9b,$31,$9d	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 817
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4d	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 822
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 826
	db	$fd,$16,$39,$74,$fc,$01,$38,$26	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 830
	db	$36,$4e,$35,$4e,$fc,$4e,$fc,$4e	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 832
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 836
	db	$fc,$4e,$fc,$27,$48,$26,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 840
	db	$44,$74,$fc,$01,$46,$25,$fc,$02	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 842
	db	$44,$4d,$46,$14,$48,$13,$46,$13	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 844
	db	$fc,$01,$46,$13,$49,$9c,$4b,$61	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 845
	db	$fd,$18,$54,$14,$fd,$16,$48,$26	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 849
	db	$fc,$01,$48,$74,$4a,$27,$44,$4e	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 849
	db	$46,$26,$fc,$01,$46,$27,$fd,$17	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 853
	db	$34,$08,$fc,$0b,$39,$0b,$fc,$09	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 854
	db	$39,$09,$fc,$0a,$34,$09,$fc,$0b	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 854
	db	$34,$08,$fc,$0b,$39,$0a,$fc,$0a	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 855
	db	$39,$09,$fc,$0a,$34,$0b,$fc,$09	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 855
	db	$36,$0a,$fc,$09,$3b,$08,$fc,$0c	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 856
	db	$3b,$09,$fc,$0a,$36,$09,$fc,$0a	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 856
	db	$36,$0a,$fc,$0a,$3b,$0b,$fc,$08	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 857
	db	$3b,$09,$fc,$0b,$36,$09,$fc,$0a	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 857
	db	$fd,$19,$38,$4e,$38,$26,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 858
	db	$36,$26,$fc,$01,$32,$4d,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 859
	db	$32,$26,$fc,$01,$31,$26,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 861
	db	$32,$9b,$31,$9d,$fc,$4d,$fc,$4e	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 862
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 868
	db	$fc,$4e,$fc,$4e,$fd,$16,$39,$74	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 872
	db	$38,$27,$36,$4e,$35,$4d,$fc,$01	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 875
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 878
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$27	;Trk L; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 882
	db	$48,$26,$fc,$01,$fc,$09
song_000_11_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_11_lp)*2
	dw	song_000_11_lp


song_000_15:	;Trk P
	db	$fd,$01,$fe,$00,$fb,$05,$ef,$07	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 70
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 888
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 892
	db	$fc,$3a,$61,$05,$fc,$0f,$fc,$4d	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 896
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 898
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 902
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 906
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 910
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 914
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 918
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 922
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 926
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 930
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 934
	db	$fc,$4e,$fc,$4e,$fc,$3a,$fd,$00	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 938
	db	$61,$05,$fc,$0e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 940
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 943
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 947
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 951
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 955
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 959
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 963
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 967
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk P; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 971
	db	$fc,$4e,$fc,$09
song_000_15_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_15_lp)*2
	dw	song_000_15_lp


song_000_16:	;Trk Q
	db	$fd,$04,$fe,$01,$fb,$01,$ef,$07	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 71
	db	$fc,$13,$48,$0a,$fd,$03,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 978
	db	$fc,$06,$fd,$02,$48,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 978
	db	$fd,$04,$48,$0a,$fd,$03,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 978
	db	$fc,$06,$fd,$02,$48,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 978
	db	$fd,$04,$48,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 979
	db	$48,$04,$fc,$06,$fd,$02,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 979
	db	$fc,$0f,$fd,$04,$51,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 979
	db	$fd,$03,$51,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 979
	db	$51,$04,$fc,$0f,$fd,$04,$4b,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 980
	db	$fc,$01,$fd,$03,$4b,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 980
	db	$fd,$02,$4b,$04,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 980
	db	$4b,$09,$fc,$01,$fd,$03,$4b,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 980
	db	$fc,$06,$fd,$02,$4b,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 980
	db	$fd,$04,$51,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 981
	db	$51,$04,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 981
	db	$fc,$0f,$fd,$04,$46,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 981
	db	$fd,$03,$46,$04,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 981
	db	$46,$05,$fc,$0f,$fd,$04,$44,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 982
	db	$fc,$01,$fd,$03,$44,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 982
	db	$fd,$02,$44,$05,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 982
	db	$44,$08,$fc,$01,$fd,$03,$44,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 982
	db	$fc,$05,$fd,$02,$44,$04,$fc,$10	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 982
	db	$fd,$04,$44,$09,$fd,$03,$44,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 983
	db	$fc,$05,$fd,$02,$44,$04,$fc,$10	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 983
	db	$fd,$04,$44,$09,$fd,$03,$44,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 983
	db	$fc,$05,$fd,$02,$44,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 983
	db	$fd,$04,$46,$0a,$fd,$03,$46,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 984
	db	$fc,$06,$fd,$02,$46,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 984
	db	$fd,$04,$46,$0a,$fd,$03,$46,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 984
	db	$fc,$06,$fd,$02,$46,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 984
	db	$fd,$04,$46,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 985
	db	$46,$04,$fc,$06,$fd,$02,$46,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 985
	db	$fc,$0f,$fd,$04,$43,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 985
	db	$fd,$03,$43,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 985
	db	$43,$04,$fc,$0f,$fd,$04,$48,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 986
	db	$fc,$01,$fd,$03,$48,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 986
	db	$fd,$02,$48,$04,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 986
	db	$48,$09,$fc,$01,$fd,$03,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 986
	db	$fc,$06,$fd,$02,$48,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 986
	db	$fd,$04,$48,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 987
	db	$48,$04,$fc,$05,$fd,$02,$48,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 987
	db	$fc,$0f,$fd,$04,$51,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 987
	db	$fd,$03,$51,$04,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 987
	db	$51,$05,$fc,$0f,$fd,$04,$4b,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 988
	db	$fc,$01,$fd,$03,$4b,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 988
	db	$fd,$02,$4b,$05,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 988
	db	$4b,$09,$fd,$03,$4b,$05,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 988
	db	$fd,$02,$4b,$04,$fc,$10,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 989
	db	$51,$08,$fc,$01,$fd,$03,$51,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 989
	db	$fc,$05,$fd,$02,$51,$04,$fc,$10	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 989
	db	$fd,$04,$46,$09,$fd,$03,$46,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 989
	db	$fc,$05,$fd,$02,$46,$04,$fc,$10	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 989
	db	$fd,$04,$44,$08,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 990
	db	$44,$05,$fc,$05,$fd,$02,$44,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 990
	db	$fc,$0f,$fd,$04,$44,$0a,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 990
	db	$44,$04,$fc,$06,$fc,$13,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 990
	db	$44,$09,$fc,$01,$fd,$03,$44,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 991
	db	$fc,$06,$fd,$02,$44,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 991
	db	$fd,$04,$44,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 991
	db	$44,$04,$fc,$06,$fd,$02,$44,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 991
	db	$fc,$0f,$fd,$04,$46,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 992
	db	$fd,$03,$46,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 992
	db	$46,$04,$fc,$0f,$fd,$04,$46,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 992
	db	$fc,$01,$fd,$03,$46,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 992
	db	$fd,$02,$46,$04,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 993
	db	$46,$09,$fc,$01,$fd,$03,$46,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 993
	db	$fc,$05,$fd,$02,$46,$05,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 993
	db	$fd,$04,$53,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 993
	db	$53,$04,$fc,$05,$fd,$02,$53,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 993
	db	$fc,$49,$fc,$4e,$fc,$4e,$fc,$4e	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 994
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 998
	db	$fc,$14,$fd,$06,$51,$08,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1002
	db	$fd,$03,$51,$05,$fc,$05,$fd,$07	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1002
	db	$46,$08,$fc,$0b,$fd,$06,$51,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1002
	db	$fc,$01,$fd,$03,$51,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1002
	db	$fd,$07,$46,$08,$fc,$0b,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1003
	db	$51,$09,$fc,$01,$fd,$03,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1003
	db	$fc,$06,$fd,$02,$51,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1003
	db	$fd,$06,$56,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1003
	db	$56,$04,$fc,$06,$fd,$02,$56,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1003
	db	$fc,$0f,$fd,$06,$54,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1004
	db	$fd,$03,$54,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1004
	db	$54,$04,$fc,$0f,$fd,$06,$54,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1004
	db	$fc,$01,$fd,$03,$54,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1004
	db	$fd,$02,$54,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1005
	db	$56,$09,$fc,$01,$fd,$03,$56,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1005
	db	$fc,$06,$fd,$02,$56,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1005
	db	$fd,$06,$4b,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1005
	db	$4b,$04,$fc,$05,$fd,$02,$4b,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1005
	db	$fc,$0f,$fd,$06,$49,$08,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1006
	db	$fd,$03,$49,$04,$fc,$19,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1006
	db	$49,$08,$fc,$02,$fd,$03,$49,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1006
	db	$fc,$05,$fd,$02,$49,$05,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1006
	db	$fd,$06,$49,$08,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1007
	db	$49,$05,$fc,$05,$fd,$02,$49,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1007
	db	$fc,$10,$fd,$06,$49,$08,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1007
	db	$fd,$03,$49,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1007
	db	$49,$04,$fc,$10,$fd,$06,$4b,$08	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1008
	db	$fc,$01,$fd,$03,$4b,$05,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1008
	db	$fd,$02,$4b,$04,$fc,$10,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1008
	db	$4b,$08,$fc,$01,$fd,$03,$4b,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1008
	db	$fc,$05,$fd,$02,$4b,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1008
	db	$fd,$06,$4b,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1009
	db	$4b,$04,$fc,$06,$fd,$02,$4b,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1009
	db	$fc,$0f,$fd,$06,$58,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1009
	db	$fd,$03,$58,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1009
	db	$58,$04,$fc,$0f,$fd,$06,$51,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1010
	db	$fc,$01,$fd,$03,$51,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1010
	db	$fd,$02,$51,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1010
	db	$51,$09,$fc,$01,$fd,$03,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1010
	db	$fc,$06,$fd,$02,$51,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1010
	db	$fd,$06,$51,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1011
	db	$51,$04,$fc,$06,$fd,$02,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1011
	db	$fc,$0f,$fd,$06,$51,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1011
	db	$fd,$03,$51,$04,$fc,$05,$fc,$14	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1011
	db	$fd,$06,$49,$08,$fc,$02,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1012
	db	$49,$04,$fc,$05,$fd,$02,$49,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1012
	db	$fc,$0f,$fd,$06,$49,$08,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1012
	db	$fd,$03,$49,$04,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1012
	db	$49,$05,$fc,$0f,$fd,$06,$48,$08	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1013
	db	$fc,$02,$fd,$03,$48,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1013
	db	$fd,$02,$48,$05,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1013
	db	$48,$08,$fc,$01,$fd,$03,$48,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1013
	db	$fc,$05,$fd,$02,$48,$04,$fc,$10	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1013
	db	$fd,$06,$51,$08,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1014
	db	$51,$05,$fc,$05,$fd,$02,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1014
	db	$fc,$10,$fd,$06,$51,$08,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1014
	db	$fd,$03,$51,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1014
	db	$51,$04,$fc,$0f,$fd,$06,$51,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1015
	db	$fc,$01,$fd,$03,$51,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1015
	db	$fd,$02,$51,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1015
	db	$51,$09,$fc,$01,$fd,$03,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1015
	db	$fc,$06,$fd,$02,$51,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1015
	db	$fd,$06,$49,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1016
	db	$49,$04,$fc,$06,$fd,$02,$49,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1016
	db	$fc,$0f,$fd,$06,$49,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1016
	db	$fd,$03,$49,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1016
	db	$49,$04,$fc,$0f,$fd,$06,$48,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1017
	db	$fc,$01,$fd,$03,$48,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1017
	db	$fd,$02,$48,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1017
	db	$48,$09,$fc,$01,$fd,$03,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1017
	db	$fc,$06,$fd,$02,$48,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1017
	db	$fd,$06,$51,$08,$fc,$02,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1018
	db	$51,$04,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1018
	db	$fc,$0f,$fd,$06,$51,$08,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1018
	db	$fd,$03,$51,$04,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1018
	db	$51,$05,$fc,$0f,$fd,$06,$51,$08	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1019
	db	$fc,$02,$fd,$03,$51,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1019
	db	$fd,$02,$51,$05,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1019
	db	$51,$08,$fc,$01,$fd,$03,$51,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1019
	db	$fc,$05,$fd,$02,$51,$04,$fc,$10	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1019
	db	$fd,$06,$61,$08,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1020
	db	$61,$05,$fc,$05,$fd,$02,$61,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1020
	db	$fc,$10,$fd,$06,$61,$08,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1020
	db	$fd,$03,$61,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1020
	db	$61,$04,$fc,$0f,$fd,$06,$61,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1021
	db	$fc,$01,$fd,$03,$61,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1021
	db	$fd,$02,$61,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1021
	db	$61,$09,$fc,$01,$fd,$03,$61,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1021
	db	$fc,$06,$fc,$13,$fd,$04,$48,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1021
	db	$fc,$01,$fd,$03,$48,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1022
	db	$fd,$02,$48,$04,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1022
	db	$48,$09,$fc,$01,$fd,$03,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1022
	db	$fc,$06,$fd,$02,$48,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1022
	db	$fd,$04,$48,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1023
	db	$48,$04,$fc,$06,$fd,$02,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1023
	db	$fc,$0f,$fd,$04,$51,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1023
	db	$fd,$03,$51,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1023
	db	$51,$04,$fc,$0f,$fd,$04,$4b,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1024
	db	$fc,$01,$fd,$03,$4b,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1024
	db	$fd,$02,$4b,$05,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1024
	db	$4b,$09,$fc,$01,$fd,$03,$4b,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1024
	db	$fc,$05,$fd,$02,$4b,$05,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1024
	db	$fd,$04,$51,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1025
	db	$51,$04,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1025
	db	$fc,$0f,$fd,$04,$46,$09,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1025
	db	$46,$05,$fc,$05,$fd,$02,$46,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1025
	db	$fc,$10,$fd,$04,$44,$09,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1026
	db	$44,$05,$fc,$05,$fd,$02,$44,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1026
	db	$fc,$10,$fd,$04,$44,$08,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1026
	db	$fd,$03,$44,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1026
	db	$44,$04,$fc,$10,$fd,$04,$44,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1027
	db	$fd,$03,$44,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1027
	db	$44,$04,$fc,$0f,$fd,$04,$44,$0a	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1027
	db	$fd,$03,$44,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1027
	db	$44,$04,$fc,$0f,$fd,$04,$46,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1028
	db	$fc,$01,$fd,$03,$46,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1028
	db	$fd,$02,$46,$04,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1028
	db	$46,$09,$fc,$01,$fd,$03,$46,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1028
	db	$fc,$06,$fd,$02,$46,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1028
	db	$fd,$04,$46,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1029
	db	$46,$04,$fc,$06,$fd,$02,$46,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1029
	db	$fc,$0f,$fd,$04,$43,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1029
	db	$fd,$03,$43,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1029
	db	$43,$04,$fc,$0f,$fd,$04,$48,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1030
	db	$fc,$01,$fd,$03,$48,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1030
	db	$fd,$02,$48,$05,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1030
	db	$48,$08,$fc,$02,$fd,$03,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1030
	db	$fc,$05,$fd,$02,$48,$05,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1030
	db	$fd,$04,$48,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1031
	db	$48,$04,$fc,$05,$fd,$02,$48,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1031
	db	$fc,$0f,$fd,$04,$51,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1031
	db	$fd,$03,$51,$04,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1031
	db	$51,$05,$fc,$0f,$fd,$04,$4b,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1032
	db	$fd,$03,$4b,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1032
	db	$4b,$04,$fc,$10,$fd,$04,$4b,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1032
	db	$fd,$03,$4b,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1032
	db	$4b,$04,$fc,$10,$fd,$04,$51,$08	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1033
	db	$fc,$01,$fd,$03,$51,$05,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1033
	db	$fd,$02,$51,$04,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1033
	db	$46,$0a,$fd,$03,$46,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1033
	db	$fd,$02,$46,$04,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1034
	db	$44,$09,$fc,$01,$fd,$03,$44,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1034
	db	$fc,$06,$fd,$02,$44,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1034
	db	$fd,$04,$44,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1034
	db	$44,$04,$fc,$06,$fc,$13,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1034
	db	$44,$09,$fc,$01,$fd,$03,$44,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1035
	db	$fc,$06,$fd,$02,$44,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1035
	db	$fd,$04,$44,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1035
	db	$44,$04,$fc,$06,$fd,$02,$44,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1035
	db	$fc,$0f,$fd,$04,$46,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1036
	db	$fd,$03,$46,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1036
	db	$46,$04,$fc,$0f,$fd,$04,$46,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1036
	db	$fc,$01,$fd,$03,$46,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1036
	db	$fd,$02,$46,$05,$fc,$0f,$fd,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1037
	db	$46,$09,$fc,$01,$fd,$03,$46,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1037
	db	$fc,$05,$fd,$02,$46,$05,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1037
	db	$fd,$04,$53,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1037
	db	$53,$04,$fc,$05,$fd,$02,$53,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1037
	db	$fc,$49,$fc,$4e,$fc,$4e,$fc,$4e	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1038
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1042
	db	$fc,$13,$fd,$06,$51,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1046
	db	$fd,$03,$51,$04,$fc,$06,$fd,$07	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1046
	db	$46,$08,$fc,$0b,$fd,$06,$51,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1046
	db	$fc,$01,$fd,$03,$51,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1046
	db	$fd,$07,$46,$08,$fc,$0b,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1047
	db	$51,$09,$fc,$01,$fd,$03,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1047
	db	$fc,$06,$fd,$02,$51,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1047
	db	$fd,$06,$56,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1047
	db	$56,$04,$fc,$06,$fd,$02,$56,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1047
	db	$fc,$0f,$fd,$06,$54,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1048
	db	$fd,$03,$54,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1048
	db	$54,$04,$fc,$0f,$fd,$06,$54,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1048
	db	$fc,$01,$fd,$03,$54,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1048
	db	$fd,$02,$54,$05,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1049
	db	$56,$08,$fc,$02,$fd,$03,$56,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1049
	db	$fc,$05,$fd,$02,$56,$05,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1049
	db	$fd,$06,$4b,$08,$fc,$02,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1049
	db	$4b,$04,$fc,$05,$fd,$02,$4b,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1049
	db	$fc,$0f,$fd,$06,$49,$08,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1050
	db	$fd,$03,$49,$04,$fc,$19,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1050
	db	$49,$08,$fc,$01,$fd,$03,$49,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1050
	db	$fc,$05,$fd,$02,$49,$04,$fc,$10	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1050
	db	$fd,$06,$49,$08,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1051
	db	$49,$05,$fc,$05,$fd,$02,$49,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1051
	db	$fc,$10,$fd,$06,$49,$08,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1051
	db	$fd,$03,$49,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1051
	db	$49,$04,$fc,$0f,$fd,$06,$4b,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1052
	db	$fc,$01,$fd,$03,$4b,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1052
	db	$fd,$02,$4b,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1052
	db	$4b,$09,$fc,$01,$fd,$03,$4b,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1052
	db	$fc,$06,$fd,$02,$4b,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1052
	db	$fd,$06,$4b,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1053
	db	$4b,$04,$fc,$06,$fd,$02,$4b,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1053
	db	$fc,$0f,$fd,$06,$58,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1053
	db	$fd,$03,$58,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1053
	db	$58,$04,$fc,$0f,$fd,$06,$51,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1054
	db	$fc,$01,$fd,$03,$51,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1054
	db	$fd,$02,$51,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1054
	db	$51,$09,$fc,$01,$fd,$03,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1054
	db	$fc,$06,$fd,$02,$51,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1054
	db	$fd,$06,$51,$08,$fc,$02,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1055
	db	$51,$04,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1055
	db	$fc,$0f,$fd,$06,$51,$08,$fc,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1055
	db	$fd,$03,$51,$04,$fc,$05,$fc,$14	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1055
	db	$fd,$06,$49,$08,$fc,$02,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1056
	db	$49,$04,$fc,$05,$fd,$02,$49,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1056
	db	$fc,$0f,$fd,$06,$49,$08,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1056
	db	$fd,$03,$49,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1056
	db	$49,$04,$fc,$10,$fd,$06,$48,$08	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1057
	db	$fc,$01,$fd,$03,$48,$05,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1057
	db	$fd,$02,$48,$04,$fc,$10,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1057
	db	$48,$08,$fc,$01,$fd,$03,$48,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1057
	db	$fc,$05,$fd,$02,$48,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1057
	db	$fd,$06,$51,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1058
	db	$51,$04,$fc,$06,$fd,$02,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1058
	db	$fc,$0f,$fd,$06,$51,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1058
	db	$fd,$03,$51,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1058
	db	$51,$04,$fc,$0f,$fd,$06,$51,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1059
	db	$fc,$01,$fd,$03,$51,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1059
	db	$fd,$02,$51,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1059
	db	$51,$09,$fc,$01,$fd,$03,$51,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1059
	db	$fc,$06,$fd,$02,$51,$04,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1059
	db	$fd,$06,$49,$09,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1060
	db	$49,$04,$fc,$06,$fd,$02,$49,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1060
	db	$fc,$0f,$fd,$06,$49,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1060
	db	$fd,$03,$49,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1060
	db	$49,$04,$fc,$0f,$fd,$06,$48,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1061
	db	$fc,$01,$fd,$03,$48,$04,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1061
	db	$fd,$02,$48,$05,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1061
	db	$48,$08,$fc,$02,$fd,$03,$48,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1061
	db	$fc,$05,$fd,$02,$48,$05,$fc,$0f	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1061
	db	$fd,$06,$51,$08,$fc,$02,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1062
	db	$51,$04,$fc,$05,$fd,$02,$51,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1062
	db	$fc,$0f,$fd,$06,$51,$08,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1062
	db	$fd,$03,$51,$05,$fc,$05,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1062
	db	$51,$04,$fc,$10,$fd,$06,$51,$08	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1063
	db	$fc,$01,$fd,$03,$51,$05,$fc,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1063
	db	$fd,$02,$51,$04,$fc,$10,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1063
	db	$51,$08,$fc,$01,$fd,$03,$51,$05	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1063
	db	$fc,$05,$fd,$02,$51,$04,$fc,$10	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1063
	db	$fd,$06,$61,$08,$fc,$01,$fd,$03	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1064
	db	$61,$05,$fc,$05,$fd,$02,$61,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1064
	db	$fc,$0f,$fd,$06,$61,$09,$fc,$01	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1064
	db	$fd,$03,$61,$04,$fc,$06,$fd,$02	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1064
	db	$61,$04,$fc,$0f,$fd,$06,$61,$09	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1065
	db	$fc,$01,$fd,$03,$61,$04,$fc,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1065
	db	$fd,$02,$61,$04,$fc,$0f,$fd,$06	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1065
	db	$61,$09,$fc,$01,$fd,$03,$61,$04	;Trk Q; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1065
	db	$fc,$06,$fc,$09
song_000_16_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_16_lp)*2
	dw	song_000_16_lp


song_000_17:	;Trk R
	db	$fd,$02,$fe,$02,$fb,$01,$ef,$07	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 72
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1068
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1072
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1076
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1080
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1084
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1088
	db	$fc,$27,$51,$04,$fc,$23,$51,$04	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1092
	db	$fc,$23,$fd,$07,$3b,$08,$fc,$0b	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1093
	db	$46,$08,$fc,$0c,$39,$08,$fc,$0b	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1093
	db	$44,$08,$fc,$0c,$39,$08,$fc,$0b	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1094
	db	$44,$08,$fc,$0c,$3b,$08,$fc,$0b	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1094
	db	$46,$08,$fc,$0c,$3b,$07,$fc,$1f	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1095
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1096
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1100
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1104
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1108
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1112
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1116
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1120
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1124
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1128
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1132
	db	$fc,$27,$fd,$02,$51,$04,$fc,$23	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1136
	db	$51,$04,$fc,$23,$fd,$07,$3b,$08	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1137
	db	$fc,$0b,$46,$08,$fc,$0c,$39,$08	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1137
	db	$fc,$0b,$44,$08,$fc,$0c,$39,$07	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1138
	db	$fc,$0c,$44,$08,$fc,$0b,$3b,$08	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1138
	db	$fc,$0c,$46,$08,$fc,$0b,$3b,$08	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1139
	db	$fc,$1f,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1139
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1143
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1147
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk R; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1151
	db	$fc,$4e,$fc,$09
song_000_17_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_17_lp)*2
	dw	song_000_17_lp


song_000_18:	;Trk S
	db	$fd,$0e,$fe,$03,$fb,$06,$ef,$07	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 73
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1158
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1162
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1166
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$3a	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1170
	db	$58,$08,$fc,$02,$58,$08,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1173
	db	$58,$9b,$fc,$01,$56,$9b,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1174
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1178
	db	$49,$74,$fc,$01,$46,$26,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1182
	db	$44,$4d,$fc,$01,$46,$26,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1184
	db	$48,$26,$49,$9c,$54,$74,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1185
	db	$55,$26,$fc,$01,$fd,$10,$46,$09	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1189
	db	$fc,$01,$48,$08,$fc,$01,$49,$09	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1190
	db	$fc,$01,$4b,$09,$fc,$01,$51,$0b	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1190
	db	$fc,$08,$56,$0c,$fc,$08,$59,$13	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1190
	db	$58,$09,$fc,$01,$56,$08,$fc,$02	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1191
	db	$54,$0d,$fc,$06,$51,$0d,$fc,$06	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1191
	db	$56,$13,$fc,$01,$54,$09,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1192
	db	$52,$09,$51,$07,$fc,$0d,$4b,$0c	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1192
	db	$fc,$07,$49,$14,$48,$13,$49,$13	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1192
	db	$fc,$01,$4b,$13,$fd,$0d,$46,$75	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1193
	db	$48,$27,$49,$4d,$fc,$01,$48,$4c	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1195
	db	$fc,$02,$4a,$ff,$f4,$11,$fc,$27	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1197
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1202
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1206
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1210
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$3b	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1214
	db	$fd,$0e,$58,$08,$fc,$02,$58,$07	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1217
	db	$fc,$02,$58,$9b,$fc,$01,$56,$9b	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1217
	db	$fc,$01,$fc,$4d,$fc,$4e,$fc,$4e	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1221
	db	$fc,$4e,$49,$74,$fc,$01,$46,$26	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1225
	db	$fc,$01,$44,$4d,$46,$27,$48,$27	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1227
	db	$49,$9b,$fc,$01,$54,$74,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1230
	db	$55,$26,$fc,$01,$fd,$0f,$46,$09	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1233
	db	$48,$09,$fc,$01,$49,$09,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1234
	db	$4b,$09,$fc,$01,$51,$0b,$fc,$08	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1234
	db	$56,$0c,$fc,$08,$59,$12,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1234
	db	$58,$08,$fc,$02,$56,$08,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1235
	db	$54,$0e,$fc,$06,$51,$0d,$fc,$06	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1235
	db	$56,$13,$fc,$01,$54,$09,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1236
	db	$52,$09,$51,$07,$fc,$0d,$4b,$0c	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1236
	db	$fc,$07,$49,$14,$48,$13,$49,$13	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1236
	db	$fc,$01,$4b,$12,$fc,$01,$fd,$0d	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1237
	db	$46,$75,$48,$27,$49,$4d,$fc,$01	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1238
	db	$48,$4c,$fc,$01,$4a,$ff,$f4,$12	;Trk S; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1241
	db	$fc,$27,$fc,$09
song_000_18_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_18_lp)*2
	dw	song_000_18_lp


song_000_19:	;Trk T
	db	$fd,$0e,$fe,$04,$fb,$06,$ef,$07	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 74
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1248
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1252
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1256
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$3a	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1260
	db	$51,$08,$fc,$02,$51,$06,$fc,$03	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1263
	db	$51,$9b,$fc,$01,$4b,$9b,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1264
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1268
	db	$51,$74,$fc,$01,$4b,$26,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1272
	db	$49,$4d,$fc,$01,$4b,$26,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1274
	db	$4b,$26,$52,$9b,$fc,$01,$4b,$9a	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1275
	db	$fc,$02,$fc,$4e,$fc,$4d,$fc,$4e	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1279
	db	$fc,$4e,$fd,$0d,$49,$74,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1283
	db	$4b,$26,$fc,$01,$52,$4d,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1285
	db	$51,$4d,$fc,$01,$51,$ff,$f4,$10	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1287
	db	$fc,$28,$fc,$4e,$fc,$4e,$fc,$4d	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1291
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1295
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1299
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1303
	db	$fc,$3b,$fd,$0e,$51,$08,$fc,$02	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1307
	db	$51,$06,$fc,$03,$51,$9b,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1307
	db	$4b,$9b,$fc,$01,$fc,$4d,$fc,$4e	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1310
	db	$fc,$4e,$fc,$4e,$51,$74,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1314
	db	$4b,$26,$fc,$01,$49,$4d,$4b,$27	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1317
	db	$4b,$27,$52,$9b,$fc,$01,$4b,$9a	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1319
	db	$fc,$02,$fc,$4e,$fc,$4d,$fc,$4e	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1323
	db	$fc,$4e,$fd,$0d,$49,$74,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1327
	db	$4b,$26,$fc,$01,$52,$4d,$fc,$01	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1329
	db	$51,$4d,$51,$ff,$f4,$11,$fc,$28	;Trk T; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1331
	db	$fc,$09
song_000_19_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_19_lp)*2
	dw	song_000_19_lp


song_000_20:	;Trk U
	db	$fd,$07,$fe,$05,$fb,$01,$ef,$07	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 75
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1338
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1342
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1346
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1350
	db	$fc,$27,$58,$05,$fc,$05,$fd,$04	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1354
	db	$58,$03,$fc,$1a,$fc,$27,$fd,$07	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1354
	db	$58,$04,$fc,$06,$fd,$05,$58,$03	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1355
	db	$fc,$1a,$fc,$27,$fd,$07,$56,$04	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1355
	db	$fc,$06,$fd,$04,$56,$03,$fc,$1a	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1356
	db	$fc,$27,$fd,$07,$56,$04,$fc,$06	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1357
	db	$fd,$04,$56,$03,$fc,$1a,$fc,$27	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1357
	db	$fd,$07,$55,$04,$fc,$05,$fd,$04	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1358
	db	$55,$03,$fc,$1b,$fc,$27,$fd,$07	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1358
	db	$55,$04,$fc,$05,$fd,$04,$55,$03	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1359
	db	$fc,$1a,$fd,$07,$55,$05,$fc,$05	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1359
	db	$fd,$04,$55,$03,$fc,$1a,$fd,$07	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1360
	db	$55,$05,$fc,$05,$fd,$04,$55,$03	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1360
	db	$fc,$1a,$fd,$07,$55,$05,$fc,$05	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1360
	db	$fd,$04,$55,$03,$fc,$1a,$fd,$07	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1361
	db	$55,$04,$fc,$06,$fd,$04,$55,$03	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1361
	db	$fc,$1a,$fc,$4e,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1361
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1365
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1369
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1373
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1377
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1381
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1385
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1389
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1393
	db	$fc,$4e,$fc,$27,$fd,$07,$58,$04	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1397
	db	$fc,$06,$fd,$04,$58,$03,$fc,$1a	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1398
	db	$fc,$27,$fd,$07,$58,$04,$fc,$06	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1399
	db	$fd,$05,$58,$03,$fc,$1a,$fc,$27	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1399
	db	$fd,$07,$56,$04,$fc,$06,$fd,$04	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1400
	db	$56,$03,$fc,$1a,$fc,$27,$fd,$07	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1400
	db	$56,$04,$fc,$05,$fd,$04,$56,$03	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1401
	db	$fc,$1b,$fc,$27,$fd,$07,$55,$04	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1401
	db	$fc,$05,$fd,$04,$55,$03,$fc,$1a	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1402
	db	$fc,$27,$fd,$07,$55,$05,$fc,$05	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1403
	db	$fd,$04,$55,$03,$fc,$1a,$fd,$07	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1403
	db	$55,$05,$fc,$05,$fd,$04,$55,$03	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1404
	db	$fc,$1a,$fd,$07,$55,$04,$fc,$06	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1404
	db	$fd,$04,$55,$03,$fc,$1a,$fd,$07	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1404
	db	$55,$04,$fc,$06,$fd,$04,$55,$03	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1405
	db	$fc,$1a,$fd,$07,$55,$04,$fc,$06	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1405
	db	$fd,$04,$55,$03,$fc,$1a,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1405
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1407
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1411
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1415
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1419
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$09	;Trk U; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1423

song_000_20_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_20_lp)*2
	dw	song_000_20_lp


song_000_21:	;Trk V
	db	$fd,$07,$fe,$06,$fb,$01,$ef,$07	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 76
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1428
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1432
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1436
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1440
	db	$fc,$27,$48,$05,$fc,$22,$fc,$27	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1444
	db	$48,$04,$fc,$23,$fc,$27,$46,$04	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1445
	db	$fc,$23,$fc,$27,$46,$04,$fc,$23	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1446
	db	$fc,$27,$45,$04,$fc,$23,$fc,$27	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1448
	db	$45,$04,$fc,$22,$45,$05,$fc,$22	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1449
	db	$45,$05,$fc,$22,$45,$05,$fc,$22	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1450
	db	$45,$04,$fc,$23,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1451
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1454
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1458
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1462
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1466
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1470
	db	$fc,$4d,$fc,$4e,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1474
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1478
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1482
	db	$fc,$4d,$fc,$4e,$fc,$27,$48,$04	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1486
	db	$fc,$23,$fc,$27,$48,$04,$fc,$23	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1488
	db	$fc,$27,$46,$04,$fc,$23,$fc,$27	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1490
	db	$46,$04,$fc,$23,$fc,$27,$45,$04	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1491
	db	$fc,$22,$fc,$27,$45,$05,$fc,$22	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1492
	db	$45,$05,$fc,$22,$45,$04,$fc,$23	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1494
	db	$45,$04,$fc,$23,$45,$04,$fc,$23	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1495
	db	$fc,$4e,$fc,$4e,$fc,$4d,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1496
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1500
	db	$fc,$4e,$fc,$4d,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1504
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4d	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1508
	db	$fc,$4e,$fc,$4e,$fc,$4e,$fc,$4e	;Trk V; C:\Users\stgig\Downloads\ppmck-master\songs\SmRPG_forest(1).mml: 1512
	db	$fc,$09
song_000_21_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_21_lp)*2
	dw	song_000_21_lp


song_000_22:	;Trk W

song_000_22_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_22_lp)*2
	dw	song_000_22_lp

