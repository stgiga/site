; Macros for improved PPMCK, can be used in user subroutines

_endsub		.macro
		jmp	sound_data_read
		.endm
